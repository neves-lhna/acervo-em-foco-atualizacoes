VERSION = '2026.10.22.2'
SEQUENCE = 2
PUBLIC_KEY = 'fz79aI6AFMv2zoc9P5yYa/lQwiOwaZ3EJG9et1MZKco='
REPOSITORY = 'neves-lhna/acervo-em-foco-atualizacoes'
CHANNEL_URL = 'https://raw.githubusercontent.com/' + REPOSITORY + '/main/updates/stable.json'
