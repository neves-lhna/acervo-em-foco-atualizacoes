"""
main.py
--------
Ponto de entrada da aplicação de busca de rostos em galerias locais.

Execução:
    pip install -r requirements.txt
    python main.py

Na primeira execução, o InsightFace baixa automaticamente os pesos do
bundle "buffalo_l" (~350MB) para ~/.insightface/models/. É necessário
acesso à internet apenas nesse primeiro uso.
"""

import sys
import multiprocessing

if __name__ == '__main__':
    from core.update_bootstrap import dispatch
    dispatch()


def main():
    from PySide6.QtWidgets import QApplication

    from ui.main_window import MainWindow
    from ui.theme import apply_theme, watch_theme
    from ui.branding import app_icon
    from ui.scroll_preview import install_scroll_preview
    from ui.language import install_portuguese
    from core.app_profile import current_profile

    # Give each edition its own Windows taskbar identity instead of Python's.
    if sys.platform == 'win32':
        import ctypes
        set_app_id = ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID
        set_app_id.argtypes = [ctypes.c_wchar_p]
        set_app_id.restype = ctypes.c_long
        set_app_id('AcervoEmFoco.' + current_profile().key)
    app = QApplication(sys.argv)
    install_portuguese(app)
    app.setApplicationDisplayName(current_profile().title)
    app.setWindowIcon(app_icon())
    from ui.windows_identity import install_native_icons
    install_native_icons(app)
    apply_theme(app)
    watch_theme(app)
    install_scroll_preview(app)

    from ui.archive_startup import prepare_archive
    app.setQuitOnLastWindowClosed(False)
    lock, location = prepare_archive(app)
    if lock is None:
        return

    from core import diagnostics
    from ui.diagnostic_log import NotificationBus,configure_log
    app.notification_bus=NotificationBus(app)
    app.diagnostic_store=diagnostics.initialize(current_profile().data_directory()/'diagnostics',app.notification_bus.message.emit)
    diagnostics.install_exception_hooks()
    if not app.diagnostic_store.configured:
        configure_log(None,app.diagnostic_store)
    window = MainWindow()
    window.show()
    from ui.startup_updates import StartupUpdates
    window.startup_updates = StartupUpdates(window)
    from core.signed_updates import mark_healthy
    mark_healthy()
    import os
    if os.environ.pop("ACERVO_UPDATE_ROLLBACK", None):
        window._notify("A última atualização não concluiu a abertura. A versão anterior foi restaurada; os bancos foram preservados.")
    if not app.diagnostic_store.configured:
        window._notify('Log técnico sem senha configurada. Use Ctrl+Shift+L para configurar; os registros desta sessão ainda não serão salvos em disco.')
    app.setQuitOnLastWindowClosed(True)
    if location['mappings']:
        window.statusBar().showMessage('Localização do acervo atualizada automaticamente: ' + '; '.join(new for old, new in location['mappings']), 30000)
    elif location['warnings']:
        window.statusBar().showMessage(location['warnings'][0])

    sys.exit(app.exec())


if __name__ == "__main__":
    multiprocessing.freeze_support()
    if '--maintenance' in sys.argv:
        from ui.maintenance import main as maintenance_main
        sys.exit(maintenance_main())
    elif len(sys.argv) == 3 and sys.argv[1] == '--verify-package':
        from core.frozen_checks import run_checks
        sys.exit(run_checks(sys.argv[2]))
    else:
        main()
