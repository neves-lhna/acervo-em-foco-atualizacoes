"""
ui/main_window.py
--------------------
Janela principal: orquestra a seleção da foto de referência, o crop
interativo, a configuração da busca (pasta alvo + limiar de
similaridade) e a exibição progressiva dos resultados enquanto o
ScanWorker roda em background.

Nota de arquitetura sobre responsividade:
  Nenhuma chamada de inferência (`FaceEngine.detect_faces`) ou I/O de
  disco pesado acontece diretamente aqui na thread de UI, EXCETO a
  detecção sobre a única foto de referência (rápida, imagem única,
  ~100-300ms) feita dentro do CropDialog — um custo aceitável e único,
  disparado por uma ação explícita do usuário. Toda a varredura da
  galeria (potencialmente milhares de imagens) acontece exclusivamente
  dentro do `ScanWorker`, que roda em uma QThread dedicada.
"""

from __future__ import annotations

import os
import time

from PySide6.QtCore import Qt, Signal, QBuffer, QIODevice, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QLabel,
    QFileDialog,
    QListWidget,
    QListWidgetItem,
    QProgressBar,
    QSlider,
    QMessageBox,
    QGroupBox,
    QFormLayout,
    QDialog,
    QFrame,
    QTabWidget,
    QTabBar,
    QStackedLayout,
    QGraphicsOpacityEffect,
)

from core.face_engine import FaceEngine, load_bgr_image
from core.embedding_cache import EmbeddingCache
from ui.crop_dialog import CropDialog, bgr_to_qpixmap
from ui.result_widget import ResultItemWidget
from workers.scan_worker import ScanWorker
from workers.inventory_worker import InventoryWorker
from workers.cache_worker import CacheWorker
from core.folder_history import FolderHistory
from ui.folders_tab import FoldersTab
from ui.dialog_paths import initial_directory,remember_folder,last_folder
from ui.duplicates_tab import DuplicatesTab
from ui.branding import brand_label,app_icon
from core.face_history import FaceHistory
from ui.face_history_tab import FaceHistoryTab

from core.app_profile import current_profile

CACHE_DB_PATH = str(current_profile().data_directory() / 'embeddings_cache.db')


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(current_profile().title)
        self.setWindowIcon(app_icon())
        screen = self.screen().availableGeometry()
        self.resize(min(1180, screen.width()-50), min(850, screen.height()-70))

        self.reference_embedding = None
        self.reference_pose = None
        self.target_folder = None
        self._last_reference_directory = None
        self.worker: ScanWorker | None = None
        self.cache = EmbeddingCache(CACHE_DB_PATH)
        self.face_history = FaceHistory(os.path.join(os.path.dirname(CACHE_DB_PATH), 'face_history.db'))
        self._history_face = None
        self.history = FolderHistory(os.path.join(os.path.dirname(CACHE_DB_PATH), "folder_history.db"))
        self.history.recover_interrupted()
        self.history.consolidate_completed()
        self._cache_worker = None
        self._cache_queue = []
        self._cache_paused = False
        self._inventory_worker = None
        self._engine_ready = False

        self._build_ui()
        self._folder_signatures={};self._folder_changes=set();self._folder_monitor=None
        self._startup_check_done=False
        self._folder_timer=QTimer(self);self._folder_timer.setSingleShot(True);self._folder_timer.setInterval(1000)
        self._folder_timer.timeout.connect(self._check_explorer_changes)
        QTimer.singleShot(1500,self._check_explorer_changes)

        # O carregamento dos modelos ONNX (~1-2s) é custoso; disparamos
        # em segundo plano assim que a janela abre, para que o primeiro
        # clique do usuário não trave a UI esperando o modelo carregar.
        self._warm_up_engine()

    # ------------------------------------------------------------------
    # Construção da UI
    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QWidget(); central.setObjectName('Page')
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(22, 18, 22, 18); root.setSpacing(14)
        hero = QFrame(); hero.setObjectName('CompactHero');hero.setFixedHeight(48)
        hero.setToolTip('Acervo em Foco — Organize imagens. Encontre histórias.')
        hero_row = QHBoxLayout(hero); hero_row.setContentsMargins(8, 6, 8, 8)
        icon=brand_label('icone',32,32);icon.setFixedSize(32,32)
        hero_row.addWidget(icon);hero_row.setSpacing(10)
        brand = brand_label('nome',190,28); brand.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
        hero_row.addWidget(brand);hero_row.addStretch()
        edition = QLabel(current_profile().label)
        edition.setToolTip('Cache, históricos e configurações próprios desta edição.')
        from ui.theme import theme_selector
        self.theme_control=theme_selector(self)
        hero_row.addWidget(edition)
        badge = QLabel('Local  •  Cache persistente'); badge.setObjectName('LocalBadge')
        badge.setToolTip('Análises feitas neste computador. O cache fica salvo para as próximas verificações.')
        root.addWidget(hero)
        self.tabs = QTabWidget()
        self.search_page = QWidget(); self.search_page.setObjectName('Page')
        self.search_tabs = QTabWidget()
        self.search_tabs.setObjectName('SearchSubtabs')
        self.search_tabs.addTab(self.search_page, 'Nova busca')
        self.face_history_tab = FaceHistoryTab(self.face_history, defer_photos=True)
        self.search_tabs.addTab(self.face_history_tab, 'Rostos pesquisados')
        separator = QFrame()
        separator.setFixedSize(1, 12)
        separator.setStyleSheet('background: rgba(88,112,131,65); border: none;')
        self.search_tabs.tabBar().setTabButton(0, QTabBar.RightSide, separator)
        self.search_tabs.currentChanged.connect(lambda index: self.face_history_tab.reload() if index == 1 else None)
        self.tabs.addTab(self.search_tabs, 'Buscar fotos')
        self.folders_tab = FoldersTab(self.history)
        self.tabs.addTab(self.folders_tab, 'Pastas analisadas')
        self.folders_tab.inventory_requested.connect(self._request_inventory)
        self.folders_tab.folder_chosen.connect(self._use_history_folder)
        self.folders_tab.cache_start_btn.clicked.connect(self._start_cache)
        self.folders_tab.cache_requested.connect(self._start_cache)
        self.folders_tab.cache_pause_btn.clicked.connect(self._toggle_cache_pause)
        self.folders_tab.cache_stop_btn.clicked.connect(self._stop_cache)
        self.duplicates_tab = DuplicatesTab(os.path.join(os.path.dirname(CACHE_DB_PATH), 'duplicates.db'))
        self.tabs.addTab(self.duplicates_tab, 'Duplicidade')
        self.folders_tab.duplicate_requested.connect(self._use_duplicate_folder)
        from core.deletion_history import DeletionHistory
        from ui.deleted_photos_tab import DeletedPhotosTab
        self.deletion_history=DeletionHistory(os.path.join(os.path.dirname(CACHE_DB_PATH),'deletions.db'))
        self.deletion_history.import_previous(self.duplicates_tab.db)
        self.duplicates_tab.deletion_history=self.deletion_history
        self.deleted_photos_tab=DeletedPhotosTab(self.deletion_history,self)
        self.tabs.addTab(self.deleted_photos_tab,'Fotos excluídas')
        self.duplicates_tab.open_deleted.connect(lambda:self.tabs.setCurrentWidget(self.deleted_photos_tab))
        from ui.auxiliary_cleanup import AuxiliaryCleanup
        self.auxiliary_tab=AuxiliaryCleanup(self)
        self.tabs.addTab(self.auxiliary_tab,'Arquivos auxiliares')
        self.utility_tabs=QTabBar()
        self.utility_tabs.setExpanding(False)
        self.utility_tabs.setDrawBase(False)
        self.utility_tabs.addTab('Arquivos auxiliares')
        self.utility_tabs.addTab('Fotos excluídas')
        self.tabs.setCornerWidget(self.utility_tabs,Qt.TopRightCorner)
        self.tabs.setTabVisible(3,False);self.tabs.setTabVisible(4,False)
        self.utility_tabs.setCurrentIndex(-1)
        self.utility_tabs.tabBarClicked.connect(lambda index:self.tabs.setCurrentIndex(4-index))
        self.tabs.currentChanged.connect(lambda index:self.utility_tabs.setCurrentIndex(4-index if index in (3,4) else -1))
        self.utility_tabs.setObjectName('UtilityTabs')
        def utility_style(index):
            self.utility_tabs.setProperty('inactive',index not in (3,4))
            self.utility_tabs.style().unpolish(self.utility_tabs);self.utility_tabs.style().polish(self.utility_tabs)
        utility_style(self.tabs.currentIndex())
        self.tabs.currentChanged.connect(utility_style)
        for index,tip in enumerate([
            'Encontre fotos de uma pessoa usando um rosto de referência e a similaridade mínima.',
            'Acompanhe as pastas do acervo, o progresso da análise e a coleta de cache.',
            'Compare fotos semelhantes ou idênticas e escolha as cópias que deseja enviar à Lixeira.',
            'Consulte as exclusões feitas pelo programa e restaure arquivos ainda disponíveis na Lixeira.',
            'Examina as pastas com fotos registradas no cache e reúne metadados auxiliares para revisão e limpeza. Não apaga fotos originais.'
        ]):self.tabs.setTabToolTip(index,tip)
        for index in range(2):self.utility_tabs.setTabToolTip(index,self.tabs.tabToolTip(4-index))
        self.authorities_tab = None
        if current_profile().key in ('dcta', 'pessoal'):
            from core.authorities import AuthorityStore
            from ui.authorities_tab import AuthoritiesTab
            store = AuthorityStore(os.path.join(os.path.dirname(CACHE_DB_PATH), 'authorities.db'))
            self.authorities_tab = AuthoritiesTab(store, self)
            index = self.tabs.addTab(self.authorities_tab, 'Seleção de Pessoas' if current_profile().key == 'pessoal' else 'Autoridades')
            self.tabs.setTabToolTip(index, 'Cadastre rostos, mantenha as fotos encontradas no catálogo e copie as escolhidas para outra pasta.')
            self.authorities_tab.busy_changed.connect(self._update_start_button_state)
        self.search_tabs.setTabToolTip(0,'Escolha um rosto e uma pasta para iniciar uma busca de fotos.')
        self.search_tabs.setTabToolTip(1,'Consulte os rostos já pesquisados e os resultados salvos.')
        self.duplicates_tab.views.setTabToolTip(0,'Visualize e compare as fotos encontradas como semelhantes ou duplicadas.')
        self.duplicates_tab.views.setTabToolTip(1,'Consulte o resultado de leitura de cada imagem, incluindo falhas.')
        self.tabs.currentChanged.connect(lambda _:self.deleted_photos_tab.refresh() if self.tabs.currentWidget() is self.deleted_photos_tab else None)
        self.duplicates_tab.busy_changed.connect(self._update_start_button_state)
        root.addWidget(self.tabs, 1)
        activity_row=QHBoxLayout()
        from ui.stable_status import StableStatusLabel
        self.operation_label=StableStatusLabel(2);self.operation_label.setText('Pronto. Nenhuma coleta de cache em andamento.')
        activity_row.addWidget(self.operation_label,1)
        self.notifications=[]
        self._read_notifications=[]
        from PySide6.QtWidgets import QToolButton
        self.notification_button=QToolButton();self.notification_button.setObjectName('NotificationBell')
        self.notification_button.setAccessibleName('Notificações');self.notification_button.setFixedSize(42,36)
        from PySide6.QtCore import QSize
        self.notification_button.setIconSize(QSize(32,32))
        self.notification_button.clicked.connect(self._show_notifications)
        hero_row.insertWidget(hero_row.count()-1,self.notification_button)
        self.maintenance_button=QPushButton('Backup e atualizações')
        self.maintenance_button.clicked.connect(self._open_maintenance)
        hero_row.insertWidget(hero_row.count()-1,self.maintenance_button)
        self._update_notification_bell()
        root.addLayout(activity_row)
        from PySide6.QtWidgets import QApplication
        from PySide6.QtGui import QShortcut,QKeySequence
        from ui.diagnostic_log import show_log
        self.log_shortcut=QShortcut(QKeySequence('Ctrl+Shift+L'),self)
        self.log_shortcut.activated.connect(lambda:show_log(self))
        from ui.database_security_setup import show_setup
        self.security_shortcut=QShortcut(QKeySequence('Ctrl+Shift+S'),self)
        self.security_shortcut.activated.connect(lambda:show_setup(self))
        bus=getattr(QApplication.instance(),'notification_bus',None)
        if bus:bus.message.connect(self._notify)
        QApplication.instance().theme_controller.changed.connect(lambda _:self._update_notification_bell())
        self.inventory_panel=QGroupBox('Atualização do inventário');inventory_layout=QVBoxLayout(self.inventory_panel)
        from ui.stable_status import StableStatusLabel
        self.inventory_activity=StableStatusLabel(3);inventory_layout.addWidget(self.inventory_activity)
        inventory_row=QHBoxLayout();self.inventory_progress=QProgressBar();self.inventory_progress.setRange(0,0)
        self.inventory_stop=QPushButton('Parar atualização');self.inventory_stop.clicked.connect(self._stop_inventory)
        inventory_row.addWidget(self.inventory_progress,1);inventory_row.addWidget(self.inventory_stop);inventory_layout.addLayout(inventory_row)
        root.addWidget(self.inventory_panel);self.inventory_panel.hide()
        self.footer_progress=QProgressBar()
        self.footer_progress.setRange(0,100);self.footer_progress.setValue(0)
        self.footer_progress.setFormat('%p%');self.footer_progress.setAlignment(Qt.AlignCenter)
        self.footer_progress.setFixedHeight(22)
        self.footer_progress.setToolTip('Progresso da verificação de duplicidade: leitura das imagens (0–90%) e comparação (90–100%). Não representa uma estimativa de tempo.')
        self.footer_progress.hide();root.addWidget(self.footer_progress)
        self.duplicates_tab.progress_changed.connect(self.footer_progress.setValue)
        self.duplicates_tab.progress_changed.connect(lambda value:self._announce(f'Verificando duplicidade: {value}% da etapa de leitura/comparação.'))
        self.duplicates_tab.busy_changed.connect(self._sync_footer_progress)
        footer = QHBoxLayout();footer.setContentsMargins(0,0,0,0)
        footer_left=QVBoxLayout();footer_left.setSpacing(4)
        footer_left.addWidget(badge);footer_left.addWidget(self.theme_control,0,Qt.AlignLeft)
        footer.addLayout(footer_left);footer.addStretch()
        credit = QLabel('Desenvolvido por <b>Luiz Henrique Neves de Andrade</b>')
        credit.setObjectName('DeveloperCredit');credit.setWordWrap(True)
        credit.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        credit.setTextFormat(Qt.RichText)
        footer.addWidget(credit)
        root.addLayout(footer)
        search = QVBoxLayout(self.search_page); search.setContentsMargins(0, 0, 0, 0); search.setSpacing(10)
        settings = QHBoxLayout(); settings.setSpacing(14)
        ref_group = QGroupBox('Referência')
        ref_layout = QHBoxLayout(ref_group)
        from ui.photo_viewer import PhotoLabel, show_photo
        self.reference_photo_path=None
        self.ref_thumb = PhotoLabel('Rosto de\nreferência')
        self.ref_thumb.clicked.connect(lambda:show_photo(self.reference_photo_path,self))
        self.ref_thumb.setFixedSize(100,100); self.ref_thumb.setAlignment(Qt.AlignCenter)
        self.ref_thumb.setObjectName('Thumbnail')
        self.ref_status = QLabel('Selecione a pessoa que deseja encontrar.'); self.ref_status.setWordWrap(True)
        self.ref_status.setObjectName('Muted')
        self.load_btn = QPushButton('Selecionar rosto'); self.load_btn.setEnabled(False)
        self.load_btn.clicked.connect(self._on_load_reference)
        ref_text = QVBoxLayout(); ref_text.addWidget(self.ref_status); ref_text.addWidget(self.load_btn)
        ref_layout.addWidget(self.ref_thumb); ref_layout.addLayout(ref_text)
        settings.addWidget(ref_group, 1)
        cfg = QGroupBox('Onde buscar'); form = QVBoxLayout(cfg)
        self.folder_label = QLabel('Nenhuma pasta selecionada'); self.folder_label.setWordWrap(True)
        self.folder_btn = QPushButton('Escolher pasta'); self.folder_btn.clicked.connect(self._on_choose_folder)
        folder_row = QHBoxLayout(); folder_row.addWidget(self.folder_label,1); folder_row.addWidget(self.folder_btn)
        form.addLayout(folder_row)
        thr = QHBoxLayout(); thr.addWidget(QLabel('Similaridade mínima'))
        self.threshold_slider = QSlider(Qt.Horizontal); self.threshold_slider.setRange(20,80); self.threshold_slider.setValue(60)
        self.threshold_value_label = QLabel('60%')
        self.threshold_slider.valueChanged.connect(self._update_threshold_display)
        self._update_threshold_display(self.threshold_slider.value())
        thr.addWidget(self.threshold_slider,1); thr.addWidget(self.threshold_value_label)
        form.addLayout(thr); settings.addWidget(cfg, 2)
        search.addLayout(settings)
        controls = QHBoxLayout()
        self.start_btn = QPushButton('Iniciar busca'); self.start_btn.setObjectName('Primary'); self.start_btn.setEnabled(False)
        self.start_btn.clicked.connect(self._on_start_search)
        self.stop_btn = QPushButton('Parar'); self.stop_btn.setObjectName('Stop'); self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._on_stop_search)
        self.progress_bar = QProgressBar(); self.progress_bar.setRange(0,100); self.progress_bar.setValue(0)
        controls.addWidget(self.start_btn); controls.addWidget(self.stop_btn); controls.addWidget(self.progress_bar,1)
        search.addLayout(controls)
        self.status_label = QLabel('Preparando reconhecimento facial…'); self.status_label.setObjectName('Muted'); self.status_label.setWordWrap(True)
        search.addWidget(self.status_label)
        results_group = QGroupBox('Candidatos para conferência')
        results_layout = QVBoxLayout(results_group)
        self.result_count = QLabel('0 fotos encontradas'); self.result_count.setObjectName('Muted')
        from ui.search_export import SearchExport
        self.search_export=SearchExport(self)
        self.search_export.status.connect(self.status_label.setText)
        self.search_export.status.connect(lambda text:self._announce('Exportação de fotos: '+text))
        self.search_export.busy_changed.connect(self._update_start_button_state)
        results_header=QHBoxLayout();results_header.addWidget(self.result_count);results_header.addWidget(self.search_export,1)
        results_layout.addLayout(results_header)
        self.empty_label = QLabel('As fotos encontradas aparecerão aqui.\nSelecione uma referência e uma pasta para começar.')
        self.empty_label.setAlignment(Qt.AlignCenter); self.empty_label.setObjectName('Muted')
        result_area = QWidget()
        layers = QStackedLayout(result_area)
        layers.setContentsMargins(0,0,0,0)
        layers.setStackingMode(QStackedLayout.StackAll)
        backdrop = QWidget()
        backdrop.setAttribute(Qt.WA_TransparentForMouseEvents)
        backdrop_layout = QVBoxLayout(backdrop)
        backdrop_layout.setContentsMargins(20,20,20,20)
        backdrop_layout.addStretch()
        self.empty_brand = QWidget();self.empty_brand.setObjectName('EmptyBrandPanel')
        personal_brand_layout = QVBoxLayout(self.empty_brand)
        personal_brand_layout.setContentsMargins(20,14,20,14)
        personal_brand_layout.setSpacing(6)
        personal_brand_layout.addWidget(brand_label('icone',100,100),0,Qt.AlignCenter)
        personal_brand_layout.addWidget(brand_label('nome',190,28),0,Qt.AlignCenter)
        self.brand_opacity = QGraphicsOpacityEffect(self.empty_brand)
        self.brand_opacity.setOpacity(1.0)
        self.empty_brand.setGraphicsEffect(self.brand_opacity)
        backdrop_layout.addWidget(self.empty_brand,0,Qt.AlignCenter)
        backdrop_layout.addWidget(self.empty_label)
        backdrop_layout.addStretch()
        layers.addWidget(backdrop)
        self.results_list = QListWidget(); self.results_list.setSpacing(6)
        self.results_list.setStyleSheet('QListWidget { background: transparent; }')
        self.results_list.viewport().setAutoFillBackground(False)
        layers.addWidget(self.results_list)
        layers.setCurrentWidget(self.results_list)
        results_layout.addWidget(result_area,1)
        search.addWidget(results_group,1)

    def _update_threshold_display(self,value):
        self.threshold_value_label.setText(f'{value}%')
        score=f'{value/100:.2f}'.replace('.',',')
        explanation=(f'{value}% corresponde ao limite {score} usado pelo reconhecimento. '
            f'Serão mostradas fotos com pontuação de similaridade igual ou superior a {score}. '
            'A porcentagem é a pontuação multiplicada por 100, não uma probabilidade de identidade. '
            'Valores maiores tornam a busca mais exigente e podem deixar de encontrar algumas fotos, especialmente de perfil.')
        self.threshold_slider.setToolTip(explanation);self.threshold_value_label.setToolTip(explanation)

    def _start_cache(self,folder=None):
        if self._busy() or not self._engine_ready:
            return
        tab = self.folders_tab
        if not isinstance(folder,str):folder = tab.selected_folder()
        if not folder:
            folder = QFileDialog.getExistingDirectory(self, 'Escolha a pasta para coletar cache', tab.dialog_directory())
        if not folder:
            return
        if not os.path.isdir(folder):
            tab.cache_status.setText('A pasta selecionada não está disponível.');return
        if self._cache_running():
            from core.folder_history import path_key
            worker=self._cache_worker
            if path_key(folder)==path_key(worker.folder) and not worker._stop_requested:
                worker.resume();return
            # Finish the current file and save its snapshot before switching.
            # Reopening from persisted cache also handles overlapping folders safely.
            queue=[folder]
            pending=self._cache_queue+[worker.folder] if worker._stop_requested else [worker.folder]+self._cache_queue
            for path in pending:
                if path_key(path) not in {path_key(p) for p in queue}:queue.append(path)
            self._cache_queue=queue
            worker.stop()
            tab.cache_pause_btn.setEnabled(False)
            tab.cache_status.setText('Salvando progresso para priorizar a pasta selecionada…')
            return
        self._cache_worker = CacheWorker(folder, self.cache, self.history, self)
        self._announce('Coletando cache: '+folder,True)
        self._cache_paused = False
        tab.cache_folder_label.setText(folder)
        tab.cache_progress.setRange(0,0)
        tab.cache_status.setText('Preparando coleta…')
        tab.cache_pause_btn.setText('Pausar'); tab.cache_pause_btn.setEnabled(True)
        tab.cache_stop_btn.setEnabled(True)
        self._cache_worker.progress.connect(self._cache_progress)
        self._cache_worker.status.connect(tab.cache_status.setText)
        self._cache_worker.status.connect(lambda text:self._announce('Coleta de cache: '+text))
        self._cache_worker.error.connect(tab.cache_status.setText)
        self._cache_worker.paused.connect(self._cache_pause_changed)
        self._cache_worker.history_changed.connect(tab.reload)
        self._cache_worker.finished.connect(self._cache_finished)
        self._cache_worker.start()
        self._update_start_button_state()

    def _cache_progress(self, processed, total):
        tab = self.folders_tab
        tab.cache_progress.setRange(0, max(total,1)); tab.cache_progress.setValue(processed)
        if self._cache_worker._stop_requested:
            return
        tab.cache_status.setText(f'Coleta: {processed:,} de {total:,} imagens conferidas. Falhas: {self._cache_worker.failed_count}.')
        self._announce(f'Coletando cache: {processed:,}/{total:,} fotos; {len(self._cache_worker.reused)} reaproveitadas; {len(self._cache_worker.computed)} processadas agora; {self._cache_worker.failed_count} falhas.')

    def _toggle_cache_pause(self):
        if not self._cache_worker or not self._cache_worker.isRunning():
            return
        if self._cache_paused:
            self._cache_worker.resume()
        else:
            self._cache_worker.pause()
            self.folders_tab.cache_status.setText('Pausando após o arquivo em processamento…')
        self.folders_tab.cache_pause_btn.setEnabled(False)

    def _cache_pause_changed(self, paused):
        self._cache_paused = paused
        if self._cache_worker._stop_requested:
            return
        self.folders_tab.cache_pause_btn.setText('Continuar' if paused else 'Pausar')
        self.folders_tab.cache_pause_btn.setEnabled(True)
        self.folders_tab.cache_status.setText('Coleta pausada. O cache já gravado está preservado.' if paused else 'Continuando coleta…')

    def _stop_cache(self):
        self._cache_queue.clear()
        if self._cache_worker and self._cache_worker.isRunning():
            self._cache_worker.stop()
            self.folders_tab.cache_pause_btn.setEnabled(False)
            self.folders_tab.cache_stop_btn.setEnabled(False)
            self.folders_tab.cache_status.setText('Parando após o arquivo em processamento. Salvando progresso…')

    def _cache_finished(self):
        worker = self._cache_worker
        tab = self.folders_tab
        tab.cache_pause_btn.setEnabled(False); tab.cache_pause_btn.setText('Pausar')
        tab.cache_stop_btn.setEnabled(False)
        tab.cache_progress.setRange(0,max(worker.total,1)); tab.cache_progress.setValue(worker.processed)
        state = 'Coleta parada' if worker._stop_requested else ('Coleta finalizada com falhas' if worker.failure_message else 'Coleta concluída')
        detail = f' Última falha: {worker.failure_message}' if worker.failure_message else ''
        tab.cache_status.setText(f'{state}. {worker.processed:,}/{worker.total:,} imagens conferidas; {worker.failed_count} falhas. Cache preservado.' + detail)
        self._announce(tab.cache_status.text()+f' Reaproveitadas: {len(worker.reused)}. Processadas agora: {len(worker.computed)}.',True)
        tab.reload()
        self._update_start_button_state()
        self._resume_queued_cache()

    def _resume_queued_cache(self):
        if self._cache_running() or self._busy():return
        while self._cache_queue:
            folder=self._cache_queue.pop(0)
            if os.path.isdir(folder):
                self._start_cache(folder);return
            self.folders_tab.cache_status.setText('Pasta aguardando retomada indisponível: '+folder)

    def _request_inventory(self,roots):
        if not roots or self._busy() or self._cache_running():return
        self._start_inventory(roots)

    def _start_inventory(self, roots):
        if not roots or self._busy() or self._cache_running():
            return
        self._inventory_worker = InventoryWorker(roots, self.cache, self.history, self, directories_only=False)
        self._announce('Contabilizando fotos e validando o cache existente. Não executa reconhecimento facial.',True)
        self.inventory_panel.show();self.inventory_progress.setRange(0,0);self.inventory_stop.setEnabled(True);self.inventory_stop.setText('Parar atualização')
        self.inventory_activity.setText('Preparando atualização do inventário…\n'+str(roots[0])+'\nA quantidade total será conhecida ao concluir a leitura das pastas.')
        self._inventory_worker.activity.connect(self._inventory_activity)
        self._inventory_worker.status.connect(self.folders_tab.message.setText)
        self._inventory_worker.error.connect(self.folders_tab.message.setText)
        self._inventory_worker.updated.connect(self.folders_tab.reload)
        self._inventory_worker.finished.connect(self._inventory_finished)
        self._inventory_worker.start()
        self._update_start_button_state()

    def _inventory_activity(self,stage,path,count,index,total):
        if self._inventory_worker.isInterruptionRequested():return
        scope=f' — pasta selecionada {index} de {total}' if index else ''
        unit='pastas verificadas' if self._inventory_worker.directories_only else 'imagens conferidas'
        self.inventory_activity.setText(f'{stage}{scope}\n{path}\n{count:,} {unit}. Total ainda em levantamento.')
        self._announce(f'{stage}: {path} — {count:,} {unit}.')
        self.inventory_activity.setToolTip(path)

    def _stop_inventory(self):
        if self._inventory_worker and self._inventory_worker.isRunning():
            self._inventory_worker.requestInterruption();self.inventory_stop.setEnabled(False)
            self.inventory_activity.setText('Parando após a operação atual… O inventário parcial não substituirá o anterior.')
        else:self.inventory_panel.hide()

    def _check_explorer_changes(self):
        if getattr(self,'_closing',False) or self._startup_check_done:return
        if self._busy() or self._cache_running():
            self._folder_timer.start();return
        if self._folder_monitor and self._folder_monitor.isRunning():return
        self._startup_check_done=True
        self._folder_timer.stop()
        from workers.folder_monitor import FolderMonitor
        self._folder_monitor=FolderMonitor(self.history,self._folder_signatures,self,tracked_only=True)
        self._folder_monitor.activity.connect(lambda text:self._announce(text) if not self._busy() and not self._cache_running() else None)
        self._folder_monitor.summary.connect(self._monitor_summary)
        self._folder_monitor.checked.connect(self._explorer_changes_found)
        self._folder_monitor.finished.connect(self._resume_initial_inventory)
        self._folder_monitor.start()

    def _explorer_changes_found(self,signatures,roots):
        self._folder_signatures=signatures;self._folder_changes.update(roots)
        if self.history.discovered_keys() and not self._folder_changes:
            tracked,_=self.history.records()
            self._folder_changes.update(row[1] for row in tracked)
        self.folders_tab.reload()

    def _resume_initial_inventory(self):
        # Startup detection only informs. No inventory, cache collection or face search.
        if getattr(self,'_closing',False) or self._busy() or self._cache_running():return
        if not self._folder_changes or getattr(self,'_startup_notice_shown',False):return
        self._startup_notice_shown=True
        self._folder_changes.clear()
        notice=QMessageBox(self)
        notice.setWindowTitle('Alterações no acervo')
        notice.setIcon(QMessageBox.Information)
        notice.setText('Foram detectadas pastas novas ou alterações no acervo que podem incluir novas fotos.')
        notice.setInformativeText('Nenhuma busca ou coleta foi iniciada. Você decide quando atualizar o inventário, coletar o cache ou buscar fotos.')
        review=notice.addButton('Ver pastas acompanhadas',QMessageBox.ActionRole)
        later=notice.addButton('Agora não',QMessageBox.RejectRole)
        notice.setDefaultButton(later)
        notice.buttonClicked.connect(lambda button:self.tabs.setCurrentWidget(self.folders_tab) if button is review else None)
        self._startup_notice=notice
        notice.open()

    def _inventory_finished(self):
        self.folders_tab.reload()
        summary=self._inventory_worker.summary
        self._announce(summary,True)
        self.folders_tab.message.setText(summary)
        self.inventory_activity.setText(summary+'\nPastas indisponíveis ou com falhas são indicadas na tabela.')
        self.inventory_progress.setRange(0,1);self.inventory_progress.setValue(0 if self._inventory_worker.isInterruptionRequested() else 1)
        self.inventory_progress.setFormat('Interrompido' if self._inventory_worker.isInterruptionRequested() else 'Finalizado')
        self.inventory_stop.setText('Fechar acompanhamento');self.inventory_stop.setEnabled(True)
        self._update_start_button_state()

    def _announce(self,message,save=False):
        self.operation_label.setText(message);self.operation_label.setToolTip(message)
        if save:self._notify(message)

    def _monitor_summary(self,message):
        # Directory discoveries and errors emit dedicated notifications from the worker.
        if not self._busy() and not self._cache_running():self._announce(message)

    def _notify(self,message):
        from datetime import datetime
        if self.notifications and self.notifications[-1][1]==message:return
        self.notifications.append((datetime.now().strftime('%H:%M:%S'),str(message)))
        self.notifications=self.notifications[-100:]
        self._update_notification_bell()

    def _update_notification_bell(self):
        from ui.notification_icon import bell_icon
        people=self.authorities_tab.history.notifications() if self.authorities_tab is not None else []
        count=sum(not any(entry is read for read in self._read_notifications) for entry in self.notifications)+len(people)
        self.notification_button.setIcon(bell_icon(count))
        panel=getattr(self,'_notifications_panel',None)
        if panel is not None and panel.isVisible():panel.refresh()
        self.notification_button.setAccessibleName(f'Notificações: {count} não lidas')
        self.notification_button.setToolTip(f'Notificações não lidas ({count})'+(' — '+self.notifications[-1][1] if self.notifications else ''))

    def _show_notifications(self):
        from ui.notifications_panel import NotificationsPanel
        panel=getattr(self,'_notifications_panel',None)
        if panel is None:
            panel=NotificationsPanel(self)
            self._notifications_panel=panel
        if panel.isVisible():panel.hide()
        else:panel.refresh();panel.reposition();panel.show();panel.raise_()

    def _use_duplicate_folder(self,path):
        if self._busy() or not os.path.isdir(path):return
        remember_folder(path)
        self.duplicates_tab.folder=path
        self.duplicates_tab.folder_label.setText(os.path.basename(os.path.normpath(path)) or path)
        self.duplicates_tab.folder_label.setToolTip(path)
        self.duplicates_tab.status.setText('Pasta selecionada. Ajuste a similaridade e clique em Verificar duplicidade.')
        self.duplicates_tab.update_controls()
        self.tabs.setCurrentWidget(self.duplicates_tab)

    def _use_history_folder(self, path):
        if self._busy():
            return
        self.target_folder = path
        self.folder_label.setText(path)
        self.tabs.setCurrentIndex(0)
        self.search_tabs.setCurrentIndex(0)
        self._update_start_button_state()

    def _cache_running(self):
        return bool(self._cache_worker and self._cache_worker.isRunning())

    def _busy(self):
        if getattr(self,'authorities_tab',None) and self.authorities_tab.active():return True
        if hasattr(self,'search_export') and self.search_export.running():return True
        return bool(self.duplicates_tab.running() or
                    (self.worker and self.worker.isRunning()) or
                    (self._inventory_worker and self._inventory_worker.isRunning()))

    def _warm_up_engine(self):
        # Carrega o FaceEngine (singleton) numa QThread simples e
        # descartável só para não bloquear o primeiro clique do usuário.
        from PySide6.QtCore import QThread

        class _WarmUpThread(QThread):
            failed = Signal(str)
            def run(self_inner):
                try:
                    FaceEngine.instance()
                except Exception as exc:
                    self_inner.failed.emit(str(exc))
        self._warmup_error = None

        self._warmup_thread = _WarmUpThread()
        self._warmup_thread.failed.connect(self._on_engine_error)
        self._warmup_thread.finished.connect(self._on_engine_ready)
        self._warmup_thread.start()

    def _on_engine_error(self, message):
        from core.diagnostics import program_error
        program_error(message,'Carregamento do reconhecimento')
        self._warmup_error = message
        self.status_label.setText('Não foi possível carregar o reconhecimento: ' + message)

    def _on_engine_ready(self):
        self._engine_ready = self._warmup_error is None
        if self._engine_ready:
            self.status_label.setText('Pronto. Selecione um rosto e uma pasta.')
        self._update_start_button_state()

    # ------------------------------------------------------------------
    # Passo 1: referência
    # ------------------------------------------------------------------
    def _on_load_reference(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Selecione a foto de referência",
            initial_directory(self._last_reference_directory, self.target_folder,
                              self.folders_tab.dialog_directory()),
            "Imagens (*.jpg *.jpeg *.png *.bmp *.webp *.heic *.heif *.hif)"
        )
        if not path:
            return
        self._last_reference_directory = os.path.dirname(path)

        bgr = load_bgr_image(path)
        if bgr is None:
            QMessageBox.critical(self, "Erro", "Não foi possível carregar a imagem selecionada.")
            return

        dialog = CropDialog(bgr, parent=self)
        if dialog.exec() == QDialog.Accepted and dialog.selected_embedding is not None:
            self.reference_embedding = dialog.selected_embedding
            self.reference_photo_path=path
            self.reference_pose = dialog.selected_pose

            pixmap = bgr_to_qpixmap(dialog.selected_crop).scaled(
                100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.ref_thumb.setPixmap(pixmap)
            self.ref_status.setText("Rosto de referência definido. Confira a miniatura ao lado.")
            self._update_start_button_state()

    # ------------------------------------------------------------------
    # Passo 2: pasta alvo
    # ------------------------------------------------------------------
    def _on_choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Escolha a pasta da galeria",
            initial_directory(last_folder(), self.target_folder, self.folders_tab.dialog_directory()))
        if folder:
            remember_folder(folder)
            self.target_folder = folder
            self.folder_label.setText(folder)
            self._update_start_button_state()

    def _sync_footer_progress(self):
        active=self.duplicates_tab.running()
        if active and self.footer_progress.isHidden():self.footer_progress.setValue(0)
        self.footer_progress.setVisible(active)

    def _update_start_button_state(self):
        busy = self._busy()
        self.start_btn.setEnabled(self._engine_ready and self.reference_embedding is not None
                                  and self.target_folder is not None and not busy)
        self.load_btn.setEnabled(self._engine_ready and not busy)
        self.folder_btn.setEnabled(not busy)
        self.threshold_slider.setEnabled(not busy)
        self.duplicates_tab.set_busy(busy and not self.duplicates_tab.running())
        self.duplicates_tab.file_operations_busy=self._cache_running()
        self.duplicates_tab.update_controls()
        self.folders_tab.set_busy(busy)
        self.folders_tab.refresh_btn.setEnabled(not busy and not self._cache_running())
        self.folders_tab.add_btn.setEnabled(not busy and not self._cache_running())
        self.folders_tab.cache_start_btn.setEnabled(self._engine_ready and not busy and not self._cache_running())
        self.folders_tab.cache_priority_enabled=self._engine_ready and not busy
        if self.authorities_tab is not None:self.authorities_tab.controls()
        if getattr(self,'_folder_changes',None) and not self._cache_running() and not busy:
            QTimer.singleShot(0,self._resume_initial_inventory)
        if self._cache_queue and not self._cache_running() and not busy:
            QTimer.singleShot(0,self._resume_queued_cache)

    # ------------------------------------------------------------------
    # Passo 3: execução da busca (assíncrona)
    # ------------------------------------------------------------------
    def _on_start_search(self):
        if self.reference_embedding is None or self.target_folder is None:
            return

        if self._busy() or not self._engine_ready:
            return
        self.brand_opacity.setOpacity(1.0)
        self.search_export.reset()
        self.results_list.clear()
        self.result_count.setText('0 fotos encontradas')
        self.empty_label.setText('Buscando candidatos no seu acervo…')
        self.empty_label.show()
        self.progress_bar.setValue(0)
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self._search_start_time = time.monotonic()

        threshold = self.threshold_slider.value() / 100.0
        portrait = QBuffer()
        portrait.open(QIODevice.WriteOnly)
        pixmap = self.ref_thumb.pixmap()
        if pixmap and not pixmap.isNull():
            pixmap.save(portrait, 'PNG')
        self._history_face = self.face_history.start(self.reference_embedding, bytes(portrait.data()), self.target_folder)
        portrait.close()

        self.worker = ScanWorker(
            folder=self.target_folder,
            query_embedding=self.reference_embedding,
            threshold=threshold,
            cache=self.cache,
            history=None if self._cache_running() else self.history,
        )
        # Conexões via sinal/slot: entregues com segurança na thread da
        # UI mesmo o worker rodando em outra thread (queued connection
        # automática do Qt quando emissor e receptor vivem em threads
        # diferentes).
        self.worker.match_found.connect(self._on_match_found)
        self.worker.progress.connect(self._on_progress)
        self.worker.status.connect(self.status_label.setText)
        self.worker.status.connect(lambda text:self._announce('Busca de fotos: '+text))
        self.worker.finished.connect(self._on_search_finished)
        self.worker.error.connect(self._on_search_error)
        self.worker.history_changed.connect(self.folders_tab.reload)
        self.worker.start()
        self._update_start_button_state()

    def _on_stop_search(self):
        if self.worker is not None:
            self.worker.stop()
            self.status_label.setText("Cancelando...")
        self.stop_btn.setEnabled(False)

    def _on_match_found(self, path: str, score: float, pose: str):
        if self._history_face:
            self.face_history.add(self._history_face, path, score, pose)
        # Inserção incremental: a foto aparece na lista assim que é
        # encontrada, sem esperar o fim da varredura completa.
        item_widget = ResultItemWidget(path, score, pose)
        item_widget.gallery_provider = lambda: [self.results_list.itemWidget(self.results_list.item(i)).path for i in range(self.results_list.count())]
        self.search_export.add(path,score,pose,item_widget.export_check)
        list_item = QListWidgetItem()
        list_item.setSizeHint(item_widget.sizeHint())
        self.results_list.addItem(list_item)
        self.results_list.setItemWidget(list_item, item_widget)
        self.brand_opacity.setOpacity(0.30)
        self.empty_label.hide()
        self.result_count.setText(f'{self.results_list.count()} fotos encontradas')

    def _on_progress(self, processed: int, total: int):
        if total > 0:
            self.progress_bar.setMaximum(total)
            self.progress_bar.setValue(processed)
        
        eta_str = ""
        if processed >= 10 and total > processed:
            elapsed = time.monotonic() - getattr(self, '_search_start_time', time.monotonic())
            eta_seconds = (total - processed) * (elapsed / processed)
            h, remainder = divmod(int(eta_seconds), 3600)
            m, seconds = divmod(remainder, 60)
            eta_str = f" - Estimativa: {h}h {m:02d}min {seconds:02d}s"

        self.status_label.setText(f"Analisando {processed}/{total} imagens{eta_str}...")

    def _on_search_finished(self):
        self.search_export.finish()
        self._update_start_button_state()
        self.stop_btn.setEnabled(False)
        count = self.results_list.count()
        state = "Busca cancelada" if self.worker._stop_requested else "Busca concluída"
        if self.worker.failure_message:
            state += f" — falhas: {self.worker.failed_count}; {self.worker.failure_message}"
        self.status_label.setText(f"{state}. {count} candidato(s) encontrado(s).")
        if self._history_face:
            self.face_history.finish(self._history_face, state)
            self._history_face = None
            self.face_history_tab.reload()
        self.brand_opacity.setOpacity(0.30 if count else 1.0)
        if not count:
            self.empty_label.setText('Nenhum candidato nesta busca. Confira a referência e o limite de similaridade.')
        self.folders_tab.reload()

    def _on_search_error(self, message: str):
        self._update_start_button_state()
        self.stop_btn.setEnabled(False)
        QMessageBox.critical(self, "Erro durante a busca", message)

    def _open_maintenance(self):
        # Do not let closeEvent cancel work just to enter maintenance.
        running=self._busy() or self._warmup_thread.isRunning() or self.auxiliary_tab.running()
        running=running or bool(getattr(self,'startup_updates',None) and self.startup_updates.running())
        running=running or self.face_history_tab.copying() or self.deleted_photos_tab.refreshing() or bool(self.deleted_photos_tab.pending)
        running=running or any(w and w.isRunning() for w in (self._cache_worker,self._folder_monitor))
        popup=self.folders_tab.extension_popup
        running=running or bool(popup and popup.running())
        if running:
            QMessageBox.information(self,'Operação em andamento','Aguarde a operação terminar antes de abrir backup e atualizações.');return
        if QMessageBox.question(self,'Backup e atualizações','Fechar esta edição e abrir a área de manutenção?',
                                QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        if self.close():
            import subprocess,sys
            from core.signed_updates import install_root
            subprocess.Popen([sys.executable,str(install_root()/'main.py'),'--maintenance'],cwd=install_root(),
                             env=os.environ.copy(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))

    def closeEvent(self, event):
        if getattr(self,'startup_updates',None) and self.startup_updates.running():
            self.status_label.setText('Concluindo a consulta ou instalação da atualização. Aguarde antes de fechar.')
            event.ignore();return
        if self.authorities_tab is not None:
            self.authorities_tab.cancel_pending()
        extension_popup=self.folders_tab.extension_popup
        if extension_popup and extension_popup.running():
            extension_popup.stop();event.ignore();return
        if self.authorities_tab is not None:
            if self.authorities_tab.active():
                self.authorities_tab.stop_scan();self.authorities_tab.cancel_copy();event.ignore();return
            if self.authorities_tab.stop_previews():
                event.ignore();return
        if self._folder_monitor and self._folder_monitor.isRunning():
            self._folder_monitor.requestInterruption();event.ignore();return
        if self.auxiliary_tab.running():
            self.auxiliary_tab.stop_scan();event.ignore();return
        self._cache_queue.clear()
        if self.search_export.running():
            self.search_export.cancel();event.ignore();return
        if self.deleted_photos_tab.refreshing():
            self.deleted_photos_tab.status.setText('Aguarde a consulta da Lixeira terminar antes de fechar.');event.ignore();return
        if self.deleted_photos_tab.pending:
            self.deleted_photos_tab.status.setText('Aguarde a confirmação da restauração antes de fechar.')
            event.ignore();return
        if self.face_history_tab.copying():
            self.face_history_tab.cancel_copy()
            event.ignore()
            return
        if self.face_history_tab.stop_previews():
            self.status_label.setText('Finalizando prévias do histórico. Aguarde antes de fechar.')
            event.ignore()
            return
        if self.duplicates_tab.running():
            self.duplicates_tab.stop_scan()
            event.ignore()
            return
        if self._cache_worker is not None and self._cache_worker.isRunning():
            self._stop_cache()
            event.ignore()
            return
        if self.worker is not None and self.worker.isRunning():
            self.worker.stop()
            self.status_label.setText("Cancelando; aguarde o processamento atual antes de fechar.")
            event.ignore()
            return
        if self._warmup_thread.isRunning():
            self.status_label.setText("Aguarde o carregamento dos modelos antes de fechar.")
            event.ignore()
            return
        if self._inventory_worker is not None and self._inventory_worker.isRunning():
            self._inventory_worker.requestInterruption()
            self.folders_tab.message.setText('Interrompendo conferência. Aguarde antes de fechar.')
            event.ignore()
            return
        self.duplicates_tab.db.close()
        self._closing=True
        self._folder_timer.stop()
        self.deletion_history.db.close()
        self.face_history.db.close()
        if self.authorities_tab is not None:self.authorities_tab.history.db.close()
        self.cache.close()
        self.history.close()
        if extension_popup:extension_popup.db.close()
        super().closeEvent(event)
