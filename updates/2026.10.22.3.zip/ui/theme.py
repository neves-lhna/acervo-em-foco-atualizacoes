"""Shared desktop theme, following Windows at every launch."""
from PySide6.QtGui import QColor, QPalette, QFont

from pathlib import Path
from PySide6.QtCore import QTimer, QObject, QEvent, Qt, QVariantAnimation, QEasingCurve
from PySide6.QtWidgets import QLabel, QCheckBox

THEME_PATH = Path(__file__).with_suffix('.qss')
STYLE = THEME_PATH.read_text(encoding='utf-8')


class TooltipWrapping(QObject):
    """Constrain native Qt tooltips, including dynamically created table tips."""
    def eventFilter(self, widget, event):
        if event.type() == QEvent.Show and isinstance(widget, QLabel) and widget.windowType() == Qt.ToolTip:
            screen = widget.screen().availableGeometry()
            widget.setMaximumWidth(min(440, max(120, screen.width() - 32)))
            widget.setWordWrap(True)
            widget.adjustSize()
            widget.move(max(screen.left(), min(widget.x(), screen.right()-widget.width()+1)),
                        max(screen.top(), min(widget.y(), screen.bottom()-widget.height()+1)))
        return False



def theme_settings():
    from PySide6.QtCore import QSettings
    from core.app_profile import current_profile
    return QSettings('AcervoEmFoco', current_profile().settings_name)


def is_dark():
    from PySide6.QtWidgets import QApplication
    app=QApplication.instance()
    return bool(app and app.property('darkTheme'))


def native_title(widget, dark):
    import sys
    if sys.platform!='win32' or not widget.isWindow():return
    import ctypes
    from ctypes import wintypes
    try:
        fn=ctypes.windll.dwmapi.DwmSetWindowAttribute
        fn.argtypes=[wintypes.HWND,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD]
        value=ctypes.c_int(dark)
        fn(int(widget.winId()),20,ctypes.byref(value),ctypes.sizeof(value))
    except (OSError,AttributeError):pass


class ThemeController(QObject):
    from PySide6.QtCore import Signal
    changed=Signal(str)

    def __init__(self,app):
        super().__init__(app);self.app=app
        self.mode='system'
        app.styleHints().colorSchemeChanged.connect(lambda *_:self.apply() if self.mode=='system' else None)
        app.installEventFilter(self)

    def eventFilter(self,widget,event):
        from PySide6.QtWidgets import QWidget
        if event.type()==QEvent.Show and isinstance(widget,QWidget) and widget.isWindow():
            native_title(widget,is_dark())
        return False

    def select(self,mode):
        if mode not in ('light','dark','system'):raise ValueError(mode)
        self.mode=mode
        self.apply()

    def apply(self):
        dark=self.mode=='dark' or (self.mode=='system' and self.app.styleHints().colorScheme()==Qt.ColorScheme.Dark)
        self.app.setProperty('darkTheme',dark)
        palette=QPalette()
        colors={QPalette.Window:('#f4f6f8','#191b1f'),QPalette.WindowText:('#21364a','#e8edf2'),
            QPalette.Base:('#ffffff','#23262b'),QPalette.AlternateBase:('#f5f8fa','#272c32'),
            QPalette.Text:('#21364a','#e8edf2'),QPalette.Button:('#ffffff','#2d3137'),
            QPalette.ButtonText:('#21364a','#e8edf2'),QPalette.Highlight:('#d9eee8','#174f50'),
            QPalette.HighlightedText:('#163a35','#ffffff'),QPalette.ToolTipBase:('#18364b','#303942'),
            QPalette.ToolTipText:('#ffffff','#ffffff'),QPalette.Link:('#087e70','#50d0bc')}
        for role,pair in colors.items():palette.setColor(role,QColor(pair[int(dark)]))
        for role in (QPalette.WindowText,QPalette.Text,QPalette.ButtonText):
            palette.setColor(QPalette.Disabled,role,QColor('#82909d' if dark else '#8e9eac'))
        self.app.setPalette(palette)
        path=THEME_PATH.with_name('theme_dark.qss') if dark else THEME_PATH
        self.app.setStyleSheet(path.read_text(encoding='utf-8'))
        for widget in self.app.topLevelWidgets():native_title(widget,dark);widget.update()
        self.changed.emit(self.mode)


def apply_theme(app):
    if not hasattr(app,'_tooltip_wrapping'):
        app._tooltip_wrapping=TooltipWrapping(app);app.installEventFilter(app._tooltip_wrapping)
    app.setStyle('Fusion');app.setFont(QFont('Segoe UI',10))
    if not hasattr(app,'theme_controller'):app.theme_controller=ThemeController(app)
    app.theme_controller.apply()


class ThemeSwitch(QCheckBox):
    """Keyboard-accessible switch; painted symbols avoid emoji/font differences."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('ThemeSwitch')
        self.setAccessibleName('Tema escuro')
        self.setFixedSize(106, 30)
        self.setCursor(Qt.PointingHandCursor)
        from PySide6.QtWidgets import QApplication
        self._position = 1.0 if is_dark() else 0.0
        self._motion = QVariantAnimation(self)
        self._motion.setDuration(180)
        self._motion.setEasingCurve(QEasingCurve.InOutCubic)
        self._motion.valueChanged.connect(self._move_thumb)
        self.controller = QApplication.instance().theme_controller
        self.toggled.connect(lambda checked: self.controller.select('dark' if checked else 'light'))
        self.controller.changed.connect(self.refresh)
        self.refresh()

    def _move_thumb(self, value):
        self._position = float(value)
        self.update()

    def refresh(self, *_):
        target = 1.0 if is_dark() else 0.0
        self._motion.stop()
        if self.isVisible() and self._position != target:
            self._motion.setStartValue(self._position)
            self._motion.setEndValue(target)
            self._motion.start()
        else:
            self._position = target
        self.blockSignals(True)
        self.setChecked(is_dark())
        self.blockSignals(False)
        self.setToolTip('Tema escuro' if is_dark() else 'Tema claro')
        self.setAccessibleDescription('Lâmpada: claro. Lua: escuro. Ao abrir, acompanha o Windows.')
        self.update()

    def hitButton(self, pos):
        return self.rect().contains(pos)

    def paintEvent(self, event):
        from PySide6.QtGui import QPainter, QPen, QPainterPath
        from PySide6.QtCore import QRectF
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        amber = QColor('#f59b18')
        muted = self.palette().color(QPalette.WindowText)
        painter.setPen(QPen(amber if not self.isChecked() else muted, 1.7))
        painter.setBrush(Qt.NoBrush)
        # Light bulb and base.
        painter.drawEllipse(QRectF(5, 4, 13, 14))
        painter.drawLine(9, 18, 9, 21); painter.drawLine(15, 18, 15, 21)
        painter.drawLine(9, 21, 15, 21); painter.drawLine(10, 24, 14, 24)
        painter.setPen(Qt.NoPen)
        painter.setBrush(amber if self.isChecked() else QColor('#82909d'))
        painter.drawRoundedRect(QRectF(30, 5, 44, 20), 10, 10)
        painter.setBrush(QColor('#ffffff'))
        painter.drawEllipse(QRectF(33 + 22 * self._position, 8, 14, 14))
        # Crescent moon, drawn without assuming the parent's background color.
        moon = QPainterPath(); moon.addEllipse(QRectF(84, 5, 18, 18))
        cutout = QPainterPath(); cutout.addEllipse(QRectF(90, 1, 17, 18))
        painter.setBrush(amber if self.isChecked() else muted)
        painter.drawPath(moon.subtracted(cutout))


def theme_selector(parent=None):
    return ThemeSwitch(parent)


def watch_theme(app):
    """Reload changed theme files without overriding the selected mode."""
    timer=QTimer(app);timer.setInterval(1000)
    paths=[THEME_PATH,THEME_PATH.with_name('theme_dark.qss')]
    last=[tuple(p.stat().st_mtime_ns for p in paths)]
    def refresh():
        try:current=tuple(p.stat().st_mtime_ns for p in paths)
        except OSError:return
        if current!=last[0]:last[0]=current;app.theme_controller.apply()
    timer.timeout.connect(refresh);timer.start();app._theme_timer=timer
