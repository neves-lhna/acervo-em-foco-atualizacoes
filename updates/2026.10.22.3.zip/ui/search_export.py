import os
from PySide6.QtCore import Qt,Signal
from PySide6.QtWidgets import QWidget,QHBoxLayout,QVBoxLayout,QCheckBox,QPushButton
from ui.export_dialog import ExportDialog


class SearchExport(QWidget):
    busy_changed=Signal()
    status=Signal(str)
    def __init__(self,parent=None):
        super().__init__(parent);self.rows={};self.boxes={};self.formats={};self.ready=False;self.dialog=None
        self.layout=QVBoxLayout(self);self.layout.setContentsMargins(0,0,0,0)
        self.options=QHBoxLayout();self.layout.addLayout(self.options);
        actions=QHBoxLayout();self.layout.addLayout(actions)
        self.select_all=QPushButton('Selecionar todas');self.clear_all=QPushButton('Desmarcar todas')
        self.select_all.clicked.connect(lambda:self.mark_all(True));self.clear_all.clicked.connect(lambda:self.mark_all(False))
        actions.addWidget(self.select_all);actions.addWidget(self.clear_all);actions.addStretch()
        self.copy=QPushButton('Exportar selecionadas (0)');self.copy.clicked.connect(self.export);actions.addWidget(self.copy)
        self.copy.setToolTip('Escolha a pasta de destino e mantenha os formatos originais ou converta para JPG. Os originais serão preservados.')
        self.sync()

    def running(self):return self.dialog is not None

    def mark_all(self,checked):
        if not self.ready or self.running():return
        for box in self.boxes.values():
            box.blockSignals(True);box.setChecked(checked);box.blockSignals(False)
        self.sync()

    def reset(self):
        self.rows={};self.boxes={};self.ready=False
        for box in self.formats.values():box.deleteLater();self.options.removeWidget(box)
        self.formats={};self.sync()

    def add(self,path,score,pose,box):
        try:st=os.stat(path)
        except OSError:return
        self.rows[path]=(path,score,pose,st.st_mtime_ns,st.st_size)
        self.boxes[path]=box;box.toggled.connect(self.sync)

    def finish(self):
        self.ready=True
        for extension in sorted({os.path.splitext(path)[1].lower() for path in self.rows}):
            box=QCheckBox(extension.lstrip('.').upper());box.setTristate(True)
            box.clicked.connect(lambda _,ext=extension:self.toggle_format(ext))
            self.formats[extension]=box;self.options.addWidget(box)
        self.sync()

    def toggle_format(self,extension):
        boxes=[box for path,box in self.boxes.items() if os.path.splitext(path)[1].lower()==extension]
        marked=not all(box.isChecked() for box in boxes)
        for box in boxes:box.blockSignals(True);box.setChecked(marked);box.blockSignals(False)
        self.sync()

    def sync(self,*_):
        busy=self.running();selected=sum(box.isChecked() for box in self.boxes.values())
        self.copy.setVisible(self.ready)
        for box in self.boxes.values():box.setEnabled(self.ready and not busy)
        for extension,box in self.formats.items():
            boxes=[b for path,b in self.boxes.items() if os.path.splitext(path)[1].lower()==extension]
            n=sum(b.isChecked() for b in boxes)
            box.blockSignals(True);box.setCheckState(Qt.Checked if n==len(boxes) else Qt.PartiallyChecked if n else Qt.Unchecked);box.blockSignals(False);box.setEnabled(not busy)
        self.copy.setText(f'Exportar selecionadas ({selected})');self.copy.setEnabled(self.ready and selected>0 and not busy)
        for button in (self.select_all,self.clear_all):button.setVisible(self.ready)
        self.select_all.setEnabled(self.ready and not busy and selected<len(self.boxes))
        self.clear_all.setEnabled(self.ready and not busy and selected>0)

    def export(self):
        if not self.ready or self.running():return
        rows=[self.rows[path] for path,box in self.boxes.items() if box.isChecked()]
        if not rows:return
        self.dialog=ExportDialog(rows,self)
        self.sync();self.busy_changed.emit()
        try:
            self.dialog.exec()
            self.status.emit(self.dialog.status.text())
        finally:
            self.dialog.deleteLater();self.dialog=None
            self.sync();self.busy_changed.emit()

    def cancel(self):
        if self.dialog:self.dialog.stop_export()
