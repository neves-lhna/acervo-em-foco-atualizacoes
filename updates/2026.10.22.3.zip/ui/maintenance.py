"""Offline maintenance UI; no recognition engine or live stores are opened."""
import os
from pathlib import Path
import subprocess
import sys
import time

from PySide6.QtCore import QLockFile, QThread, Signal, Qt
from PySide6.QtWidgets import (QApplication,QDialog,QVBoxLayout,QLabel,QPushButton,
                               QFileDialog,QLineEdit,QMessageBox,QProgressBar,QTabWidget,QWidget)
from core.app_profile import current_profile
from core.backup_service import export_backup,restore_backup,inspect_backup,reconcile_restore
from core.database_activation import reconcile
from core.signed_updates import check_update,install_update,rollback,install_root
from core.release_identity import VERSION


class MaintenanceWorker(QThread):
    progress=Signal(str)
    outcome=Signal(bool,object)

    def __init__(self,operation,args,parent=None):
        super().__init__(parent);self.operation=operation;self.args=args

    def run(self):
        profile=current_profile();root=profile.data_directory().resolve()
        lock=None
        try:
            if self.operation in ('export','restore'):
                root.mkdir(parents=True,exist_ok=True)
                lock=QLockFile(str(root/'application.lock'));lock.setStaleLockTime(0)
                if not lock.tryLock(0):raise ValueError('Esta edição está aberta. Feche o aplicativo antes de continuar.')
                reconcile_restore(root,profile.key,self.progress.emit);reconcile(root,profile.key,self.progress.emit)
                if self.operation=='export':result=export_backup(root,profile.key,*self.args,self.progress.emit)
                else:result=restore_backup(root,profile.key,*self.args,self.progress.emit)
            else:
                if profile.key!='pessoal':raise ValueError('Atualizações pelo GitHub estão disponíveis somente no Acervo Pessoal.')
                base=install_root();folder=base/'.acervo-updates';folder.mkdir(exist_ok=True)
                lock=QLockFile(str(folder/'maintenance.lock'));lock.setStaleLockTime(0)
                if not lock.tryLock(0):raise ValueError('Outra atualização está em andamento.')
                if self.operation=='check':result=check_update(base,self.progress.emit)
                elif self.operation=='install':result=install_update(base,*self.args,self.progress.emit)
                elif self.operation=='rollback':result=rollback(base)
                else:raise ValueError('Operação desconhecida.')
            self.outcome.emit(True,result)
        except ValueError as error:self.outcome.emit(False,str(error))
        except Exception:
            self.outcome.emit(False,'Não foi possível concluir. Confira conexão, espaço livre, permissões e arquivos selecionados. '
                              'Nenhuma foto original foi alterada. Se houver restauração pendente, ela será conferida na próxima abertura.')
        finally:
            self.args=()
            if lock is not None:lock.unlock()


class MaintenanceDialog(QDialog):
    def __init__(self):
        super().__init__();self.worker=None;self.available=None
        self.setWindowTitle('Backup e atualizações — '+current_profile().label)
        self.resize(650,510)
        layout=QVBoxLayout(self)
        explanation=QLabel('Durante backup ou restauração, mantenha esta edição fechada. '
                           'Os backups incluem os bancos criptografados; as fotos originais devem ser copiadas separadamente.')
        explanation.setWordWrap(True);layout.addWidget(explanation)
        self.tabs=QTabWidget();layout.addWidget(self.tabs)
        backup=QWidget();box=QVBoxLayout(backup)
        self.export_button=QPushButton('Criar backup criptografado…');box.addWidget(self.export_button)
        self.export_button.clicked.connect(self.export)
        self.backup_path=QLineEdit();self.backup_path.setReadOnly(True);self.backup_path.setPlaceholderText('Backup a restaurar')
        box.addWidget(self.backup_path)
        choose=QPushButton('Escolher backup para restaurar…');choose.clicked.connect(self.choose_backup);box.addWidget(choose)
        self.recovery_path=QLineEdit();self.recovery_path.setReadOnly(True);self.recovery_path.setPlaceholderText('Arquivo de recuperação separado')
        box.addWidget(self.recovery_path)
        choose_key=QPushButton('Escolher arquivo de recuperação…');choose_key.clicked.connect(self.choose_recovery);box.addWidget(choose_key)
        self.password=QLineEdit();self.password.setEchoMode(QLineEdit.Password);self.password.setMaxLength(1024)
        self.password.setPlaceholderText('Senha de recuperação — não será gravada');box.addWidget(self.password)
        restore=QPushButton('Restaurar backup…');restore.clicked.connect(self.restore);box.addWidget(restore)
        self.tabs.addTab(backup,'Backup e restauração')
        updates=QWidget();update_box=QVBoxLayout(updates)
        update_box.addWidget(QLabel('Versão em execução: '+VERSION))
        note=QLabel('Atualizações são consultadas ao abrir o programa ou pelo botão abaixo. A instalação exige sua autorização. '
                    'A assinatura e o conteúdo serão verificados antes da instalação. '
                    'Atualizações com novas dependências exigem instalação assistida.')
        note.setWordWrap(True);update_box.addWidget(note)
        check=QPushButton('Verificar atualizações no GitHub');check.clicked.connect(lambda:self.start('check',()))
        update_box.addWidget(check)
        self.install_button=QPushButton('Baixar e instalar atualização verificada');self.install_button.setEnabled(False)
        self.install_button.clicked.connect(lambda:self.start('install',(self.available,)));update_box.addWidget(self.install_button)
        back=QPushButton('Voltar à versão anterior…');back.clicked.connect(self.rollback);update_box.addWidget(back)
        update_box.addStretch();self.tabs.addTab(updates,'Atualizações')
        if current_profile().key!='pessoal':self.tabs.removeTab(self.tabs.indexOf(updates))
        self.status=QLabel('Pronto. Nenhuma operação em andamento.');self.status.setWordWrap(True);self.status.setTextFormat(Qt.PlainText)
        layout.addWidget(self.status)
        self.bar=QProgressBar();self.bar.setRange(0,1);self.bar.setValue(0);layout.addWidget(self.bar)
        self.open_button=QPushButton('Abrir o programa');self.open_button.clicked.connect(self.open_app);layout.addWidget(self.open_button)

    def choose_backup(self):
        path,_=QFileDialog.getOpenFileName(self,'Selecionar backup','','Backup do Acervo (*.acervo-backup)')
        if path:self.backup_path.setText(path)

    def choose_recovery(self):
        path,_=QFileDialog.getOpenFileName(self,'Selecionar recuperação','','Recuperação do Acervo (*.acervo-recovery)')
        if path:self.recovery_path.setText(path)

    def export(self):
        from datetime import datetime
        name='Acervo-'+current_profile().key+'-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.acervo-backup'
        path,_=QFileDialog.getSaveFileName(self,'Salvar backup em arquivo novo',str(Path.home()/name),'Backup do Acervo (*.acervo-backup)')
        if path:self.start('export',(path,))

    def restore(self):
        if not self.backup_path.text() or not self.recovery_path.text() or len(self.password.text())<16:
            self.status.setText('Selecione o backup, a recuperação e informe a senha.');return
        try:report=inspect_backup(self.backup_path.text(),current_profile().key)
        except Exception:self.status.setText('Backup inválido ou de outra edição.');return
        answer=QMessageBox.question(self,'Confirmar restauração',
            f'Restaurar {len(report["files"])-1} bancos da edição {current_profile().label}?\n\n'
            'Os bancos atuais serão substituídos, mas permanecerão guardados para restauração. '
            'As fotos originais não serão alteradas.',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if answer!=QMessageBox.Yes:return
        args=(self.backup_path.text(),self.recovery_path.text(),self.password.text())
        self.password.clear();self.start('restore',args)

    def rollback(self):
        if QMessageBox.question(self,'Voltar à versão anterior','Voltar à versão anterior do programa? Os bancos não serão revertidos.',
                                QMessageBox.Yes|QMessageBox.No,QMessageBox.No)==QMessageBox.Yes:self.start('rollback',())

    def start(self,operation,args):
        if self.worker is not None and self.worker.isRunning():return
        self.tabs.setEnabled(False);self.open_button.setEnabled(False);self.bar.setRange(0,0)
        self.status.setText('Preparando operação…')
        self.worker=MaintenanceWorker(operation,args,self)
        self.worker.progress.connect(self.status.setText)
        self.worker.outcome.connect(lambda ok,result:self.completed(operation,ok,result))
        self.worker.finished.connect(self.finished_work);self.worker.start()

    def completed(self,operation,ok,result):
        if ok and operation=='check':
            self.available=result
            if result:
                from core.signed_updates import verify_envelope
                self.status.setText('Atualização autenticada disponível: '+verify_envelope(result)['version'])
            else:self.status.setText('Sua instalação já está atualizada. Nenhuma alteração realizada.')
        elif ok and operation=='export':self.status.setText('Backup criado e conferido: '+str(result)+'\nGuarde a recuperação e a senha separadamente.')
        else:self.status.setText(str(result))
        if operation in ('install','rollback'):self.available=None

    def finished_work(self):
        self.tabs.setEnabled(True);self.open_button.setEnabled(True);self.bar.setRange(0,1);self.bar.setValue(1)
        self.install_button.setEnabled(self.available is not None)

    def open_app(self):
        from core.signed_updates import application_command
        subprocess.Popen(application_command(),cwd=install_root(),env=os.environ.copy(),
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.accept()

    def reject(self):
        if self.worker is None or not self.worker.isRunning():self.password.clear();super().reject()

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():event.ignore()
        else:self.password.clear();super().closeEvent(event)


def main():
    from ui.theme import apply_theme,watch_theme
    from ui.branding import app_icon
    from ui.language import install_portuguese
    from ui.windows_identity import install_native_icons
    if sys.platform=='win32':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('AcervoEmFoco.'+current_profile().key)
    app=QApplication.instance() or QApplication(sys.argv)
    install_portuguese(app);app.setWindowIcon(app_icon());install_native_icons(app);apply_theme(app);watch_theme(app)
    dialog=MaintenanceDialog();dialog.show();return app.exec()


if __name__=='__main__':sys.exit(main())
