"""Local recovery preparation only. No database migration or activation here."""
from pathlib import Path
from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QLineEdit,
                               QPushButton, QFileDialog, QDialogButtonBox)
from core.security_preparation import prepare
from core.app_profile import current_profile


class PreparationWorker(QThread):
    outcome = Signal(bool, str)

    def __init__(self, root, profile, password, destination, parent=None):
        super().__init__(parent)
        self.root, self.profile = root, profile
        self.password, self.destination = password, destination

    def run(self):
        try:
            prepare(self.root, self.profile, self.password, self.destination)
        except ValueError as error:
            self.outcome.emit(False, str(error))
        except ImportError:
            self.outcome.emit(False, 'O componente de criptografia precisa ser instalado antes de preparar a recuperação.')
        except Exception:
            self.outcome.emit(False, 'Não foi possível concluir a preparação. Os bancos não foram alterados. '
                              'Se um arquivo de recuperação foi criado nesta tentativa, preserve-o e escolha outro nome ao tentar novamente.')
        else:
            self.outcome.emit(True, 'Recuperação salva e conferida. Os bancos ainda não foram criptografados. '
                             'Guarde o arquivo e a senha em locais seguros e separados. A ativação será uma etapa posterior.')
        finally:
            self.password = ''


class DatabaseSecuritySetup(QDialog):
    def __init__(self, parent=None, *, profile=None, directory=None):
        super().__init__(parent)
        self.profile = profile or current_profile().key
        self.directory = Path(directory) if directory is not None else current_profile().data_directory()
        self.worker = None
        self.prepared = (self.directory/'database-security.pending.json').exists()
        active = (self.directory/'database-security.json').exists()
        self.setWindowTitle('Preparar recuperação dos dados — ' + ('DCTA' if self.profile == 'dcta' else 'Pessoal'))
        self.resize(620, 460)
        layout = QVBoxLayout(self)
        explanation = QLabel('Esta etapa prepara sua chave de recuperação. Ela não criptografa nem substitui os bancos.\n\n'
                             'Crie uma senha com pelo menos 16 caracteres. Você precisará dela e do arquivo de recuperação '
                             'para abrir os dados protegidos em outro computador. Sem ambos, a recuperação pode ser impossível.\n\n'
                             'Esta senha é independente da senha do log técnico. Não a envie pelo chat.')
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText('Nova senha de recuperação (mínimo de 16 caracteres)')
        self.password.setMaxLength(1024)
        self.confirmation = QLineEdit()
        self.confirmation.setEchoMode(QLineEdit.Password)
        self.confirmation.setPlaceholderText('Repita a senha')
        self.confirmation.setMaxLength(1024)
        layout.addWidget(self.password)
        layout.addWidget(self.confirmation)
        self.save_button = QPushButton('Escolher local e preparar recuperação')
        self.save_button.clicked.connect(self.save)
        layout.addWidget(self.save_button)
        self.status = QLabel('Prefira guardar o arquivo de recuperação em outro dispositivo. Não o salve junto aos bancos.')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Close)
        self.buttons.button(QDialogButtonBox.Close).setText('Fechar')
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        if self.prepared or active:
            self.password.setEnabled(False)
            self.confirmation.setEnabled(False)
            self.save_button.setEnabled(False)
            self.status.setText('Já há uma configuração de proteção. Preserve a senha e o arquivo de recuperação existentes. '
                                'Esta tela não substitui chaves nem altera bancos.')

    def save(self):
        password = self.password.text()
        if len(password) < 16:
            self.status.setText('Use pelo menos 16 caracteres.')
            return
        if password != self.confirmation.text():
            self.status.setText('As senhas não coincidem.')
            return
        destination, _ = QFileDialog.getSaveFileName(
            self, 'Salvar recuperação fora da pasta dos bancos',
            str(Path.home()/f'Acervo-{self.profile}-recuperacao.acervo-recovery'),
            'Recuperação do Acervo (*.acervo-recovery)')
        if not destination:
            return
        self.worker = PreparationWorker(self.directory, self.profile, password, destination, self)
        self.password.clear()
        self.confirmation.clear()
        self.password.setEnabled(False)
        self.confirmation.setEnabled(False)
        self.save_button.setEnabled(False)
        self.buttons.setEnabled(False)
        self.status.setText('Protegendo a chave e conferindo o arquivo salvo…')
        self.worker.outcome.connect(self._outcome)
        self.worker.finished.connect(self._finished)
        self.worker.start()

    def _outcome(self, success, message):
        self.prepared = success
        self.status.setText(message)

    def _finished(self):
        self.buttons.setEnabled(True)
        if not self.prepared:
            self.password.setEnabled(True)
            self.confirmation.setEnabled(True)
            self.save_button.setEnabled(True)

    def reject(self):
        if self.worker is not None and self.worker.isRunning():
            return
        self.password.clear()
        self.confirmation.clear()
        super().reject()

    def closeEvent(self, event):
        if self.worker is not None and self.worker.isRunning():
            event.ignore()
        else:
            self.password.clear()
            self.confirmation.clear()
            super().closeEvent(event)


def show_setup(parent=None):
    dialog = DatabaseSecuritySetup(parent)
    dialog.exec()


if __name__ == '__main__':
    import sys
    if sys.platform == 'win32':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('AcervoEmFoco.' + current_profile().key)
    from PySide6.QtWidgets import QApplication
    from ui.theme import apply_theme, watch_theme
    from ui.branding import app_icon
    app = QApplication(sys.argv)
    from ui.language import install_portuguese
    from ui.windows_identity import install_native_icons
    install_portuguese(app)
    app.setWindowIcon(app_icon())
    install_native_icons(app)
    apply_theme(app)
    watch_theme(app)
    dialog = DatabaseSecuritySetup()
    dialog.show()
    sys.exit(app.exec())
