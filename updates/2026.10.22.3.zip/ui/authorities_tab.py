import os
import time
from PySide6.QtCore import Qt, Signal, QBuffer, QIODevice, QTimer
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QPushButton, QFileDialog,
                              QInputDialog, QMessageBox, QDialog, QSlider, QProgressBar, QMenu)
from core.image_loader import load_bgr_image
from ui.crop_dialog import CropDialog, bgr_to_qpixmap
from ui.dialog_paths import initial_directory, last_folder, remember_folder
from ui.face_history_tab import FaceHistoryTab
from ui.stable_status import StableStatusLabel
from workers.authority_worker import AuthorityWorker


def _edition_text(text):
    from core.app_profile import current_profile
    if current_profile().key == 'pessoal':
        return text.replace('Autoridades', 'Pessoas').replace('autoridades', 'pessoas').replace('Autoridade', 'Pessoa').replace('autoridade', 'pessoa')
    return text


class AuthoritiesTab(FaceHistoryTab):
    busy_changed = Signal()

    def __init__(self, store, main):
        self.main = main
        self.worker = None
        self.inventory_worker = None
        self._startup_inventories = {}
        self._prepared_inventory = None
        self._scan_inventory = None
        self.folder = None
        self.scan_keys = []
        self._jobs = []
        self._checked_rows = []
        self._new_counts = {}
        self._known_matches = {}
        self._scanning_name = ''
        self._scan_done = 0;self._scan_total = None;self._last_completed = time.monotonic()
        super().__init__(store, main, defer_photos=True)
        self.layout().itemAt(0).widget().setText(
            _edition_text('Cadastre as autoridades e selecione os rostos nas fotos de referência. '
            'Confira os resultados antes de copiar: similaridade não é confirmação de identidade.'))
        registration = QHBoxLayout()
        self.add_btn = QPushButton(_edition_text('Cadastrar autoridade'))
        self.reference_btn = QPushButton('Adicionar referência')
        self.remove_btn = QPushButton('Remover cadastro')
        self.add_btn.clicked.connect(lambda: self.register(False))
        self.reference_btn.clicked.connect(lambda: self.register(True))
        self.remove_btn.clicked.connect(self.remove_registration)
        for button in (self.add_btn, self.reference_btn, self.remove_btn):
            registration.addWidget(button)
        registration.addStretch()
        self.layout().insertLayout(1, registration)
        search = QHBoxLayout()
        self.folder_btn = QPushButton('Escolher pasta')
        self.folder_btn.clicked.connect(self.choose_folder)
        self.folder_label = QLabel('Selecione a pasta do acervo a verificar.')
        self.folder_label.setWordWrap(True)
        search.addWidget(self.folder_btn);search.addWidget(self.folder_label, 1)
        self.layout().insertLayout(2, search)
        actions = QHBoxLayout()
        actions.addWidget(QLabel('Similaridade mínima'))
        self.threshold = QSlider(Qt.Horizontal)
        self.threshold.setRange(20, 80);self.threshold.setValue(60)
        self.threshold_label = QLabel('60%')
        self.threshold.setToolTip('60% corresponde a 0,60 na comparação facial. '
                                 'Aumentar o valor exige maior semelhança; não representa probabilidade de identidade.')
        self.threshold.valueChanged.connect(self.threshold_changed)
        actions.addWidget(self.threshold, 1);actions.addWidget(self.threshold_label)
        self.start_btn = QPushButton(_edition_text('Buscar esta autoridade'))
        self.stop_btn = QPushButton('Parar busca')
        self.start_btn.clicked.connect(self.start_scan);self.stop_btn.clicked.connect(self.stop_scan)
        actions.addWidget(self.start_btn);actions.addWidget(self.stop_btn)
        self.layout().insertLayout(3, actions)
        self.progress = QProgressBar();self.progress.setAlignment(Qt.AlignCenter);self.progress.hide()
        self.layout().insertWidget(4, self.progress)
        self.activity_label = StableStatusLabel(3);self.activity_label.hide()
        self.layout().insertWidget(5, self.activity_label)
        self.activity_timer = QTimer(self);self.activity_timer.setInterval(1000)
        self.activity_timer.timeout.connect(self.update_activity)
        self.progress.setToolTip('Proporção dos arquivos conferidos, incluindo falhas. Não é uma estimativa do tempo restante: imagens sem cache e formatos maiores podem levar mais tempo.')
        self.copy_all.setText(_edition_text('Copiar todas desta autoridade'))
        from ui.photo_display import PhotoDisplay
        self.display = PhotoDisplay(self)
        registration.addWidget(self.display.button)
        self.queue_timer = QTimer(self);self.queue_timer.setInterval(1000)
        self.queue_timer.timeout.connect(self.run_next_job)
        self.notifications_btn = QPushButton()
        self.notifications_btn.clicked.connect(self.show_notifications)
        self.notifications_btn.hide()
        self.choose_face(self.faces.currentItem())
        self.refresh_notifications()
        self.faces.setContextMenuPolicy(Qt.CustomContextMenu)
        self.faces.customContextMenuRequested.connect(self.authority_menu)

    def authority_menu(self,point):
        item=self.faces.itemAt(point)
        if item is None:return
        self.faces.setCurrentItem(item)
        menu=self.build_authority_menu()
        menu.exec(self.faces.viewport().mapToGlobal(point))
        menu.deleteLater()

    def build_authority_menu(self):
        self.controls()
        menu=QMenu(self)
        for label,button in [(_edition_text('Buscar esta autoridade'),self.start_btn),
                             ('Adicionar referência',self.reference_btn),
                             ('Escolher pasta de busca',self.folder_btn),
                             (_edition_text('Copiar todas as fotos desta autoridade'),self.copy_all),
                             ('Remover cadastro',self.remove_btn)]:
            if button is self.remove_btn:menu.addSeparator()
            action=menu.addAction(label);action.setEnabled(button.isEnabled())
            action.triggered.connect(button.click)
        return menu

    def choose_face(self, item, previous=None):
        super().choose_face(item, previous)
        if not hasattr(self, 'folder_label') or not hasattr(self, 'threshold'):
            return
        folder, threshold = self.history.scan_settings(self.face)
        self.folder = folder or self.history.default_folder() or None
        self.folder_label.setText(self.folder or _edition_text('Escolha a pasta do acervo para buscar esta autoridade.'))
        self.threshold.setValue(round(threshold * 100))
        self.controls()

    def schedule_startup_refresh(self,manual=False):
        if getattr(self,'_startup_scheduled',False) and not manual:return
        self._startup_scheduled=True
        self._jobs=[job for job in self._jobs if not job[3]]
        self._startup_inventories.clear()
        self._announced_folders=set()
        for key, name, _ in self.history.authorities():
            folder, threshold = self.history.scan_settings(key)
            if folder:
                self._jobs.append((key, folder, threshold, True))
        if self._jobs:
            self.status.setText(_edition_text('Atualização das autoridades agendada. Serão conferidas fotos novas ou alteradas.'))
            self.queue_timer.start()

    def cancel_pending(self):
        self._jobs.clear()
        self._prepared_inventory=None
        self._startup_inventories.clear()
        if self.inventory_worker and self.inventory_worker.isRunning():
            self.inventory_worker.requestInterruption()
        if hasattr(self, 'queue_timer'):
            self.queue_timer.stop()

    def run_next_job(self):
        if not self._jobs:
            self._startup_inventories.clear()
            self.queue_timer.stop();return
        if getattr(self.main, '_closing', False):
            self.cancel_pending();return
        if not self.main._engine_ready or self.main._busy() or self.main._cache_running():
            return
        key, folder, threshold, automatic = self._jobs[0]
        if not self.history.references({key}):
            self._jobs.pop(0);return
        if not os.path.isdir(folder):
            self.status.setText(_edition_text('Atualização adiada: pasta indisponível. Conecte o acervo e reabra o programa ou busque esta autoridade manualmente.'))
            self.main.statusBar().showMessage(self.status.text())
            self._jobs.pop(0);return
        if self.start_scan(key=key, folder=folder, threshold=threshold, automatic=automatic):
            self._jobs.pop(0)

    def refresh_notifications(self):
        rows = self.history.notifications()
        total = sum(row[2] for row in rows)
        self.notifications_btn.setText(_edition_text(f'Autoridades: {total} novas fotos'))
        self.notifications_btn.hide()
        if hasattr(self.main,'notification_button'):self.main._update_notification_bell()
        totals = {}
        for _, name, count, _ in rows:
            totals[name] = totals.get(name, 0) + count
        self.notifications_btn.setToolTip('\n'.join(f'{name}: {count} novas fotos' for name,count in totals.items()))

    def show_notifications(self):
        rows = self.history.notifications()
        totals = {}
        for _, name, count, _ in rows:
            totals[name] = totals.get(name, 0) + count
        self.main.tabs.setCurrentWidget(self)
        QMessageBox.information(self, _edition_text('Novas fotos de autoridades'),
            '\n'.join(f'{name}: {count} nova(s) foto(s)' for name,count in totals.items())
            + '\n\nConfira as correspondências antes de copiar. Similaridade não confirma identidade.')
        self.history.mark_notifications_read([row[0] for row in rows])
        self.refresh_notifications()

    def threshold_changed(self, value):
        self.threshold_label.setText(f'{value}%')
        self.threshold.setToolTip(f'{value}% corresponde a {value / 100:.2f} na comparação facial. '
                                 'Valores maiores exigem maior semelhança. Não é uma probabilidade de identidade.')

    def reload(self):
        super().reload()
        names = {key: (name, count) for key, name, count in self.history.authorities()}
        for index in range(self.faces.count()):
            item = self.faces.item(index)
            name, count = names.get(item.data(Qt.UserRole), (_edition_text('Autoridade'), 0))
            item.setText(f'{name}\n{count} referência(s) · ' + item.text())
        if not self.faces.count():
            self.face = None;self.rows = [];self.selected.clear();self.photos.clear()
            self.info.setText(_edition_text('Cadastre a primeira autoridade para começar.'))
            if hasattr(self,'display'):self.display.apply(self.display.mode)
        self.controls()

    def show_page(self):
        super().show_page()
        for row in self.rows:
            item = self.items.get(row[0])
            if item:
                item.setText(f'{os.path.basename(row[0])}\nSimilaridade: {row[1]:.0%}')
        if hasattr(self,'display'):self.display.apply(self.display.mode)

    def preview_ready(self, path, data, generation):
        super().preview_ready(path,data,generation)
        if hasattr(self,'display') and generation == self.generation:
            item = self.display.table_items.get(path)
            source = self.items.get(path)
            if item and source:item.setIcon(0,source.icon())
            self.display.update_panel()

    def copy_photos(self,selected_only):
        if self.main._busy() or self.copying():return
        rows=[row for row in self.rows if not selected_only or row[0] in self.selected]
        if not rows:return
        from ui.export_dialog import ExportDialog
        self.export_dialog=ExportDialog(rows,self)
        self.export_dialog.exec()
        self.status.setText(self.export_dialog.status.text())
        self.export_dialog.deleteLater();self.export_dialog=None
        self.controls()

    def copying(self):
        dialog=getattr(self,'export_dialog',None)
        return bool(dialog and dialog.isVisible()) or super().copying()

    def cancel_copy(self):
        dialog=getattr(self,'export_dialog',None)
        if dialog:dialog.stop_export()
        else:super().cancel_copy()

    def running(self):
        return bool((self.worker and self.worker.isRunning()) or
                    (self.inventory_worker and self.inventory_worker.isRunning()))

    def active(self):
        return self.running() or self.copying()

    def controls(self):
        super().controls()
        if not hasattr(self, 'start_btn'):
            return
        busy = self.main._busy()
        ready = self.main._engine_ready and not busy
        self.add_btn.setEnabled(ready)
        self.reference_btn.setEnabled(ready and self.face is not None)
        self.remove_btn.setEnabled(not busy and self.face is not None)
        self.folder_btn.setEnabled(not busy)
        self.threshold.setEnabled(not busy)
        self.start_btn.setEnabled(ready and self.face is not None)
        self.start_btn.setToolTip(_edition_text('Busca somente a autoridade selecionada. ') +
                                 ('Pasta: ' + self.folder if self.folder else 'Escolha a pasta do acervo ao iniciar.'))
        self.stop_btn.setEnabled(self.running())
        self.copy_all.setEnabled(bool(self.rows) and not busy)
        self.copy_selected.setEnabled(bool(self.selected) and not busy)

    def register(self, additional):
        if self.main._busy() or not self.main._engine_ready:
            return
        key = self.face if additional else None
        name = None
        if not additional:
            name, accepted = QInputDialog.getText(self, _edition_text('Cadastrar autoridade'), _edition_text('Nome da autoridade:'))
            if not accepted or not name.strip():
                return
        path, _ = QFileDialog.getOpenFileName(self, _edition_text('Escolha uma foto e selecione o rosto da autoridade'),
            initial_directory(last_folder()), 'Imagens (*.jpg *.jpeg *.png *.bmp *.webp *.heic *.heif *.hif)')
        if not path:
            return
        image = load_bgr_image(path)
        if image is None:
            QMessageBox.warning(self, 'Foto indisponível', 'Não foi possível ler essa imagem.');return
        dialog = CropDialog(image, self)
        if dialog.exec() != QDialog.Accepted or dialog.selected_embedding is None:
            return
        buffer = QBuffer();buffer.open(QIODevice.WriteOnly)
        bgr_to_qpixmap(dialog.selected_crop).scaled(160, 160, Qt.KeepAspectRatio,
                                                  Qt.SmoothTransformation).save(buffer, 'PNG')
        portrait = bytes(buffer.data());buffer.close()
        try:
            if additional:
                self.history.add_reference(key, dialog.selected_embedding, portrait)
            else:
                key = self.history.add_authority(name, dialog.selected_embedding, portrait)
        except ValueError as exc:
            QMessageBox.warning(self, 'Cadastro', str(exc));return
        self.face = key;self.reload()
        if self.folder and os.path.isdir(self.folder):
            self._jobs = [job for job in self._jobs if job[0] != key]
            self._jobs.insert(0, (key,self.folder,self.threshold.value()/100,False))
            self.queue_timer.start()
            self.status.setText(_edition_text('Referência salva. A busca será feita somente para esta autoridade.'))
        else:
            self.status.setText(_edition_text('Referência salva. Clique em Buscar esta autoridade e escolha a pasta do acervo.'))

    def remove_registration(self):
        if self.main._busy() or self.face is None:
            return
        if QMessageBox.question(self, 'Remover cadastro',
            _edition_text('Remover esta autoridade, suas referências e os resultados salvos? As fotos do acervo serão preservadas.'),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._jobs = [job for job in self._jobs if job[0] != self.face]
        self.history.remove_authority(self.face);self.face = None;self.reload();self.refresh_notifications()

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, _edition_text('Pasta para buscar as autoridades'),
                                                   initial_directory(self.folder, last_folder()))
        if folder:
            self.folder = folder;remember_folder(folder)
            if self.face:
                self.history.remember_scan(self.face,folder,self.threshold.value()/100)
            self.folder_label.setText(folder);self.controls()

    def start_scan(self, checked=False, *, key=None, folder=None, threshold=None, automatic=False):
        if self.main._busy() or not self.main._engine_ready:
            return False
        key = key or self.face
        folder = folder or self.folder
        if not folder or not os.path.isdir(folder):
            if automatic:
                return False
            self.choose_folder();folder = self.folder
            if not folder or not os.path.isdir(folder):return False
        threshold = self.threshold.value()/100 if threshold is None else threshold
        references = self.history.references({key})
        if not references:
            return False
        if self.stop_previews():
            self.status.setText(_edition_text('Finalizando as prévias antes de iniciar a busca desta autoridade…'))
            if not self._jobs:
                self._jobs.append((key,folder,threshold,automatic));self.queue_timer.start()
            return False
        signature = self.history.scan_signature(key,threshold)
        prepared_matches=bool(self._prepared_inventory and self._prepared_inventory.get('identity')==(key,folder,signature))
        if automatic and not prepared_matches:
            from workers.authority_inventory_worker import AuthorityInventoryWorker
            self.status.setText('Verificando alterações no acervo, sem reconhecimento facial…')
            announced=getattr(self,'_announced_folders',set())
            folder_key=os.path.normcase(os.path.abspath(folder))
            if folder_key not in announced:
                self.main._announce(_edition_text('Autoridades: conferindo se há fotos novas ou alteradas em ')+folder)
                announced.add(folder_key);self._announced_folders=announced
            self.inventory_worker=AuthorityInventoryWorker(self.history.path,key,folder,signature,self, snapshot=self._startup_inventories.get(os.path.normcase(os.path.abspath(folder))))
            self._inventory_result=None
            self.inventory_worker.result.connect(self.inventory_result)
            self.inventory_worker.finished.connect(lambda:self.inventory_finished(key,folder,threshold,signature))
            self.inventory_worker.start();self.busy_changed.emit();self.controls()
            return False
        prepared=self._prepared_inventory if automatic and prepared_matches else None;self._prepared_inventory=None
        self._scan_inventory=(key,folder,signature,prepared['current']) if prepared else None
        if prepared:self.history.reconcile_inventory(key,folder,prepared['current'])
        self.scan_keys = list(references)
        self._scanning_name = next((name for ident,name,_ in self.history.authorities() if ident==key),_edition_text('Autoridade'))
        self.history.remember_scan(key,folder,threshold)
        signature = self.history.scan_signature(key,threshold)
        checked_files = self.history.checked_files(key,signature)
        self._known_matches = {key:{os.path.normcase(os.path.abspath(row[0])) for row in self.history.results(key)}}
        self._new_counts = {key:0};self._checked_rows = []
        self.history.begin_scan(self.scan_keys, folder)
        self.selected.clear()
        self.worker = AuthorityWorker(folder, references, threshold, self.main.cache, self,
                                      checked={key:checked_files},signatures={key:signature},
                                      paths=prepared['pending'] if prepared else None)
        self.worker.authority_evaluated.connect(self.clear_previous_match)
        self.worker.authority_found.connect(self.match_found)
        self.worker.file_checked.connect(self.file_checked)
        self.worker.status.connect(lambda message: self.status.setText(self._scanning_name + ': ' + message))
        self.worker.status.connect(lambda message:self.main._announce(_edition_text('Busca de autoridades: ')+self._scanning_name+': '+message))
        self.worker.progress.connect(self.scan_progress)
        self.worker.error.connect(lambda message: self.status.setText('Falha na busca: ' + message))
        self.worker.finished.connect(self.scan_finished)
        self._scan_done = 0;self._scan_total = None;self._last_completed = time.monotonic()
        self.progress.setRange(0,0);self.progress.show()
        self.activity_label.setText('Enumerando imagens e preparando o reconhecimento…');self.activity_label.show()
        self.activity_timer.start()
        self.worker.start();self.busy_changed.emit();self.controls()
        return True

    def inventory_result(self,result):
        self._inventory_result=result

    def inventory_finished(self,key,folder,threshold,signature):
        result=self._inventory_result or {'error':'Conferência não concluída.'}
        if self.inventory_worker.isInterruptionRequested():
            self._prepared_inventory=None
        elif 'error' in result:
            self.status.setText('Não foi possível conferir o acervo: '+result['error']+' Resultados preservados.')
            self._jobs=[job for job in self._jobs if job[0]!=key]
        elif result['unchanged']:
            if not result.get('baseline'):
                self.history.save_inventory(key,folder,signature,result['current'])
            self.status.setText(_edition_text('Acervo sem alterações. Resultados das autoridades preservados; nenhuma nova busca necessária.'))
            self._jobs=[job for job in self._jobs if job[0]!=key]
        else:
            result['identity']=(key,folder,signature)
            self._prepared_inventory=result
            self.status.setText(f"Alterações detectadas: {len(result['pending'])} foto(s) para conferir.")
        if 'current' in result and not self.inventory_worker.isInterruptionRequested():
            self._startup_inventories[os.path.normcase(os.path.abspath(folder))]=result['current']
        self.main._announce(_edition_text('Autoridades: ')+self.status.text(),not result.get('unchanged',False))
        self.busy_changed.emit();self.controls()

    def scan_progress(self, done, total):
        if done > self._scan_done:
            self._last_completed = time.monotonic()
        self._scan_done = done;self._scan_total = total
        if done == total:
            self.progress.setRange(0,0)
        else:
            self.progress.setRange(0, max(total,1));self.progress.setValue(done)
            percent = int(1000 * done / total) / 10 if total else 0
            self.progress.setFormat(f'{percent:.1f}% — {done:,} / {total:,} arquivos'.replace(',', '.'))
        self.update_activity()

    def update_activity(self):
        if not self.worker:
            return
        now = time.monotonic()
        if self._scan_total is not None:
            remaining = max(0, self._scan_total - self._scan_done)
            text = f'{self._scan_done:,} de {self._scan_total:,} arquivos conferidos. Restam {remaining:,}. Falhas: {self.worker.failed_count}.'.replace(',', '.')
            if self.worker._stop_requested:
                text += ' Parando; aguardando os arquivos em processamento.'
            elif remaining == 0:
                text += ' Finalizando o catálogo…'
            self.status.setText((self._scanning_name + ': ' if self._scanning_name else '') + text)
        active = self.worker.activity_snapshot()
        lines = [f'{stage}: {os.path.basename(path)} — {int(now-started)} s nesta etapa'
                 for path, (stage, started) in active.items()]
        if active and self._scan_total is not None:
            lines.append(f'Há {int(now-self._last_completed)} s sem concluir outro arquivo. A porcentagem só avança após a conclusão de um arquivo.')
        if lines:
            self.activity_label.setText('\n'.join(lines))
            self.activity_label.setToolTip('\n'.join(lines) + '\n\n' + '\n'.join(active))
        elif self._scan_total is not None:
            self.activity_label.setText('Aguardando a próxima atualização do processamento…')

    def clear_previous_match(self,key,path):
        with self.history.db:
            self.history.db.execute('DELETE FROM matches WHERE face=? AND path=?',(key,os.path.abspath(path)))

    def match_found(self, key, path, score, pose):
        self.history.add(key, path, score, pose)
        normalized = os.path.normcase(os.path.abspath(path))
        known = self._known_matches.setdefault(key,set())
        if normalized not in known and self.history.db.execute(
                'SELECT 1 FROM matches WHERE face=? AND path=?',(key,os.path.abspath(path))).fetchone():
            known.add(normalized);self._new_counts[key] = self._new_counts.get(key,0)+1

    def file_checked(self, row):
        self._checked_rows.append(row)
        if len(self._checked_rows) >= 100:
            self.flush_checked()

    def flush_checked(self):
        if self._checked_rows:
            self.history.save_checked(self._checked_rows)
            self._checked_rows.clear()

    def stop_scan(self):
        self.cancel_pending()
        if self.worker and self.worker.isRunning():
            self.worker.stop();self.status.setText('Parando após os arquivos em processamento…')

    def scan_finished(self):
        worker = self.worker
        self.flush_checked()
        self.activity_timer.stop();self.activity_label.hide()
        self.progress.setRange(0,max(self._scan_total or 0,1));self.progress.setValue(self._scan_done)
        self.progress.setFormat(f'{self._scan_done:,} / {self._scan_total or 0:,} arquivos conferidos'.replace(',', '.'))
        if not worker._stop_requested and not worker.failure_message and self._scan_done == self._scan_total:
            self.progress.setRange(0,100);self.progress.setValue(100);self.progress.setFormat('100% — conferência concluída')
        state = 'Interrompida' if worker._stop_requested else ('Concluída com falhas' if worker.failure_message or worker.failed_count else 'Concluída')
        for key in self.scan_keys:
            self.history.finish(key, state)
            self.history.notify_new(key,self._new_counts.get(key,0))
        if self._scan_inventory and not worker._stop_requested and self._scan_done == self._scan_total:
            self.history.save_inventory(*self._scan_inventory)
        self._scan_inventory=None
        self.refresh_notifications()
        self.reload()
        self.status.setText(f'{state}. {self._scan_done:,} de {self._scan_total or 0:,} arquivos conferidos. {worker.failed_count} falha(s). Selecione uma pessoa para conferir as fotos.'
                            + (f' Motivo: {worker.failure_message}' if worker.failure_message else ''))
        self.main._announce(_edition_text('Busca de autoridades: ')+self.status.text(),True)
        self.busy_changed.emit();self.controls()

    def copy_finished(self):
        super().copy_finished()
        self.busy_changed.emit();self.controls()
