"""Contextual hints on vertical scrollbars, without changing navigation."""
from PySide6.QtCore import QObject,QEvent,Qt,QPoint
from PySide6.QtGui import QCursor
from PySide6.QtWidgets import QScrollBar,QAbstractItemView,QScrollArea,QLabel,QToolTip

class ScrollPreview(QObject):
    def eventFilter(self,obj,event):
        if isinstance(obj,QScrollBar) and obj.orientation()==Qt.Vertical:
            if event.type() in (QEvent.Enter,QEvent.MouseMove,QEvent.MouseButtonPress):
                self.show_hint(obj)
                if not obj.property('context_hint_connected'):
                    obj.valueChanged.connect(lambda value,bar=obj:self.on_scroll(bar))
                    obj.setProperty('context_hint_connected',True)
            elif event.type()==QEvent.Leave:
                QToolTip.hideText()
        return False

    def on_scroll(self,bar):
        if bar.underMouse() or bar.isSliderDown():self.show_hint(bar)

    def show_hint(self,bar):
        if bar.maximum()<=bar.minimum():return
        view=bar.parentWidget()
        while view and not isinstance(view,(QAbstractItemView,QScrollArea)):
            view=view.parentWidget()
        percent=round(100*(bar.value()-bar.minimum())/(bar.maximum()-bar.minimum()))
        text=f'Posição atual: {percent}%'
        if isinstance(view,QAbstractItemView):
            # Use the visible row, including expanded tree branches.
            index=view.indexAt(QPoint(8,8))
            if not index.isValid():
                for y in range(1,min(view.viewport().height(),80),4):
                    index=view.indexAt(QPoint(view.viewport().width()//2,y))
                    if index.isValid():break
            if index.isValid():
                name=index.siblingAtColumn(0).data()
                if name:text+='\n'+str(name)[:180]
        elif isinstance(view,QScrollArea) and view.widget():
            labels=[]
            for label in view.widget().findChildren(QLabel):
                pos=label.mapTo(view.viewport(),QPoint(0,0))
                if label.isVisible() and label.text() and 0<=pos.y()<view.viewport().height():
                    labels.append((pos.y(),label.text()))
            if labels:text+='\n'+min(labels,key=lambda item:item[0])[1][:180]
        QToolTip.showText(QCursor.pos()+QPoint(-30,16),text,bar)

def install_scroll_preview(app):
    app._scroll_preview=ScrollPreview(app)
    app.installEventFilter(app._scroll_preview)
