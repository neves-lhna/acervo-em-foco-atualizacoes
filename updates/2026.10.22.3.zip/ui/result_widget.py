"""
ui/result_widget.py
----------------------
Item individual da lista de resultados: thumbnail da foto encontrada,
caminho completo no disco, score de similaridade/pose, e o botão
"Abrir na pasta".
"""

from __future__ import annotations

import os

from PySide6.QtCore import Qt, QSize,QThreadPool,Slot
from PySide6.QtGui import QPixmap, QImageReader
from PySide6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QSizePolicy,QCheckBox

from core.utils_os import reveal_in_file_manager
from ui.photo_viewer import PhotoLabel, show_photo

THUMB_SIZE = 112


class ResultItemWidget(QWidget):
    def __init__(self, path: str, score: float, pose: str, parent=None):
        super().__init__(parent)
        self.path = path

        thumb_label = PhotoLabel()
        self.thumb_label=thumb_label
        thumb_label.clicked.connect(lambda:show_photo(self.path,self,self.gallery_provider() if hasattr(self,"gallery_provider") else None))
        thumb_label.setFixedSize(THUMB_SIZE, THUMB_SIZE)
        thumb_label.setAlignment(Qt.AlignCenter)
        reader = QImageReader(path)
        reader.setAutoTransform(True)
        source_size = reader.size()
        if source_size.isValid():
            reader.setScaledSize(source_size.scaled(THUMB_SIZE, THUMB_SIZE, Qt.KeepAspectRatio))
        pixmap = QPixmap.fromImage(reader.read())
        if not pixmap.isNull():
            pixmap = pixmap.scaled(
                THUMB_SIZE, THUMB_SIZE, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
        if pixmap.isNull():
            thumb_label.setText(os.path.splitext(path)[1].lstrip('.').upper())
            from ui.image_folder_dialog import PreviewJob
            self.preview_job=PreviewJob(path,0,THUMB_SIZE)
            self.preview_job.signals.ready.connect(self.preview_ready)
            QThreadPool.globalInstance().start(self.preview_job)
        else:
            thumb_label.setPixmap(pixmap)
        thumb_label.setObjectName('Thumbnail')

        name_label = QLabel(os.path.basename(path))
        name_label.setTextFormat(Qt.PlainText)
        name_label.setWordWrap(True)
        name_label.setObjectName('PhotoName')
        path_label = QLabel(path)
        path_label.setWordWrap(True)
        path_label.setObjectName('PhotoPath')
        path_label.setMaximumHeight(38)
        path_label.setToolTip(path)
        score_label = QLabel(f"Similaridade: {score*100:.1f}%".replace('.',','))
        score_label.setToolTip("Pontuação de comparação entre rostos; não é probabilidade de identidade. "
                               "Confira visualmente o resultado.")
        score_label.setObjectName('PhotoScore')

        text_col = QVBoxLayout()
        text_col.addWidget(name_label)
        text_col.addWidget(score_label)
        text_col.addWidget(path_label)
        text_col.addStretch()

        open_btn = QPushButton("Abrir na pasta")
        open_btn.clicked.connect(self._open_in_folder)
        open_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(16)
        self.export_check=QCheckBox();self.export_check.setToolTip('Selecionar esta foto para copiar.');self.export_check.setEnabled(False)
        layout.addWidget(self.export_check)
        layout.addWidget(thumb_label)
        layout.addLayout(text_col, stretch=1)
        layout.addWidget(open_btn)

    def preview_ready(self,token,image):
        if not image.isNull():self.thumb_label.setPixmap(QPixmap.fromImage(image).scaled(THUMB_SIZE,THUMB_SIZE,Qt.KeepAspectRatio,Qt.SmoothTransformation))

    def _open_in_folder(self):
        reveal_in_file_manager(self.path)

    def sizeHint(self) -> QSize:
        return QSize(400, THUMB_SIZE + 16)
