"""Palette-aware bell, independent of installed emoji fonts."""
from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QIcon,QPixmap,QPainter,QPen,QPainterPath,QColor,QPalette,QFont,QRegion
from PySide6.QtWidgets import QApplication

def bell_icon(unread=0):
    pix=QPixmap(64,64);pix.fill(Qt.transparent)
    painter=QPainter(pix);painter.setRenderHint(QPainter.Antialiasing);painter.scale(2,2)
    painter.setPen(QPen(QApplication.palette().color(QPalette.WindowText),1.7,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
    painter.save();painter.translate(4,3)
    shape=QPainterPath();shape.moveTo(5,17);shape.lineTo(7,14);shape.lineTo(7,10)
    shape.cubicTo(7,3,17,3,17,10);shape.lineTo(17,14);shape.lineTo(19,17);shape.closeSubpath()
    painter.drawPath(shape);painter.drawArc(10,17,4,4,180*16,180*16)
    painter.restore()
    if unread:
        count=max(0,int(unread))
        label=str(count) if count<100 else '99+'
        badge=QRectF(14 if count<10 else 10,0,18 if count<10 else 22,15)
        painter.setPen(Qt.NoPen);painter.setBrush(QColor('#eda62e'))
        painter.drawRoundedRect(badge,7,7)
        font=QFont('Segoe UI');font.setPixelSize(10);font.setBold(True)
        painter.setFont(font);painter.setPen(QColor('#191b1f'))
        painter.drawText(badge,Qt.AlignCenter,label)
    painter.end()
    # Center the visible composition separately for the plain and numbered states.
    bounds=QRegion(pix.mask()).boundingRect()
    centered=QPixmap(pix.size());centered.fill(Qt.transparent)
    painter=QPainter(centered)
    painter.drawPixmap((pix.width()-bounds.width())//2,
                       (pix.height()-bounds.height())//2,pix.copy(bounds))
    painter.end()
    return QIcon(centered)
