"""Recovery before startup opens any archive stores."""
from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QLineEdit,
                               QPushButton, QFileDialog, QDialogButtonBox)
from core.database_recovery import recover


class RecoveryWorker(QThread):
    progress = Signal(str)
    outcome = Signal(bool, str)

    def __init__(self, root, profile, path, password, parent=None):
        super().__init__(parent)
        self.root, self.profile, self.path, self.password = root, profile, path, password

    def run(self):
        try:
            recover(self.root, self.profile, self.path, self.password, self.progress.emit)
        except ValueError as error:
            self.outcome.emit(False, str(error))
        except ImportError:
            self.outcome.emit(False, 'O componente de criptografia precisa ser instalado. Os dados foram preservados.')
        except Exception:
            self.outcome.emit(False, 'Não foi possível validar todos os bancos e recuperar o acesso. '
                              'Confira o arquivo de recuperação e o conjunto de bancos. Nenhuma foto foi alterada.')
        else:
            self.outcome.emit(True, 'Acesso recuperado para esta conta do Windows.')
        finally:
            self.password = ''


class DatabaseRecoveryDialog(QDialog):
    def __init__(self, root, profile, parent=None):
        super().__init__(parent)
        self.root, self.profile = root, profile
        self.worker, self.recovered = None, False
        self.setWindowTitle('Recuperar acesso aos dados — ' + ('DCTA' if profile == 'dcta' else 'Pessoal'))
        self.setMinimumWidth(560)
        layout = QVBoxLayout(self)
        label = QLabel('Os bancos estão protegidos e não puderam ser desbloqueados nesta conta do Windows. '
                       'Escolha seu arquivo de recuperação e informe a senha definida na preparação. '
                       'Ao cancelar, o aplicativo será fechado e os dados serão preservados.')
        label.setWordWrap(True)
        layout.addWidget(label)
        self.path = QLineEdit()
        self.path.setReadOnly(True)
        self.path.setPlaceholderText('Arquivo .acervo-recovery')
        layout.addWidget(self.path)
        self.choose_button = QPushButton('Escolher arquivo de recuperação')
        self.choose_button.clicked.connect(self.choose)
        layout.addWidget(self.choose_button)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setMaxLength(1024)
        self.password.setPlaceholderText('Senha de recuperação')
        layout.addWidget(self.password)
        self.recover_button = QPushButton('Recuperar acesso')
        self.recover_button.clicked.connect(self.start)
        layout.addWidget(self.recover_button)
        self.status = QLabel('A senha não será gravada. Não a envie pelo chat.')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Cancel)
        self.buttons.button(QDialogButtonBox.Cancel).setText('Cancelar e sair')
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)

    def choose(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Selecionar recuperação', '', 'Recuperação do Acervo (*.acervo-recovery)')
        if path:
            self.path.setText(path)

    def start(self):
        if self.worker is not None and self.worker.isRunning():
            return
        if not self.path.text() or len(self.password.text()) < 16:
            self.status.setText('Escolha o arquivo e informe a senha de recuperação (mínimo de 16 caracteres).')
            return
        self.worker = RecoveryWorker(self.root, self.profile, self.path.text(), self.password.text(), self)
        self.password.clear()
        self._enabled(False)
        self.worker.progress.connect(self.status.setText)
        self.worker.outcome.connect(self.completed)
        self.worker.finished.connect(self.finished_recovery)
        self.worker.start()

    def _enabled(self, enabled):
        for widget in (self.choose_button, self.password, self.recover_button, self.buttons):
            widget.setEnabled(enabled)

    def completed(self, success, message):
        self.recovered = success
        self.status.setText(message)

    def finished_recovery(self):
        self._enabled(True)
        if self.recovered:
            self.accept()

    def reject(self):
        if self.worker is None or not self.worker.isRunning():
            self.password.clear()
            super().reject()

    def closeEvent(self, event):
        if self.worker is not None and self.worker.isRunning():
            event.ignore()
        else:
            self.password.clear()
            super().closeEvent(event)
