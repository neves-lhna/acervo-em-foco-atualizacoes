"""One check per launch. Installation always requires explicit user approval."""
from PySide6.QtCore import QObject,QTimer
from PySide6.QtWidgets import QMessageBox
from core.signed_updates import verify_envelope
from ui.maintenance import MaintenanceWorker


class StartupUpdates(QObject):
    def __init__(self,window):
        super().__init__(window);self.window=window;self.worker=None;self.available=None;self.output=None
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.timeout.connect(self.offer)
        QTimer.singleShot(1800,lambda:self.start('check',()))

    def running(self):return self.worker is not None and self.worker.isRunning()

    def start(self,operation,args):
        if getattr(self.window,'_closing',False) or self.running():return
        self.output=None
        self.worker=MaintenanceWorker(operation,args,self)
        self.worker.outcome.connect(lambda ok,value:setattr(self,'output',(ok,value)))
        self.worker.finished.connect(lambda:self.finished(operation))
        self.worker.start()

    def finished(self,operation):
        if not self.output:return
        ok,value=self.output
        if not ok:
            self.window._notify('Atualizações: '+str(value));return
        if operation=='check':
            self.available=value
            if value:self.timer.start(0)
        else:
            self.window._notify('Atualização instalada. Reinicie o aplicativo quando for conveniente para concluir. '
                                'A versão anterior foi preservada.')
            self.window.statusBar().showMessage('Atualização pronta — reinicie o aplicativo para usar a nova versão.')

    def offer(self):
        if not self.available or getattr(self.window,'_closing',False):return
        if self.window._busy() or self.window._warmup_thread.isRunning() or (
                self.window._cache_worker and self.window._cache_worker.isRunning()) or self.window.auxiliary_tab.running():
            self.timer.start(3000);return
        data=verify_envelope(self.available)
        dialog=QMessageBox(self.window);dialog.setWindowTitle('Atualização disponível')
        dialog.setText('A versão '+data['version']+' foi encontrada e sua assinatura foi verificada.')
        dialog.setInformativeText('Autoriza baixar e instalar? As fotos e os bancos não serão substituídos. '
                                  'Ao concluir, será necessário reiniciar o aplicativo, sem reinício automático.')
        install=dialog.addButton('Instalar atualização',QMessageBox.AcceptRole)
        dialog.addButton('Agora não',QMessageBox.RejectRole)
        dialog.exec()
        raw=self.available;self.available=None
        if dialog.clickedButton()==install:self.start('install',(raw,))
