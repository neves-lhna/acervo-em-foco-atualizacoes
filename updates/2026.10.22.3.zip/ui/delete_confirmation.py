"""Resizable confirmation with a readable, filename-only list."""
import os
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QPlainTextEdit,QDialogButtonBox,QMessageBox


class DeleteConfirmation(QDialog):
    def __init__(self,paths,parent=None):
        super().__init__(parent)
        self.setWindowTitle('Conferir exclusão')
        self.setWindowFlag(Qt.WindowMaximizeButtonHint,True)
        self.setSizeGripEnabled(True);self.resize(760,560)
        layout=QVBoxLayout(self)
        title=QLabel(f'Mover {len(paths)} arquivo(s) para a Lixeira do Windows?');title.setWordWrap(True);layout.addWidget(title)
        note=QLabel('Confira os arquivos selecionados. Fotos parecidas podem ser registros diferentes.');note.setWordWrap(True);layout.addWidget(note)
        self.file_list=QPlainTextEdit();self.file_list.setReadOnly(True)
        self.file_list.setPlainText('\n'.join(sorted(os.path.basename(path) for path in paths)))
        layout.addWidget(self.file_list,1)
        buttons=QDialogButtonBox();yes=buttons.addButton('Sim',QDialogButtonBox.AcceptRole)
        cancel=buttons.addButton('Cancelar',QDialogButtonBox.RejectRole)
        yes.setAutoDefault(False);cancel.setDefault(True)
        yes.clicked.connect(lambda:self.done(QMessageBox.Yes));cancel.clicked.connect(self.reject)
        layout.addWidget(buttons)
