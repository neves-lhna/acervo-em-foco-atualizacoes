"""Folder selection with visible image files and an asynchronous photo preview."""
import os
from PySide6.QtCore import Qt, QObject, Signal, QRunnable, QThreadPool, Slot
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import QFileDialog, QDialog, QLabel, QWidget, QVBoxLayout, QPushButton
from core.image_loader import load_bgr_image
from core.folder_history import IMAGE_EXTENSIONS


class PreviewSignals(QObject):
    ready = Signal(int, QImage)


class PreviewJob(QRunnable):
    def __init__(self, path, token, max_size=480):
        super().__init__(); self.path=path; self.token=token; self.max_size=max_size; self.signals=PreviewSignals()
    def run(self):
        image=QImage()
        try:
            bgr=load_bgr_image(self.path)
            if bgr is not None:
                import cv2
                h,w=bgr.shape[:2];scale=min(1,self.max_size/w,self.max_size/h)
                rgb=cv2.cvtColor(cv2.resize(bgr,(max(1,int(w*scale)),max(1,int(h*scale)))),cv2.COLOR_BGR2RGB)
                image=QImage(rgb.data,rgb.shape[1],rgb.shape[0],rgb.strides[0],QImage.Format_RGB888).copy()
        except Exception as exc:
            from core.diagnostics import image_error
            image_error(self.path,str(exc),'Prévia de imagem')
        self.signals.ready.emit(self.token,image)


class ImageFolderDialog(QFileDialog):
    def __init__(self, parent, directory):
        super().__init__(parent, 'Escolha a pasta e confira suas imagens', directory)
        self.setOption(QFileDialog.DontUseNativeDialog,True)
        self.setFileMode(QFileDialog.Directory)
        self.setOption(QFileDialog.ShowDirsOnly,False)
        self.setNameFilter('Imagens ('+' '.join('*'+ext for ext in sorted(IMAGE_EXTENSIONS))+')')
        self.setLabelText(QFileDialog.Accept,'Selecionar esta pasta')
        self.setViewMode(QFileDialog.Detail)
        self.resize(1050,650);self.selected_folder='';self._token=0;self._job=None;self._pending=None
        panel=QWidget();panel.setMinimumWidth(320);box=QVBoxLayout(panel)
        note=QLabel('Clique em uma imagem para ver a prévia.\nA análise incluirá esta pasta e suas subpastas.');note.setWordWrap(True);box.addWidget(note)
        self.preview=QLabel('Selecione uma imagem');self.preview.setAlignment(Qt.AlignCenter);self.preview.setMinimumSize(300,300);box.addWidget(self.preview,1)
        self.preview_path=None
        self.preview.setCursor(Qt.PointingHandCursor);self.preview.setToolTip('Clique para ampliar a imagem.')
        self.preview.mouseReleaseEvent=self.open_preview
        self.filename=QLabel();self.filename.setWordWrap(True);self.filename.setTextFormat(Qt.PlainText);box.addWidget(self.filename)
        self.use_current=QPushButton('Selecionar pasta exibida');self.use_current.setObjectName('Primary');self.use_current.clicked.connect(self.accept_current_folder);box.addWidget(self.use_current)
        layout=self.layout();layout.addWidget(panel,0,layout.columnCount(),layout.rowCount(),1)
        self.currentChanged.connect(self.show_preview)

    def accept_current_folder(self):
        self.selected_folder=self.directory().absolutePath()
        if os.path.isdir(self.selected_folder):QDialog.accept(self)

    def accept(self):
        paths=self.selectedFiles()
        selected=paths[0] if paths else self.directory().absolutePath()
        self.selected_folder=selected if os.path.isdir(selected) else os.path.dirname(selected)
        if os.path.isdir(self.selected_folder):QDialog.accept(self)

    def show_preview(self,path):
        self.preview_path=path if os.path.isfile(path) else None
        self._token+=1;self._pending=None;self.preview.clear();self.filename.setText(os.path.basename(path))
        if os.path.splitext(path)[1].lower() not in IMAGE_EXTENSIONS or os.path.isdir(path):
            self.preview.setText('Selecione uma imagem');return
        self.preview.setText('Carregando prévia…')
        self._pending=(path,self._token)
        self._start_pending()

    def open_preview(self,event):
        if event.button()==Qt.LeftButton and self.preview_path:
            from ui.photo_viewer import show_photo
            show_photo(self.preview_path,self)

    def _start_pending(self):
        if self._job is not None or self._pending is None:return
        path,token=self._pending;self._pending=None
        self._job=PreviewJob(path,token);self._job.signals.ready.connect(self.preview_ready)
        QThreadPool.globalInstance().start(self._job)

    @Slot(int,QImage)
    def preview_ready(self,token,image):
        self._job=None
        if token==self._token:
            if image.isNull():self.preview.setText('Prévia indisponível para este arquivo.')
            else:self.preview.setPixmap(QPixmap.fromImage(image).scaled(400,440,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        self._start_pending()
