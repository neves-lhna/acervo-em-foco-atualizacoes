import os
from core.file_errors import file_error_message
from PySide6.QtCore import Qt,QTimer,QUrl,QSize
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QTreeWidget,QPushButton,QProgressBar,QMenu,QApplication,QWidget,QMessageBox
from ui.table_sorting import SortableItem,SORT_ROLE,enable_header_sort
from ui.folders_tab import CoverageDelegate


class PendingFoldersDialog(QDialog):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner;self.snapshot=None
        self.items={};self.open_failures=set()
        self.setWindowTitle('Pastas com pendências');self.setWindowFlag(Qt.WindowMaximizeButtonHint,True);self.resize(1050,650)
        layout=QVBoxLayout(self)
        self.summary=QLabel();layout.addWidget(self.summary)
        self.tree=QTreeWidget();self.tree.setHeaderLabels(['Pasta','Progresso','Analisadas','Total','Pendentes','Situação'])
        self.tree.setColumnWidth(0,380);self.tree.setItemDelegateForColumn(1,CoverageDelegate(self.tree))
        enable_header_sort(self.tree);layout.addWidget(self.tree,1)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu);self.tree.customContextMenuRequested.connect(self.menu)
        self.tree.itemSelectionChanged.connect(self.sync_controls)
        self.tree.itemClicked.connect(self.show_failures)
        self.active=QLabel();self.active.setWordWrap(True);layout.addWidget(self.active)
        row=QHBoxLayout();self.start=QPushButton('Continuar análise da pasta');self.pause=QPushButton('Pausar');self.stop=QPushButton('Parar coleta')
        self.progress=QProgressBar();self.progress.setFormat('%p%')
        for widget in (self.start,self.pause,self.stop):row.addWidget(widget)
        row.addWidget(self.progress,1);layout.addLayout(row)
        self.status=QLabel();self.status.setWordWrap(True);layout.addWidget(self.status)
        self.start.clicked.connect(self.start_selected);self.pause.clicked.connect(owner.cache_pause_btn.click);self.stop.clicked.connect(owner.cache_stop_btn.click)
        self.timer=QTimer(self);self.timer.setInterval(400);self.timer.timeout.connect(self.refresh)

    def showEvent(self,event):
        super().showEvent(event);self.timer.start();self.refresh()

    def closeEvent(self,event):
        self.timer.stop();super().closeEvent(event)

    def selected(self):
        item=self.tree.currentItem();return item.data(0,Qt.UserRole) if item else None

    def show_failures(self,item,column):
        if column!=5 or item.text(5)!='Verificar falhas':return
        path=item.data(0,Qt.UserRole)
        self.open_failures.add(path)
        failures=self.owner.history.failures_for(path)
        cell=QWidget();layout=QVBoxLayout(cell);layout.setContentsMargins(3,3,3,3)
        if not failures:
            label=QLabel('Falha antiga sem detalhes. Continue a análise para registrar o motivo.');label.setWordWrap(True);layout.addWidget(label)
        for file,reason in failures:
            reason = file_error_message(reason)
            row=QHBoxLayout();label=QLabel(os.path.basename(file));label.setWordWrap(True);label.setToolTip(reason);row.addWidget(label,1)
            from core.image_loader import RAW_EXTENSIONS
            if os.path.splitext(file)[1].lower() in RAW_EXTENSIONS:
                jpg=QPushButton('JPG');jpg.setToolTip('Verificar se o conteúdo é JPEG e criar uma cópia .jpg na mesma pasta, preservando o original.')
                jpg.clicked.connect(lambda checked=False,p=file:self.create_jpeg_copy(p));row.addWidget(jpg)
            for text,tip,callback in (
                ('?',reason,lambda checked=False,r=reason:QMessageBox.information(self,'Motivo da falha',r)),
                ('📁','Abrir pasta com o arquivo selecionado',lambda checked=False,p=file:self.reveal_failure(p)),
                ('×','Mover este arquivo para a Lixeira',lambda checked=False,p=file:self.trash_failure(p))):
                button=QPushButton(text);button.setFixedWidth(25);button.setToolTip(tip)
                button.setStyleSheet('QPushButton {background:transparent;border:none;padding:0;'+('color:#e53935;' if text=='×' else '')+'}')
                button.clicked.connect(callback);row.addWidget(button)
            layout.addLayout(row)
        # The item delegate still paints its text underneath an embedded widget.
        # Clear that text before replacing the status with the expanded details.
        item.setText(5,'')
        item.setSizeHint(5,cell.sizeHint());self.tree.setItemWidget(item,5,cell)

    def reveal_failure(self,path):
        from core.utils_os import reveal_in_file_manager
        reveal_in_file_manager(path)

    def create_jpeg_copy(self,path):
        main=self.owner.window()
        if main._busy() or main._cache_running():
            QMessageBox.information(self,'Análise em andamento','Aguarde a conclusão da análise antes de criar a cópia JPG.');return
        box=QMessageBox(self);box.setWindowTitle('Criar cópia JPG')
        box.setText(f'Verificar {os.path.basename(path)} e criar uma cópia .jpg na mesma pasta?')
        box.setInformativeText('A cópia só será criada se o conteúdo já for JPEG. O original será preservado, sem recompressão. Se o nome existir, será acrescentado um número.')
        create=box.addButton('Verificar e criar cópia',QMessageBox.AcceptRole)
        box.addButton('Cancelar',QMessageBox.RejectRole);box.exec()
        if box.clickedButton()!=create:return
        try:
            from core.jpeg_copy import copy_mislabeled_jpeg
            target=copy_mislabeled_jpeg(path)
        except Exception as exc:
            QMessageBox.warning(self,'Cópia JPG não criada',file_error_message(exc));return
        QMessageBox.information(self,'Cópia JPG criada',f'{os.path.basename(target)}\n\nOriginal preservado. Continue a análise para atualizar a lista de falhas.')
        main._start_inventory([os.path.dirname(path)])

    def trash_failure(self,path):
        main=self.owner.window()
        if main._cache_running() or main._busy():
            QMessageBox.information(self,'Coleta em andamento','Pare a coleta e aguarde sua conclusão antes de excluir este arquivo.');return
        if not os.path.isfile(path):
            QMessageBox.information(self,'Arquivo indisponível','O arquivo não está mais disponível nesta pasta.');return
        box=QMessageBox(QMessageBox.Warning,'Excluir arquivo com falha',f'Mover {os.path.basename(path)} para a Lixeira? A falha de leitura não significa que a foto esteja danificada.',parent=self)
        yes=box.addButton('Mover para a Lixeira',QMessageBox.AcceptRole);box.addButton('Cancelar',QMessageBox.RejectRole);box.exec()
        if box.clickedButton()!=yes:return
        rid=None
        try:
            from send2trash import send2trash
            rid=main.deletion_history.begin(path,os.stat(path).st_size,None)
            send2trash(path);main.deletion_history.finish(rid)
            main._start_inventory([os.path.dirname(path)])
        except Exception as exc:
            if rid is not None:main.deletion_history.finish(rid,str(exc))
            QMessageBox.warning(self,'Não foi possível excluir',str(exc))

    def refresh(self):
        records=tuple(self.owner.pending_records)
        if records!=self.snapshot:
            from core.folder_history import path_key
            selected=self.selected();self.snapshot=records
            vertical=self.tree.verticalScrollBar().value();horizontal=self.tree.horizontalScrollBar().value()
            expanded={key:item.isExpanded() for key,item in self.items.items()}
            keys={path_key(row[0]) for row in records}
            rebuild=keys!=set(self.items)
            sorting=self.tree.isSortingEnabled();self.tree.setSortingEnabled(False)
            if rebuild:self.tree.clear()
            items={}
            for path,total,indexed,errors,status in sorted(records,key=lambda row:len(os.path.abspath(row[0]))):
                percent=min(99.9,100*indexed/total) if total else 0
                key=path_key(path)
                item=SortableItem() if rebuild else self.items[key]
                for column,text in enumerate([os.path.basename(os.path.normpath(path)) or path,f'{percent:.1f}%',str(indexed),str(total),str(max(0,total-indexed))]):item.setText(column,text)
                if not self.tree.itemWidget(item,5):item.setText(5,status)
                elif status!='Verificar falhas':
                    self.tree.removeItemWidget(item,5);item.setSizeHint(5,QSize());item.setText(5,status);self.open_failures.discard(path)
                item.setData(0,Qt.UserRole,path);item.setToolTip(0,path);item.setData(1,Qt.UserRole,percent)
                for column,value in ((1,percent),(2,indexed),(3,total),(4,max(0,total-indexed))):item.setData(column,SORT_ROLE,value)
                if status in ('Aguardando coleta','Subpastas pendentes — coletar cache','Alteração detectada — validar cache'):
                    item.setData(1,Qt.UserRole,None)
                    for column in (1,2,3,4):item.setText(column,'—');item.setData(column,SORT_ROLE,None)
                    item.setText(4,'A conferir')
                parent_path=os.path.dirname(os.path.abspath(path));parent=None
                while parent_path!=os.path.dirname(parent_path):
                    parent=items.get(path_key(parent_path))
                    if parent is not None:break
                    parent_path=os.path.dirname(parent_path)
                if rebuild:
                    if parent is None:self.tree.addTopLevelItem(item)
                    else:parent.addChild(item);parent.setExpanded(True)
                items[path_key(path)]=item
                if path==selected:self.tree.setCurrentItem(item)
                if rebuild and path in self.open_failures and status=='Verificar falhas':self.show_failures(item,5)
            self.items=items
            self.open_failures.intersection_update(row[0] for row in records)
            if rebuild:
                for key,item in items.items():
                    if key in expanded:item.setExpanded(expanded[key])
            self.tree.setSortingEnabled(sorting)
            self.tree.verticalScrollBar().setValue(vertical);self.tree.horizontalScrollBar().setValue(horizontal)
            self.summary.setText(f'{len(records)} pasta(s) com fotos pendentes, falhas ou alterações a conferir. Inclui pastas nunca analisadas e suas pastas superiores.' if records else 'Nenhuma pasta com análise pendente.')
        self.sync_controls()

    def sync_controls(self):
        owner=self.owner;path=self.selected()
        self.start.setEnabled(bool(path and os.path.isdir(path) and getattr(owner,'cache_priority_enabled',owner.cache_start_btn.isEnabled())))
        self.pause.setText(owner.cache_pause_btn.text());self.pause.setEnabled(owner.cache_pause_btn.isEnabled())
        self.stop.setEnabled(owner.cache_stop_btn.isEnabled())
        self.progress.setRange(owner.cache_progress.minimum(),owner.cache_progress.maximum());self.progress.setValue(owner.cache_progress.value())
        self.active.setText('Coleta: '+owner.cache_folder_label.text())
        self.status.setText(owner.cache_status.text())

    def start_selected(self):
        if self.start.isEnabled():self.owner.cache_requested.emit(self.selected());self.sync_controls()

    def menu(self,position):
        item=self.tree.itemAt(position)
        if item is None:return
        self.tree.setCurrentItem(item);path=self.selected();menu=QMenu(self)
        action=menu.addAction('Continuar análise desta pasta');action.setEnabled(self.start.isEnabled());action.triggered.connect(self.start_selected)
        action=menu.addAction(self.pause.text());action.setEnabled(self.pause.isEnabled());action.triggered.connect(self.owner.cache_pause_btn.click)
        action=menu.addAction('Parar coleta atual');action.setEnabled(self.stop.isEnabled());action.triggered.connect(self.owner.cache_stop_btn.click)
        menu.addSeparator()
        action=menu.addAction('Abrir pasta no Explorer');action.setEnabled(os.path.isdir(path));action.triggered.connect(lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(path)))
        menu.addAction('Copiar caminho da pasta').triggered.connect(lambda:QApplication.clipboard().setText(path))
        menu.exec(self.tree.viewport().mapToGlobal(position))
