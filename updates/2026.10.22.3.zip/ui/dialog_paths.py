"""Explicit dialog locations: never silently default to the program directory."""
import os
from PySide6.QtCore import QStandardPaths,QSettings
from core.app_profile import current_profile


def remember_folder(path):
    if path:
        settings=QSettings('AcervoEmFoco',current_profile().settings_name)
        settings.setValue('last_selected_folder',os.path.abspath(path));settings.sync()


def last_folder():
    return QSettings('AcervoEmFoco',current_profile().settings_name).value('last_selected_folder','',type=str)


def initial_directory(*candidates):
    for path in candidates:
        if not path:continue
        path=os.path.abspath(path)
        while not os.path.isdir(path):
            parent=os.path.dirname(path)
            if parent==path:break
            path=parent
        if os.path.isdir(path):return path
    pictures = QStandardPaths.writableLocation(QStandardPaths.PicturesLocation)
    return pictures if pictures and os.path.isdir(pictures) else os.path.expanduser('~')
