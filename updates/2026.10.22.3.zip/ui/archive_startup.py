"""Responsive startup before MainWindow opens database connections."""
from PySide6.QtCore import QThread, Signal, QLockFile, QSettings
from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QProgressBar, QMessageBox
from core.archive_location import synchronize, relocated
from core.app_profile import current_profile

class LocationWorker(QThread):
    progress = Signal(str)
    result = Signal(object)
    def run(self):
        try:
            self.result.emit(synchronize(current_profile().data_directory(), self.progress.emit))
        except Exception as error:
            self.result.emit({'error': str(error)})

class LocationDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Localizando acervo — ' + current_profile().label)
        self.setMinimumWidth(520)
        layout = QVBoxLayout(self)
        self.label = QLabel('Verificando a localização do acervo…')
        self.label.setWordWrap(True)
        layout.addWidget(self.label)
        bar = QProgressBar(); bar.setRange(0, 0); layout.addWidget(bar)
        self.output = None
        self.worker = LocationWorker(self)
        self.worker.progress.connect(self.label.setText)
        self.worker.result.connect(self.completed)
        self.worker.finished.connect(self.accept)
    def completed(self, result):
        self.output = result
    def reject(self):
        # A cross-database transaction must finish or roll back before UI exit.
        if not self.worker.isRunning():
            super().reject()
    def closeEvent(self, event):
        if self.worker.isRunning():
            event.ignore()
        else:
            super().closeEvent(event)

def prepare_archive(app):
    data = current_profile().data_directory()
    data.mkdir(parents=True, exist_ok=True)
    lock = QLockFile(str(data/'application.lock'))
    lock.setStaleLockTime(0)
    if not lock.tryLock(0):
        QMessageBox.information(None, 'Acervo em uso', 'Esta edição já está aberta. Use a janela existente.')
        return None, None
    app.archive_lock = lock
    from core.database_activation import reconcile
    try:
        from core.backup_service import reconcile_restore
        reconcile_restore(data, current_profile().key)
        reconcile(data, current_profile().key)
    except Exception:
        QMessageBox.warning(None, 'Proteção dos dados',
                            'Não foi possível concluir a recuperação de uma ativação interrompida. '
                            'A abertura foi bloqueada para preservar os bancos e os backups. Solicite suporte.')
        lock.unlock()
        return None, None
    from core.database import key_for_database, DatabaseProtectionError
    try:
        key_for_database(data/'folder_history.db')
    except DatabaseProtectionError as error:
        from ui.database_recovery import DatabaseRecoveryDialog
        recovery = DatabaseRecoveryDialog(data, current_profile().key)
        if recovery.exec() != QDialog.Accepted:
            lock.unlock()
            return None, None
        try:
            key_for_database(data/'folder_history.db')
        except DatabaseProtectionError as error:
            QMessageBox.warning(None, 'Proteção dos dados', str(error))
            lock.unlock()
            return None, None
    dialog = LocationDialog()
    dialog.worker.start()
    dialog.exec()
    dialog.worker.wait()
    result = dialog.output or {'error': 'Não foi possível concluir a verificação.'}
    if result.get('error'):
        QMessageBox.warning(None, 'Localização do acervo', 'Os caminhos não puderam ser atualizados. A inicialização foi interrompida para preservar os dados.\n\n' + result['error'])
        return None, None
    if result['mappings']:
        settings = QSettings('AcervoEmFoco', current_profile().settings_name)
        for key in settings.allKeys():
            value = settings.value(key)
            if isinstance(value, str):
                settings.setValue(key, relocated(value, result['mappings']))
        settings.sync()
    return lock, result
