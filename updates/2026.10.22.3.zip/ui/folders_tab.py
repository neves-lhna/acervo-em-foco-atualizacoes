import os
from ui.table_sorting import SortableItem,SORT_ROLE,enable_header_sort
from datetime import datetime
from PySide6.QtCore import Qt, Signal, QSignalBlocker,QUrl
from PySide6.QtGui import QColor, QPainter,QDesktopServices
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QProgressBar, QGroupBox, QTreeWidget, QTreeWidgetItem, QHeaderView, QStyledItemDelegate, QFileDialog, QStyle,QMenu,QApplication)
from core.folder_history import path_key
from ui.dialog_paths import initial_directory,remember_folder,last_folder


class CoverageDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        percent = index.data(Qt.UserRole)
        if percent is None:
            return super().paint(painter, option, index)
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        rect = option.rect.adjusted(8, 11, -8, -11)
        painter.setPen(Qt.NoPen)
        from ui.theme import is_dark
        dark=is_dark()
        painter.setBrush(QColor('#36434e' if dark else '#e4edf2'))
        painter.drawRoundedRect(rect, 5, 5)
        fill = rect.adjusted(0, 0, 0, 0)
        fill.setWidth(round(rect.width() * percent / 100))
        painter.setBrush(QColor('#258a7c' if dark else '#70c9b4'))
        painter.drawRoundedRect(fill, 5, 5)
        painter.setPen(QColor('#ffffff' if dark else '#183c37'))
        painter.drawText(option.rect, Qt.AlignCenter, f'{percent:.1f}%')
        # Custom-painted cells need the same bottom/right borders as the table.
        selected = bool(option.state & QStyle.State_Selected)
        separator = QColor(8, 126, 112, 55) if selected else QColor(88, 112, 131, 40)
        painter.setRenderHint(QPainter.Antialiasing, False)
        painter.setPen(separator)
        cell = option.rect
        painter.drawLine(cell.left(), cell.bottom(), cell.right(), cell.bottom())
        painter.drawLine(cell.right(), cell.top(), cell.right(), cell.bottom() - 1)
        painter.restore()


class FoldersTab(QWidget):
    inventory_requested = Signal(list)
    folder_chosen = Signal(str)
    duplicate_requested = Signal(str)
    cache_requested = Signal(str)

    def __init__(self, history, parent=None):
        super().__init__(parent)
        self.history = history
        self.items = {}
        self._last_directory = None
        self.hide_completed=False
        self.pending_records=[];self.pending_popup=None
        self.non_image_records=[];self.non_image_popup=None
        self.extension_popup=None
        self.setObjectName('Page')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        title = QLabel('Seu acervo, com progresso visível')
        title.setObjectName('PageTitle')
        layout.addWidget(title)
        note = QLabel('Acompanhe o cache de cada pasta. Fotos sem rostos também contam como analisadas.')
        note.setObjectName('Muted')
        note.setWordWrap(True)
        layout.addWidget(note)
        stats = QHBoxLayout()
        self.stat_values = []
        for text in ('PASTAS ACOMPANHADAS', 'PASTAS COM FOTOS CONCLUÍDAS', 'PASTAS COM PENDÊNCIAS',
                     'OUTRAS PASTAS'):
            frame = QFrame(); frame.setObjectName('StatCard')
            box = QVBoxLayout(frame)
            number = QLabel('0'); number.setObjectName('StatValue')
            caption = QLabel(text); caption.setObjectName('Muted')
            box.addWidget(number); box.addWidget(caption)
            stats.addWidget(frame); self.stat_values.append(number)
            if text=='PASTAS COM PENDÊNCIAS':
                frame.setCursor(Qt.PointingHandCursor)
                frame.setToolTip('Clique para acompanhar e continuar as análises pendentes.')
                frame.mouseReleaseEvent=lambda event:self.open_pending() if event.button()==Qt.LeftButton else None
            elif text=='OUTRAS PASTAS':
                frame.setCursor(Qt.PointingHandCursor)
                frame.setToolTip('Clique para consultar tamanho, tipos de arquivo e pastas vazias.')
                frame.mouseReleaseEvent=lambda event:self.open_non_image() if event.button()==Qt.LeftButton else None
        layout.addLayout(stats)
        buttons = QHBoxLayout()
        self.add_btn = QPushButton('+ Acompanhar pasta'); self.add_btn.setObjectName('Primary')
        self.add_btn.clicked.connect(self.add_folder)
        self.refresh_btn = QPushButton('Atualizar inventário'); self.refresh_btn.clicked.connect(self.refresh_inventory)
        self.refresh_btn.setToolTip('Conta as fotos e valida o cache existente para atualizar os números. Não executa reconhecimento facial; use Coletar cache para processar fotos pendentes.')
        self.use_btn = QPushButton('Usar pasta na busca'); self.use_btn.clicked.connect(self.use_folder)
        self.clear_completed_btn=QPushButton('Limpar concluídas')
        self.clear_completed_btn.setToolTip('Ocultar somente as pastas concluídas da tabela. Fotos, cache e histórico são preservados.')
        self.clear_completed_btn.clicked.connect(self.toggle_completed)
        buttons.addWidget(self.add_btn); buttons.addWidget(self.refresh_btn); buttons.addWidget(self.use_btn);buttons.addWidget(self.clear_completed_btn); buttons.addStretch()
        layout.addLayout(buttons)
        self.extensions_btn=QPushButton('Revisar extensões')
        self.extensions_btn.setToolTip('Localize arquivos JPEG com extensão RAW em todas as pastas registradas, incluindo as concluídas. Não altera a situação das análises.')
        self.extensions_btn.clicked.connect(self.open_extensions)
        buttons.insertWidget(4,self.extensions_btn)
        cache_box = QGroupBox('Preparar cache sem escolher um rosto')
        cache_layout = QVBoxLayout(cache_box)
        self.cache_folder_label = QLabel('Selecione uma pasta na tabela ou escolha uma ao iniciar.')
        self.cache_folder_label.setWordWrap(True)
        cache_layout.addWidget(self.cache_folder_label)
        cache_controls = QHBoxLayout()
        self.cache_start_btn = QPushButton('Coletar cache'); self.cache_start_btn.setObjectName('Primary')
        self.cache_pause_btn = QPushButton('Pausar'); self.cache_pause_btn.setEnabled(False)
        self.cache_stop_btn = QPushButton('Parar coleta'); self.cache_stop_btn.setObjectName('Stop'); self.cache_stop_btn.setEnabled(False)
        self.cache_progress = QProgressBar(); self.cache_progress.setRange(0,100); self.cache_progress.setValue(0)
        for button in (self.cache_start_btn, self.cache_pause_btn, self.cache_stop_btn):
            cache_controls.addWidget(button)
        cache_controls.addWidget(self.cache_progress,1)
        cache_layout.addLayout(cache_controls)
        self.cache_status = QLabel('Inclui subpastas e fotos sem rostos. O progresso salvo é reaproveitado ao iniciar novamente.')
        self.cache_status.setWordWrap(True); self.cache_status.setObjectName('Muted')
        cache_layout.addWidget(self.cache_status)
        layout.addWidget(cache_box)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(['Pasta', 'Progresso', 'Analisadas', 'Total', 'Pendentes', 'Situação', 'Conferido em'])
        enable_header_sort(self.tree)
        self.tree.setUniformRowHeights(True)
        self.tree.setItemDelegateForColumn(1, CoverageDelegate(self.tree))
        self.tree.setColumnWidth(0, 310)
        for col, width in ((1,125),(2,90),(3,90),(4,95),(5,135),(6,140)):
            self.tree.setColumnWidth(col,width)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.setRootIsDecorated(True)
        self.tree.itemDoubleClicked.connect(self.activate_folder_cell)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.folder_menu)
        layout.addWidget(self.tree, 1)
        self.details_label=QLabel('Selecione uma pasta para consultar o que já foi realizado.');self.details_label.setWordWrap(True)
        layout.addWidget(self.details_label)
        self.tree.itemSelectionChanged.connect(self.show_folder_details)
        self.message = QLabel('Adicione uma pasta para conferir o que já está no cache.')
        self.message.setObjectName('Muted'); self.message.setWordWrap(True)
        layout.addWidget(self.message)
        footer = QLabel('Atualizar inventário conta fotos e valida o cache existente. Coletar cache processa as fotos pendentes e salva os rostos.')
        footer.setObjectName('Muted'); footer.setWordWrap(True)
        layout.addWidget(footer)
        self.tree.itemExpanded.connect(self._branch_toggled)
        self.tree.itemCollapsed.connect(self._branch_toggled)
        self.reload()

    def toggle_completed(self):
        self.hide_completed=not self.hide_completed
        self.clear_completed_btn.setText('Mostrar concluídas' if self.hide_completed else 'Limpar concluídas')
        self.reload()


    def open_pending(self):
        if self.pending_popup is None:
            from ui.pending_folders_dialog import PendingFoldersDialog
            self.pending_popup=PendingFoldersDialog(self)
        self.pending_popup.refresh();self.pending_popup.show();self.pending_popup.raise_();self.pending_popup.activateWindow()

    def open_non_image(self):
        if self.non_image_popup is None:
            from ui.non_image_folders_dialog import NonImageFoldersDialog
            self.non_image_popup=NonImageFoldersDialog(self)
        self.non_image_popup.refresh(self.non_image_records)
        self.non_image_popup.show();self.non_image_popup.raise_();self.non_image_popup.activateWindow()

    def open_extensions(self):
        if self.extension_popup is None:
            from ui.extension_review import ExtensionReview
            self.extension_popup=ExtensionReview(self)
        self.extension_popup.show();self.extension_popup.raise_();self.extension_popup.activateWindow()

    def activate_folder_cell(self,item,column):
        if column==5:
            if item.text(5)=='Verificar falhas':
                self.open_pending()
                path=item.data(0,Qt.UserRole)
                from PySide6.QtWidgets import QTreeWidgetItemIterator
                iterator=QTreeWidgetItemIterator(self.pending_popup.tree)
                while iterator.value():
                    row=iterator.value()
                    if row.data(0,Qt.UserRole)==path:
                        self.pending_popup.tree.setCurrentItem(row)
                        self.pending_popup.tree.scrollToItem(row)
                        self.pending_popup.show_failures(row,5)
                        break
                    iterator+=1
            return
        if column==0:self.use_folder()

    def folder_menu(self,position):
        item=self.tree.itemAt(position)
        if item is None:return
        self.tree.setCurrentItem(item)
        path=item.data(0,Qt.UserRole)
        if not path:return
        available=os.path.isdir(path)
        menu=QMenu(self)
        def action(text,callback,enabled=True):
            entry=menu.addAction(text);entry.setEnabled(enabled);entry.triggered.connect(callback)
        action('Abrir pasta no Explorer',lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(path)),available)
        action('Copiar caminho da pasta',lambda:QApplication.clipboard().setText(path))
        if not available:
            parent=os.path.dirname(path)
            action('Abrir pasta superior',lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(parent)),os.path.isdir(parent))
            action('Sincronizar lista com o Explorer',lambda:self.inventory_requested.emit([parent if os.path.isdir(parent) else path]),self.refresh_btn.isEnabled())
        menu.addSeparator()
        action('Usar pasta na busca de fotos',lambda:self.folder_chosen.emit(path),available and self.use_btn.isEnabled())
        action('Verificar duplicidade nesta pasta',lambda:self.duplicate_requested.emit(path),available and self.use_btn.isEnabled())
        action('Atualizar inventário desta pasta',lambda:self.inventory_requested.emit([path]),available and self.refresh_btn.isEnabled())
        action('Continuar análise desta pasta',lambda:self.cache_requested.emit(path),available and getattr(self,'cache_priority_enabled',self.cache_start_btn.isEnabled()))
        menu.addSeparator()
        action('Recolher subpastas' if item.isExpanded() else 'Mostrar subpastas',lambda:item.setExpanded(not item.isExpanded()),item.childIndicatorPolicy()!=QTreeWidgetItem.DontShowIndicator)
        menu.exec(self.tree.viewport().mapToGlobal(position))

    def _branch_toggled(self, item):
        self.tree.setCurrentItem(item)
        self.reload()

    def selected_folder(self):
        item = self.tree.currentItem()
        return item.data(0, Qt.UserRole) if item is not None else None

    def show_folder_details(self):
        path=self.selected_folder()
        if not path or not hasattr(self.history,'folder_details'):return
        seen,cache=self.history.folder_details(path)
        text='Detectada em: '+(seen[0].replace('T',' ') if seen else 'não registrado no histórico antigo')
        if cache:
            stamp,faces,without,reused,computed,state=cache
            text+=f' | Última coleta: {stamp.replace("T"," ")} | {faces} rostos no cache · {without} fotos sem rostos · {reused} reaproveitadas · {computed} processadas nessa coleta.'
            if state!='ready':text+=' Coleta não concluída integralmente.'
        else:text+=' | Resumo detalhado da coleta ainda não registrado. O histórico anterior foi preservado; Coletar cache valida e registra esse resumo.'
        self.details_label.setText(text)

    def dialog_directory(self):
        roots, _ = self.history.records()
        return initial_directory(last_folder(), self.selected_folder(), self._last_directory, *(r[1] for r in roots))

    def add_folder(self):
        path = QFileDialog.getExistingDirectory(self, 'Pasta para acompanhar', self.dialog_directory())
        if path:
            remember_folder(path)
            self._last_directory = path
            self.history.register(path)
            self.reload()
            self.inventory_requested.emit([path])

    def refresh_inventory(self):
        roots, _ = self.history.records()
        self.inventory_requested.emit([r[1] for r in roots])

    def use_folder(self):
        item = self.tree.currentItem()
        if item is not None and self.use_btn.isEnabled():
            self.folder_chosen.emit(item.data(0, Qt.UserRole))

    def set_busy(self, busy):
        for button in (self.add_btn, self.refresh_btn, self.use_btn):
            button.setEnabled(not busy)

    def reload(self):
        roots, rows = self.history.records()
        discovered=getattr(self.history,'discovered_keys',lambda:set())()
        root_map = {r[0]: r for r in roots}
        coverage = {(r[0], r[1]): r for r in rows}
        # Count the complete inventory, not just expanded tree branches or roots.
        # Overlapping tracked roots may contain the same folder: use its latest snapshot.
        counted={}
        latest_records={}
        for record in rows:
            root,key,path,total,indexed,errors=record
            checked=root_map[root][3] or ''
            if (key not in counted or checked>counted[key][0]
                    or (checked==counted[key][0] and len(root)>len(latest_records[key][0]))):
                counted[key]=(checked,total,indexed,errors)
                latest_records[key]=record
        unknown_roots={root[0] for root in roots if root[0] not in counted}
        for root in roots:counted.setdefault(root[0],('',0,0,0))
        from core.folder_history import is_within
        affected={key for key in counted if any(is_within(child,key) for child in discovered)}
        completed=sum(total>0 and indexed==total and not errors and key not in affected for key,(_,total,indexed,errors) in counted.items())
        pending=sum(key in affected or indexed<total or errors>0
                    for key,(_,total,indexed,errors) in counted.items())
        total_folders=len(counted)
        photo_folders=sum(total>0 for _,total,_,_ in counted.values())
        self.non_image_records=sorted(
            (latest_records[key][2] if key in latest_records else root_map[key][1])
            for key,(_,total,_,_) in counted.items() if total==0 and key not in affected and key not in unknown_roots)
        self.pending_records=[]
        for key,(_,total,indexed,errors) in counted.items():
            if key not in affected and not (indexed<total or errors>0):continue
            if key not in latest_records:continue
            root,_,path,*_=latest_records[key]
            state=root_map[root][2]
            status='Verificar falhas' if errors else ('Em análise' if state=='scanning' else ('Aguardando coleta' if indexed==0 else 'Pendente de conclusão'))
            if key in affected:status=('Alteração detectada — validar cache' if total else 'Aguardando coleta') if key in discovered else 'Subpastas pendentes — coletar cache'
            self.pending_records.append((path,total,indexed,errors,status))
        # A standalone scan is a new snapshot, not a second folder in the UI.
        # Keep the broadest existing tree position and overlay the latest values.
        from core.folder_history import is_within
        display_owner={}
        for key,record in latest_records.items():
            candidates=[r[0] for r in roots if (r[0],key) in coverage and is_within(record[2],r[1])]
            display_owner[key]=min(candidates,key=len) if candidates else record[0]
        rows=[(display_owner[key],key,*record[2:]) for key,record in latest_records.items()]
        roots=[r for r in roots if display_owner.get(r[0],r[0])==r[0]]
        coverage={(r[0],r[1]):r for r in rows}
        selected_path = self.selected_folder()
        expanded = {k for k, item in self.items.items() if item.isExpanded()}
        expanded.update((r[0], r[0]) for r in roots if (r[0], r[0]) not in self.items)
        if selected_path and any(k[0] not in root_map and item is self.tree.currentItem() for k, item in self.items.items()):
            for root, key in coverage:
                if key == path_key(selected_path):
                    parent = os.path.dirname(selected_path)
                    while (root, path_key(parent)) in coverage:
                        expanded.add((root, path_key(parent)))
                        if path_key(parent) == root:
                            break
                        parent = os.path.dirname(parent)
        parents = {(r[0], path_key(os.path.dirname(r[2]))) for r in rows if r[0] != r[1]}
        # Materialize only the branches the user opened, keeping the Windows
        # accessibility table small even for collections with thousands of folders.
        desired = {(r[0], r[0]) for r in roots}
        for root, key, path, *_ in sorted(rows, key=lambda r: len(r[2])):
            parent = (root, path_key(os.path.dirname(path)))
            if parent in desired and parent in expanded:
                desired.add((root, key))
        rows = [r for r in rows if (r[0], r[1]) in desired]
        blocker = QSignalBlocker(self.tree)
        selection_moved = False
        if set(self.items) != desired:
            self.tree.clear(); self.items = {}
            for key, path, *_ in roots:
                item = SortableItem(self.tree)
                item.setText(0, os.path.basename(path.rstrip('/\\')) or path)
                item.setData(0, Qt.UserRole, path); item.setToolTip(0,path)
                self.items[(key,key)] = item
            for root,key,path,*_ in sorted(rows,key=lambda r:len(r[2])):
                if (root,key) in self.items:
                    continue
                parent_key = path_key(os.path.dirname(path))
                parent = self.items.get((root,parent_key), self.items[(root,root)])
                item = SortableItem(parent)
                item.setText(0,os.path.basename(path)); item.setData(0,Qt.UserRole,path); item.setToolTip(0,path)
                self.items[(root,key)] = item
            for key,item in self.items.items():
                item.setExpanded(key in expanded)
                has_children = key in parents
                item.setChildIndicatorPolicy(QTreeWidgetItem.ShowIndicator if has_children else QTreeWidgetItem.DontShowIndicator)
            if selected_path:
                for item in self.items.values():
                    if path_key(item.data(0, Qt.UserRole)) == path_key(selected_path):
                        self.tree.setCurrentItem(item)
                        parent = item.parent()
                        while parent is not None:
                            parent.setExpanded(True)
                            parent = parent.parent()
                        self.tree.scrollToItem(item)
                        selection_moved = True
                        break
        for (root,key),item in self.items.items():
            source=latest_records.get(key)
            source_root=source[0] if source else root
            _,root_path,state,checked,message = root_map[source_root]
            row = coverage.get((root,key))
            if row and key not in affected:
                _,_,path,total,indexed,errors = row
                percent = min(100 if indexed==total and not errors else 99.9, 100*indexed/total) if total else 0
                status = 'Concluída' if total and indexed==total and not errors else ('Sem imagens' if not total else 'Parcial')
                if status=='Concluída' and message.startswith('Inventário validado:'):status='Cache validado'
                if errors: status = 'Verificar falhas'
                if source_root==key:
                    if state == 'unavailable': status = 'Indisponível'
                    elif state == 'inventory': status = 'Conferindo…'
                    elif state == 'scanning': status = 'Em análise'
                    elif state == 'interrupted' and indexed<total: status = 'Interrompida'
                    elif state == 'error': status = 'Verificar falhas'
                item.setData(1,Qt.UserRole,percent)
                item.setData(1,SORT_ROLE,percent)
                item.setText(1,f'{percent:.1f}%')
                for col,value in ((2,indexed),(3,total),(4,max(0,total-indexed))):
                    item.setData(col,SORT_ROLE,value)
                    item.setText(col,f'{value:,}'.replace(',','.')); item.setTextAlignment(col,Qt.AlignRight|Qt.AlignVCenter)
                item.setText(5,status)
                item.setToolTip(5,message or (f'{errors} ocorrência(s) de leitura' if errors else status))
            else:
                item.setData(1,Qt.UserRole,None)
                for col in (1,2,3,4):item.setData(col,SORT_ROLE,None)
                for col in (1,2,3,4): item.setText(col,'—')
                if key in affected:item.setText(4,'A conferir')
                item.setText(5,(('Alteração detectada — validar cache' if row and row[3] else 'Aguardando coleta') if key in discovered else 'Subpastas pendentes — coletar cache') if key in affected else ('Conferindo…' if state=='inventory' else ('Indisponível' if state=='unavailable' else 'Não conferida')))
                item.setToolTip(5,'Existem pastas ainda não conferidas. O percentual será calculado após Coletar cache.' if key in affected else message)
            item.setText(6,datetime.fromisoformat(checked).strftime('%d/%m %H:%M') if checked else '—')
            item.setData(6,SORT_ROLE,checked or '')
            item.setToolTip(6,datetime.fromisoformat(checked).strftime('%d/%m/%Y %H:%M:%S') if checked else 'Ainda não conferida')
            item.setHidden(self.hide_completed and item.text(5) in ('Concluída','Cache validado'))
            if item.isHidden() and item is self.tree.currentItem():self.tree.setCurrentItem(None)
        for label,value in zip(self.stat_values,(total_folders,f'{completed} / {photo_folders}',pending,len(self.non_image_records))):
            label.setText(str(value))
        self.stat_values[0].setToolTip('Total de pastas e subpastas identificadas no inventário, sem duplicações.')
        self.show_folder_details()
        self.stat_values[2].setToolTip('Todas as pastas com fotos sem cache válido, inclusive as nunca analisadas, além de falhas e alterações aguardando conferência. Inclui as pastas superiores que contêm essas pendências.')
        self.stat_values[1].setToolTip('Pastas com fotos concluídas / total de pastas com fotos identificadas, incluindo fotos em subpastas e sem duplicações. Pastas sem fotos e pastas ainda sem conteúdo conferido não entram neste cálculo.')
        self.stat_values[3].setToolTip('Pastas sem imagens compatíveis: vazias, contendo somente subpastas vazias ou outros tipos de arquivo. Clique para ver os detalhes.')
        if roots and self.message.text().startswith('Adicione uma pasta'):
            self.message.setText('Expanda as pastas para ver cada ano e evento. Selecione uma linha para usar a pasta na busca.')
        if selection_moved:
            self.message.setText('A pasta continua selecionada na árvore. Pastas concluídas ficam dentro do acervo, no seu ano correspondente.')
