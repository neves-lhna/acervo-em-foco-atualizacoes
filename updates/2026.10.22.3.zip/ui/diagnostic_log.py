"""Visible notifications and a password-gated, hidden diagnostic viewer."""
from PySide6.QtCore import QObject,Signal,Qt,QThread
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QLabel,QLineEdit,QDialogButtonBox,QMessageBox,QPlainTextEdit,QPushButton,QInputDialog,QProgressDialog)
from core import diagnostics

class NotificationBus(QObject):
    message=Signal(str)


def configure_log(parent,store):
    dialog=QDialog(parent);dialog.setWindowTitle('Configuração privada do criador');layout=QVBoxLayout(dialog)
    text=QLabel('Defina a senha exclusiva para ler o log técnico.\nMínimo de 12 caracteres. Guarde-a: não há recuperação da senha.\nO programa continuará registrando sem pedir a senha.');text.setWordWrap(True);layout.addWidget(text)
    first=QLineEdit();first.setEchoMode(QLineEdit.Password);first.setPlaceholderText('Senha do criador')
    second=QLineEdit();second.setEchoMode(QLineEdit.Password);second.setPlaceholderText('Repita a senha')
    layout.addWidget(first);layout.addWidget(second)
    buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);layout.addWidget(buttons)
    def save():
        if first.text()!=second.text():QMessageBox.warning(dialog,'Senha','As senhas não coincidem.');return
        try:store.configure(first.text())
        except (ValueError,OSError) as exc:QMessageBox.warning(dialog,'Configuração',str(exc));return
        first.clear();second.clear();dialog.accept()
    buttons.accepted.connect(save);buttons.rejected.connect(dialog.reject)
    return dialog.exec()==QDialog.Accepted


def show_log(parent):
    store=diagnostics._store
    if not store:return
    if not store.configured:
        if not configure_log(parent,store):return
    password,ok=QInputDialog.getText(parent,'Acesso do criador','Senha do log técnico:',QLineEdit.Password)
    if not ok:return
    class Reader(QThread):
        def __init__(self):super().__init__();self.password=password;self.records=[];self.failure=None
        def run(self):
            try:self.records=store.read(self.password)
            except (ValueError,TypeError):self.failure='Senha incorreta.'
            except Exception:self.failure='Não foi possível ler os arquivos do log.'
            finally:self.password=''
    worker=Reader();password=''
    progress=QProgressDialog('Abrindo o log protegido…',None,0,0,parent)
    progress.setWindowModality(Qt.ApplicationModal);progress.setMinimumDuration(0)
    worker.finished.connect(progress.accept);worker.start();progress.exec();worker.wait()
    if worker.failure:QMessageBox.warning(parent,'Acesso ao log',worker.failure);return
    records=worker.records
    dialog=QDialog(parent);dialog.setWindowTitle('Log técnico — acesso do criador');dialog.resize(950,600)
    layout=QVBoxLayout(dialog);layout.addWidget(QLabel('Últimos 2.000 registros. Pastas verificadas e erros.'))
    text=QPlainTextEdit();text.setReadOnly(True);text.setPlainText('\n\n'.join(
        f"{r.get('when','')} | {r.get('stage','')} | {r.get('folder','')}"+
        (f"\nArquivo: {r['image']}" if r.get('image') else '')+
        (f"\nErro: {r['error']}" if r.get('error') else '') for r in records) or 'Nenhum registro ainda.')
    layout.addWidget(text);close=QPushButton('Fechar');close.clicked.connect(dialog.accept);layout.addWidget(close)
    dialog.exec();text.clear();records.clear()
