from pathlib import Path
from PySide6.QtCore import QLocale,QLibraryInfo,QTranslator


def install_portuguese(app):
    QLocale.setDefault(QLocale('pt_BR'))
    translator=QTranslator(app)
    bundled=Path(__file__).parent/'translations'/'qtbase_pt_BR.qm'
    standard=Path(QLibraryInfo.path(QLibraryInfo.TranslationsPath))/'qtbase_pt_BR.qm'
    if not any(translator.load(str(path)) for path in (bundled,standard)):
        raise RuntimeError('Não foi possível carregar a tradução em português do programa.')
    app.installTranslator(translator)
    app._portuguese_translator=translator
