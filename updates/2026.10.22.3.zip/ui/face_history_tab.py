import os
from PySide6.QtCore import Qt,QSize
from PySide6.QtGui import QPixmap,QIcon,QCursor
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QListWidget,QListWidgetItem,
                              QLabel,QPushButton,QFileDialog,QMessageBox)
from core.utils_os import reveal_in_file_manager
from workers.face_export_worker import FaceExportWorker
from workers.face_preview_worker import FacePreviewWorker
from ui.photo_viewer import show_photo


class FaceHistoryTab(QWidget):
    PAGE=40
    def __init__(self, history, parent=None, defer_photos=False):
        super().__init__(parent)
        self.history=history;self.face=None;self.page=0;self.rows=[];self.selected=set()
        self.defer_photos=defer_photos;self._photos_pending=False;self.items={}
        self.export_worker=None;self.preview_workers=[];self.generation=0
        layout=QVBoxLayout(self)
        note=QLabel('Clique em um rosto para consultar as fotos encontradas, sem repetir o reconhecimento. '
                    'O histórico começa com as buscas feitas nesta versão.')
        note.setWordWrap(True);layout.addWidget(note)
        body=QHBoxLayout();layout.addLayout(body,1)
        self.faces=QListWidget();self.faces.setIconSize(QSize(80,80));self.faces.setMaximumWidth(300)
        self.faces.currentItemChanged.connect(self.choose_face);body.addWidget(self.faces)
        right=QVBoxLayout();body.addLayout(right,1)
        self.info=QLabel('Nenhum rosto pesquisado ainda.');self.info.setWordWrap(True);right.addWidget(self.info)
        self.photos=QListWidget();self.photos.setIconSize(QSize(200,130));self.photos.setSpacing(5)
        self.photos.itemChanged.connect(self.selection_changed)
        self.photos.itemClicked.connect(self.preview_photo)
        right.addWidget(self.photos,1)
        nav=QHBoxLayout();right.addLayout(nav)
        self.previous=QPushButton('Anterior');self.next=QPushButton('Próxima')
        self.previous.clicked.connect(lambda:self.change_page(-1));self.next.clicked.connect(lambda:self.change_page(1))
        self.previous.hide();self.next.hide()
        self.open=QPushButton('Abrir na pasta');self.open.clicked.connect(self.open_photo);nav.addWidget(self.open)
        actions=QHBoxLayout();layout.addLayout(actions)
        self.copy_all=QPushButton('Copiar todas as fotos');self.copy_selected=QPushButton('Copiar selecionadas')
        self.copy_all.clicked.connect(lambda:self.copy_photos(False));self.copy_selected.clicked.connect(lambda:self.copy_photos(True))
        self.cancel=QPushButton('Parar cópia');self.cancel.clicked.connect(self.cancel_copy)
        for button in (self.copy_all,self.copy_selected,self.cancel):actions.addWidget(button)
        self.status=QLabel('As fotos originais permanecem nas pastas do acervo.');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.reload()

    def reload(self):
        current=self.face
        self.faces.blockSignals(True);self.faces.clear()
        chosen=None
        for face,portrait,date,folder,state,count in self.history.faces():
            pix=QPixmap();pix.loadFromData(portrait or b'')
            item=QListWidgetItem(QIcon(pix),f'{count} fotos · {date[:16].replace("T"," ")}\n{state}')
            item.setData(Qt.UserRole,face);item.setToolTip(folder);self.faces.addItem(item)
            if face==current:chosen=item
        self.faces.blockSignals(False)
        if chosen or self.faces.count():self.faces.setCurrentItem(chosen or self.faces.item(0))
        self.controls()

    def choose_face(self,item,previous=None):
        if item is None:return
        face=item.data(Qt.UserRole)
        if face!=self.face:self.selected.clear();self.page=0
        self.face=face
        if self.defer_photos and not self.isVisible():
            self._photos_pending=True;self.rows=[];self.controls();return
        self._photos_pending=False
        self.rows=self.history.results(face);self.show_page()

    def showEvent(self,event):
        super().showEvent(event)
        if self._photos_pending:self.choose_face(self.faces.currentItem())

    def show_page(self):
        self.generation+=1;generation=self.generation
        for worker in self.preview_workers:worker.requestInterruption()
        self.preview_workers=[worker for worker in self.preview_workers if worker.isRunning()]
        self.photos.blockSignals(True);self.photos.clear()
        visible=self.rows
        self.items={}
        for path,score,pose,mtime,size,preview in visible:
            item=QListWidgetItem(f'{os.path.basename(path)}\nSimilaridade: {score:.3f}\n{os.path.dirname(path)}')
            item.setData(Qt.UserRole,path);item.setToolTip(path)
            item.setFlags(item.flags()|Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if path in self.selected else Qt.Unchecked)
            item.setSizeHint(QSize(400,145));self.photos.addItem(item);self.items[path]=item
            if preview:self.preview_ready(path,preview,generation)
        self.photos.blockSignals(False)
        self.info.setText(f'{len(self.rows)} fotos salvas. Marque as fotos que deseja copiar.')
        if any(not row[5] for row in visible):
            worker=FacePreviewWorker(self.history.path,self.face,visible,self)
            worker.ready.connect(lambda path,data,g=generation:self.preview_ready(path,data,g))
            self.preview_workers.append(worker);worker.start()
        self.controls()

    def preview_ready(self,path,data,generation):
        if generation!=self.generation:return
        item=self.items.get(path)
        if item:
            pix=QPixmap();pix.loadFromData(data);item.setIcon(QIcon(pix))

    def preview_photo(self,item):
        # The checkbox remains a separate target from the photo thumbnail.
        point=self.photos.viewport().mapFromGlobal(QCursor.pos())
        rect=self.photos.visualItemRect(item)
        if 24 <= point.x()-rect.left() <= 24+self.photos.iconSize().width():
            show_photo(item.data(Qt.UserRole),self,[row[0] for row in self.rows])

    def selection_changed(self,item):
        path=item.data(Qt.UserRole)
        if item.checkState()==Qt.Checked:self.selected.add(path)
        else:self.selected.discard(path)
        self.controls()

    def change_page(self,delta):
        self.page=max(0,self.page+delta);self.show_page()

    def open_photo(self):
        item=self.photos.currentItem()
        if item:reveal_in_file_manager(item.data(Qt.UserRole))

    def copying(self):return bool(self.export_worker and self.export_worker.isRunning())

    def controls(self):
        busy=self.copying()
        self.copy_all.setEnabled(bool(self.rows) and not busy)
        self.copy_selected.setEnabled(bool(self.selected) and not busy)
        self.copy_selected.setText(f'Copiar selecionadas ({len(self.selected)})')
        self.cancel.setEnabled(busy)
        self.previous.setEnabled(self.page>0)
        self.next.setEnabled((self.page+1)*self.PAGE<len(self.rows))

    def copy_photos(self,selected_only):
        if self.copying():return
        rows=[row for row in self.rows if not selected_only or row[0] in self.selected]
        if not rows:return
        destination=QFileDialog.getExistingDirectory(self,'Escolha a pasta de destino das cópias')
        if not destination:return
        self.export_worker=FaceExportWorker(rows,destination,self)
        self.export_worker.progress.connect(lambda n,total:self.status.setText(f'Copiando: {n} de {total} fotos.'))
        self.export_worker.finished.connect(self.copy_finished)
        self.export_worker.start();self.controls()

    def cancel_copy(self):
        if self.copying():
            self.export_worker.stopped=True
            self.status.setText('Parando após a cópia do arquivo atual…')

    def copy_finished(self):
        worker=self.export_worker
        self.status.setText(f'{worker.copied} fotos copiadas para {worker.destination}. '
                            f'{len(worker.errors)} arquivo(s) não copiado(s).'+(' Cópia interrompida.' if worker.stopped else ''))
        if worker.errors:
            dialog=QMessageBox(self);dialog.setWindowTitle('Arquivos não copiados')
            dialog.setText('Alguns arquivos estão indisponíveis, foram alterados ou não puderam ser copiados.')
            dialog.setDetailedText('\n'.join(worker.errors));dialog.exec()
        self.controls()

    def stop_previews(self):
        for worker in self.preview_workers:worker.requestInterruption()
        return any(worker.isRunning() for worker in self.preview_workers)
