"""Windows Common Item Dialog: visible files plus explicit current-folder choice.
Uses documented IFileDialog/IFileDialogCustomize interfaces, no custom explorer.
"""
import os
from ctypes import POINTER, Structure, c_void_p, c_wchar_p, c_uint, c_int, windll, wstring_at
from comtypes import IUnknown, GUID, COMMETHOD, HRESULT, COMObject, CoCreateInstance, COMError

U=c_uint; P=c_void_p; S=c_wchar_p

def method(name,*args):return COMMETHOD([],HRESULT,name,*args)
def arg(t,name):return (['in'],t,name)
def out(t,name):return (['out'],POINTER(t),name)

class ShellItem(IUnknown):
    _iid_=GUID('{43826D1E-E718-42EE-BC55-A1E261C37BFE}')
    _methods_=[method('BindToHandler',arg(P,'a'),arg(P,'b'),arg(P,'c'),out(P,'d')),
        method('GetParent',out(P,'parent')),method('GetDisplayName',arg(U,'kind'),out(P,'name'))]

class FilterSpec(Structure):_fields_=[('name',S),('pattern',S)]

class FileDialog(IUnknown):
    _iid_=GUID('{42F85136-DB7E-439C-85F1-E4075D135FC8}')
    _methods_=[
        method('Show',arg(P,'owner')),
        method('SetFileTypes',arg(U,'count'),arg(POINTER(FilterSpec),'types')),
        method('SetFileTypeIndex',arg(U,'index')),method('GetFileTypeIndex',out(U,'index')),
        method('Advise',arg(POINTER(IUnknown),'events'),out(U,'cookie')),method('Unadvise',arg(U,'cookie')),
        method('SetOptions',arg(U,'options')),method('GetOptions',out(U,'options')),
        method('SetDefaultFolder',arg(POINTER(ShellItem),'item')),method('SetFolder',arg(POINTER(ShellItem),'item')),
        method('GetFolder',out(POINTER(ShellItem),'item')),method('GetCurrentSelection',out(POINTER(ShellItem),'item')),
        method('SetFileName',arg(S,'name')),method('GetFileName',out(P,'name')),method('SetTitle',arg(S,'title')),
        method('SetOkButtonLabel',arg(S,'label')),method('SetFileNameLabel',arg(S,'label')),
        method('GetResult',out(POINTER(ShellItem),'item')),method('AddPlace',arg(POINTER(ShellItem),'item'),arg(c_int,'where')),
        method('SetDefaultExtension',arg(S,'ext')),method('Close',arg(HRESULT,'result'))]

class Customize(IUnknown):
    _iid_=GUID('{E6FDD21A-163F-4975-9C8C-A69F1BA37034}')
    _methods_=[method('EnableOpenDropDown',arg(U,'id')),method('AddMenu',arg(U,'id'),arg(S,'label')),
        method('AddPushButton',arg(U,'id'),arg(S,'label'))]

class DialogEvents(IUnknown):
    _iid_=GUID('{973510DB-7D7F-452B-8975-74A85828D354}')
    _methods_=[method('OnFileOk',arg(POINTER(FileDialog),'dialog')),
        method('OnFolderChanging',arg(POINTER(FileDialog),'dialog'),arg(POINTER(ShellItem),'item')),
        method('OnFolderChange',arg(POINTER(FileDialog),'dialog')),
        method('OnSelectionChange',arg(POINTER(FileDialog),'dialog')),
        method('OnShareViolation',arg(POINTER(FileDialog),'dialog'),arg(POINTER(ShellItem),'item'),out(U,'response')),
        method('OnTypeChange',arg(POINTER(FileDialog),'dialog')),
        method('OnOverwrite',arg(POINTER(FileDialog),'dialog'),arg(POINTER(ShellItem),'item'),out(U,'response'))]

class ControlEvents(IUnknown):
    _iid_=GUID('{36116642-D713-4B97-9B83-7484A9D00433}')
    _methods_=[method('OnItemSelected',arg(POINTER(Customize),'custom'),arg(U,'control'),arg(U,'item')),
        method('OnButtonClicked',arg(POINTER(Customize),'custom'),arg(U,'control')),
        method('OnCheckButtonToggled',arg(POINTER(Customize),'custom'),arg(U,'control'),arg(c_int,'checked')),
        method('OnControlActivating',arg(POINTER(Customize),'custom'),arg(U,'control'))]


def filesystem_path(item):
    address=item.GetDisplayName(0x80058000)  # SIGDN_FILESYSPATH
    try:return wstring_at(address)
    finally:
        windll.ole32.CoTaskMemFree.argtypes=[P]
        windll.ole32.CoTaskMemFree(address)


class FolderEvents(COMObject):
    _com_interfaces_=[DialogEvents,ControlEvents]
    def __init__(self,dialog):super().__init__();self.dialog=dialog;self.selected=''
    def OnFileOk(self,dialog):
        path=filesystem_path(dialog.GetResult())
        self.selected=path if os.path.isdir(path) else os.path.dirname(path)
        return 0
    def OnButtonClicked(self,custom,control):
        if control==1001:
            self.selected=filesystem_path(self.dialog.GetFolder())
            self.dialog.Close(0)
        return 0
    def OnFolderChanging(self,*args):return 0
    def OnFolderChange(self,*args):return 0
    def OnSelectionChange(self,*args):return 0
    def OnTypeChange(self,*args):return 0
    def OnShareViolation(self,*args):return 0
    def OnOverwrite(self,*args):return 0
    def OnItemSelected(self,*args):return 0
    def OnCheckButtonToggled(self,*args):return 0
    def OnControlActivating(self,*args):return 0


def choose_folder_with_files(owner,directory):
    dialog=CoCreateInstance(GUID('{DC1C5A9C-E88A-4DDE-A5A1-60F82A20AEF7}'),interface=FileDialog,clsctx=1)
    dialog.SetOptions(0x40|0x800|0x1000|0x10000000) # filesystem, path/file exist, no recent entry
    dialog.SetTitle('Confira as imagens e clique em Selecionar pasta atual')
    dialog.SetOkButtonLabel('Usar pasta da imagem')
    custom=dialog.QueryInterface(Customize);custom.AddPushButton(1001,'Selecionar pasta atual')
    item=POINTER(ShellItem)()
    create=windll.shell32.SHCreateItemFromParsingName
    create.argtypes=[S,P,POINTER(GUID),POINTER(POINTER(ShellItem))];create.restype=HRESULT
    from ctypes import byref
    hr=create(os.path.abspath(directory),None,byref(ShellItem._iid_),byref(item))
    if hr<0:raise OSError('Não foi possível abrir a pasta inicial no Windows')
    dialog.SetFolder(item)
    events=FolderEvents(dialog);cookie=dialog.Advise(events.QueryInterface(DialogEvents))
    try:
        try:dialog.Show(owner)
        except COMError as exc:
            if exc.hresult & 0xffffffff != 0x800704c7:raise
            return ''
        return events.selected
    finally:dialog.Unadvise(cookie)
