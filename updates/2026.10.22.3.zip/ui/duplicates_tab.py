import os
from PySide6.QtCore import Qt,Signal,QUrl
from PySide6.QtGui import QPixmap,QDesktopServices
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QSlider,QFileDialog,QTreeWidget,QTreeWidgetItem,QTabWidget,QScrollArea,QFrame,QMenu,QCheckBox,QMessageBox,QSplitter,QListWidget,QListWidgetItem)
from workers.duplicate_worker import DuplicateWorker,connect
from ui.dialog_paths import initial_directory,remember_folder,last_folder
from core.duplicate_selection import automatic_selection,image_info
from send2trash import send2trash
from core.utils_os import reveal_in_file_manager
from ui.table_sorting import SortableItem,SORT_ROLE,enable_header_sort,text_key
from PySide6.QtWidgets import QHeaderView
from ui.photo_viewer import PhotoLabel, PhotoViewer


class DuplicatesTab(QWidget):
    open_deleted=Signal()
    progress_changed=Signal(int)
    busy_changed=Signal()
    PAGE=50
    def __init__(self,db_path,parent=None):
        super().__init__(parent);self.db_path=db_path;self.folder=None;self.worker=None;self.page=0;self.run_id=None;self.rows={};self.external_busy=False;self.selections={};self.keepers={};self.checkboxes={}
        self.db=connect(db_path)
        self.db.create_function('file_name',1,os.path.basename)
        self.db.create_collation('NATURAL_TEXT',lambda a,b:(text_key(a)>text_key(b))-(text_key(a)<text_key(b)))
        self.files_sort=(0,Qt.AscendingOrder)
        with self.db:
            self.db.execute("UPDATE runs SET state='Interrompida' WHERE state IN ('Analisando','Comparando')")
            self.db.execute("UPDATE runs SET state='Com Falha' WHERE state='Com falhas'")
        root_layout=QVBoxLayout(self)
        self.workspace_splitter=QSplitter(Qt.Horizontal);self.workspace_splitter.setChildrenCollapsible(False)
        self.workspace_splitter.setHandleWidth(8);root_layout.addWidget(self.workspace_splitter,1)
        left_scroll=QScrollArea();left_scroll.setWidgetResizable(True);left_scroll.setMinimumWidth(280);self.controls_scroll=left_scroll;left_scroll.setFrameShape(QFrame.NoFrame)
        left=QWidget();left.setMinimumWidth(0);layout=QVBoxLayout(left);left_scroll.setWidget(left)
        right=QWidget();right.setMinimumWidth(0);right_layout=QVBoxLayout(right)
        self.results_scroll=QScrollArea();self.results_scroll.setWidgetResizable(True)
        self.results_scroll.setMinimumWidth(320);self.results_scroll.setFrameShape(QFrame.NoFrame)
        self.results_scroll.setWidget(right)
        self.workspace_splitter.addWidget(left_scroll);self.workspace_splitter.addWidget(self.results_scroll)
        self.workspace_splitter.setStretchFactor(0,28);self.workspace_splitter.setStretchFactor(1,72)
        self.workspace_splitter.setSizes([280,720]);self.workspace_splitter.handle(1).setToolTip("Arraste para ajustar o espaço dos controles e das fotos.")
        title=QLabel('Duplicidade de imagens');title.setObjectName('PageTitle');title.setWordWrap(True);root_layout.insertWidget(0,title)
        self.status=QLabel('Escolha uma pasta para começar. Níveis baixos podem produzir muitos pares.');self.status.setWordWrap(True)
        self.scope_note=QLabel('Subpastas incluídas');self.scope_note.setWordWrap(True)
        self.scope_note.setToolTip('A verificação inclui a pasta selecionada e todas as suas subpastas. Fotos parecidas podem ser registros diferentes; confira as prévias antes de excluir.')
        self.scope_note.setAlignment(Qt.AlignRight|Qt.AlignVCenter);self.scope_note.setObjectName('Muted')
        settings_frame=QFrame();settings_frame.setObjectName('DuplicateSettings')
        settings_layout=QVBoxLayout(settings_frame)
        settings_layout.setContentsMargins(14,12,14,12);settings_layout.setSpacing(10)
        settings_layout.addWidget(QLabel('Pasta selecionada'))
        row=QHBoxLayout();self.folder_label=QLabel('Nenhuma pasta selecionada');self.folder_label.setWordWrap(True)
        self.choose=QPushButton('Escolher pasta');self.choose.setToolTip('Selecione qualquer pasta, inclusive uma que contenha somente subpastas.');self.choose.clicked.connect(self.choose_folder);settings_layout.addWidget(self.folder_label);row.addWidget(self.choose)
        self.explore=QPushButton('Ver no Explorer');self.explore.setToolTip('Abrir a pasta selecionada no Explorer do Windows para conferir as imagens.');self.explore.clicked.connect(self.open_folder);row.addWidget(self.explore);settings_layout.addLayout(row)
        similarity_label=QLabel('Similaridade mínima');settings_layout.addWidget(similarity_label);row=QHBoxLayout()
        self.slider=QSlider(Qt.Horizontal);self.slider.setRange(0,10);self.slider.setValue(8);row.addWidget(self.slider,1)
        self.level=QLabel('8 / 10');self.slider.valueChanged.connect(lambda v:self.level.setText(f'{v} / 10'));row.addWidget(self.level);settings_layout.addLayout(row)
        similarity_help='0: inclui imagens pouco parecidas.\nQuanto maior o nível, mais semelhantes devem ser as fotos.\n10: exige arquivos com conteúdo idêntico (SHA-256). Formatos ou metadados diferentes podem ficar abaixo de 10.\nO nível escolhido é o mínimo aceito; similaridade visual não confirma duplicidade.'
        for field in (similarity_label,self.slider,self.level):field.setToolTip(similarity_help)
        row=QHBoxLayout();self.start=QPushButton('Verificar duplicidade');self.start.setObjectName('Primary');self.start.clicked.connect(self.start_scan)
        self.stop=QPushButton('Parar verificação');self.stop.clicked.connect(self.stop_scan);row.addWidget(self.start);row.addWidget(self.stop);settings_layout.addLayout(row);settings_layout.addWidget(self.scope_note)
        self.start.setToolTip('Verificar as imagens da pasta e de suas subpastas usando a similaridade escolhida.')
        self.stop.setToolTip('Interromper após o processamento atual. O progresso já registrado permanece no histórico.')
        history_title=QPushButton('Histórico de pastas verificadas  ▴');history_title.setStyleSheet('text-align:left;font-weight:600;');history_title.setCheckable(True);history_title.setChecked(True);root_layout.insertWidget(1,history_title)
        self.history=QTreeWidget();self.history.setHeaderLabels(['Pasta / conferido em','Nível','Analisadas','Total','Progresso','Situação','Arquivo com falha']);self.history.setColumnWidth(0,420);self.history.itemSelectionChanged.connect(self.select_run);root_layout.insertWidget(2,self.history)
        history_title.toggled.connect(self.history.setVisible)
        history_title.toggled.connect(lambda shown:history_title.setText('Histórico de pastas verificadas  ▴' if shown else 'Histórico de pastas verificadas  ▾'))
        self.history.itemClicked.connect(self.expand_history)
        enable_header_sort(self.history)
        self.history.itemExpanded.connect(lambda *_:self._fit_history_height())
        self.history.itemCollapsed.connect(lambda *_:self._fit_history_height())
        self.history.header().setStretchLastSection(False)
        self.history.header().setSectionResizeMode(6,QHeaderView.Stretch)
        layout.addWidget(settings_frame)
        layout.addWidget(self.status)
        self.selection_note=QLabel('Cópias pré-selecionadas pelo nível da análise, priorizando manter RAW, maior resolução e EXIF. Você pode ajustar as marcações.')
        self.selection_note.setWordWrap(True);self.selection_note.setAlignment(Qt.AlignRight|Qt.AlignVCenter);self.selection_note.setMinimumWidth(0)
        self.trash=QPushButton('Mover selecionadas para a Lixeira (0)')
        self.trash.setToolTip(self.selection_note.text())
        self.bulk_controls_help=self.selection_note.text()
        self.trash.clicked.connect(self.trash_selected)
        self.bulk_controls=QWidget()
        self.bulk_layout=QHBoxLayout(self.bulk_controls);self.bulk_layout.setContentsMargins(0,0,0,0)
        self.bulk_controls.setToolTip(self.bulk_controls_help)
        clear=QCheckBox('Desmarcar Todas')
        clear.setToolTip('Limpar todas as marcações desta análise, em todos os resultados.')
        clear.clicked.connect(lambda:self.toggle_bulk('all'))
        self.bulk_boxes={'all':clear};self.bulk_layout.addStretch();self.bulk_layout.addWidget(clear)
        self.bulk_layout.addStretch();self.bulk_controls.hide()
        self.cleanup_failures={}
        self.cleanup_summary=QLabel();self.cleanup_summary.setWordWrap(True);layout.addWidget(self.cleanup_summary)
        self.failure_list=QListWidget();self.failure_list.setMaximumHeight(110);layout.addWidget(self.failure_list)
        self.failure_actions=QWidget();failure_row=QHBoxLayout(self.failure_actions)
        for text,handler in [('Ver motivo',self.show_cleanup_error),('Abrir na pasta',self.open_cleanup_failure),('Tentar novamente',self.retry_cleanup)]:
            button=QPushButton(text);button.clicked.connect(handler);failure_row.addWidget(button)
        layout.addWidget(self.failure_actions);self.failure_list.hide();self.failure_actions.hide()
        deleted=QPushButton('Ver fotos excluídas');deleted.clicked.connect(self.open_deleted.emit);layout.addWidget(deleted)
        self.selection_groups={'all':set()}
        self.column_selections={}
        self.result_folder=QLabel('Inicie a verificação para visualizar os resultados')
        self.result_folder.setTextFormat(Qt.PlainText);self.result_folder.setWordWrap(True);layout.addWidget(self.result_folder)
        self.views=QTabWidget();right_layout.addWidget(self.views,1)
        self.pairs_frame=QFrame();self.pairs_frame.setObjectName('DuplicateResults')
        
        pairs_layout=QVBoxLayout(self.pairs_frame);pairs_layout.setContentsMargins(6,6,6,6)
        
        self.option_controls=QWidget();self.option_layout=QHBoxLayout(self.option_controls);self.option_layout.setContentsMargins(10,4,10,4)
        
        from ui.duplicate_browser import DuplicateBrowser
        self.browser=DuplicateBrowser(self);pairs_layout.addWidget(self.browser,1)
        layout.addWidget(QLabel('Exibição'))
        layout.addWidget(self.browser.controls)
        layout.addWidget(QLabel('Seleção'))
        layout.addWidget(self.option_controls)
        layout.addWidget(self.bulk_controls)
        self.views.addTab(self.pairs_frame,'Fotos duplicadas')
        self.files=QTreeWidget();self.files.setHeaderLabels(['Imagem analisada','Estado','Detalhe']);self.files.setColumnWidth(0,470);self.views.addTab(self.files,'Histórico de imagens')
        enable_header_sort(self.files,self.sort_files)
        row=QVBoxLayout();self.previous=QPushButton('Anterior');self.next=QPushButton('Próxima');self.page_label=QLabel('');self.previous.clicked.connect(lambda:self.change_page(-1));self.next.clicked.connect(lambda:self.change_page(1));self.previous.hide();self.next.hide();row.addWidget(self.page_label);layout.addLayout(row)
        footer=QHBoxLayout();footer.addStretch();footer.addWidget(self.trash);right_layout.addLayout(footer)
        self.trash.setObjectName('Danger')
        layout.addStretch()
        self.selection_note.hide()
        self.views.currentChanged.connect(self.reset_page);self.refresh();self.update_controls()

    def running(self):return bool(self.worker and self.worker.isRunning())
    def update_controls(self):
        self.update_bulk_visibility()
        self.explore.setEnabled(bool(self.folder))
        busy=self.running() or self.external_busy
        self.history.viewport().update()
        for item in self.rows.values():
            cell=self.history.itemWidget(item,6)
            if cell:
                remove=cell.findChild(QPushButton,'RemoveHistory')
                if remove:remove.setEnabled(not busy)
        self.trash.setEnabled(not busy and not getattr(self,'file_operations_busy',False) and bool(self.selections.get(self.run_id)))
        for scope,check in self.bulk_boxes.items():
            check.setEnabled(not busy and bool(self.selections.get(self.run_id) if scope=='all' else self.selection_groups[scope]))
        self.start.setEnabled(bool(self.folder) and not busy);self.choose.setEnabled(not busy);self.slider.setEnabled(not busy);self.stop.setEnabled(self.running() and not self.worker.stopped)
    def set_busy(self,busy):self.external_busy=busy;self.update_controls();self.browser.sync_selection()
    def choose_folder(self):
        latest=self.db.execute("SELECT folder FROM runs ORDER BY id DESC LIMIT 1").fetchone()
        directory=initial_directory(last_folder(),self.folder,latest[0] if latest else None)
        if os.name == 'nt':
            from ui.windows_folder_dialog import choose_folder_with_files
            try:
                folder=choose_folder_with_files(int(self.window().winId()),directory)
            except Exception as exc:
                self.status.setText(f'Não foi possível abrir o seletor do Windows: {exc}')
                return
        else:
            folder=QFileDialog.getExistingDirectory(self,'Escolha a pasta a analisar (inclui subpastas)',directory)
        if folder:
            remember_folder(folder)
            self.folder=folder;self.folder_label.setText(os.path.basename(os.path.normpath(folder)) or folder);self.folder_label.setToolTip(folder);self.update_controls()
            self.status.setText('Pasta selecionada. A análise incluirá suas imagens e todas as subpastas.')
    def open_folder(self):
        if self.folder and not QDesktopServices.openUrl(QUrl.fromLocalFile(self.folder)):
            self.status.setText('Não foi possível abrir a pasta no Explorer. Confira se ela está disponível.')

    def rerun_selected(self):
        if self.running() or self.external_busy or getattr(self,'file_operations_busy',False):return
        record=self.db.execute('SELECT folder,level FROM runs WHERE id=?',(self.run_id,)).fetchone()
        if not record:return
        folder,level=record
        if not os.path.isdir(folder):
            self.status.setText('A pasta desta análise não está disponível. Conecte a unidade ou escolha outra pasta.');return
        self.folder=folder;self.folder_label.setText(os.path.basename(os.path.normpath(folder)) or folder);self.folder_label.setToolTip(folder)
        self.slider.setValue(level);self.start_scan()

    def start_scan(self):
        if self.running() or self.external_busy or not self.folder:return
        self.worker=DuplicateWorker(self.folder,self.slider.value(),self.db_path,self)
        self.worker.progress.connect(self.progress_changed.emit)
        self.scope_note.setText('Conferindo subpastas…')
        self.worker.subfolders_found.connect(self.show_subfolders)
        self.worker.updated.connect(self.refresh);self.worker.status.connect(self.status.setText);self.worker.finished.connect(self.finished)
        self.run_id=None;self.worker.start();self.update_controls();self.busy_changed.emit()
    def show_subfolders(self,count):
        prefix='Atenção: ' if count>1 else ''
        self.scope_note.setText(f'{prefix}{count} subpasta(s) incluída(s)')

    def stop_scan(self):
        if self.running():self.worker.stop();self.status.setText('Parando após a leitura atual…');self.update_controls()
    def finished(self):self.refresh();self.load_page();self.update_controls();self.busy_changed.emit()
    def refresh(self):
        records=self.db.execute('SELECT id,folder,started,level,done,total,state FROM runs ORDER BY id DESC').fetchall()
        newest={}
        for record in records:newest.setdefault(os.path.normcase(os.path.normpath(record[1])),record[0])
        self.history.blockSignals(True)
        for rid,folder,date,level,done,total,state in reversed(records):
            if rid not in self.rows:
                item=SortableItem();item.setData(0,Qt.UserRole,rid);self.history.insertTopLevelItem(0,item);self.rows[rid]=item
            item=self.rows[rid];percent=100*done/total if total else 0
            folder_name=os.path.basename(os.path.normpath(folder)) or folder
            for column,value in ((0,folder_name),(1,level),(2,done),(3,total),(4,percent)):
                item.setData(column,SORT_ROLE,value)
            for col,text in enumerate([folder_name+' · '+date.replace('T',' '),str(level),str(done),str(total),f'{percent:.1f}%',state]):item.setText(col,text)
            item.setToolTip(0,folder)
            failures=tuple(self.db.execute("SELECT path,error FROM files WHERE run=? AND state='Falha' ORDER BY path",(rid,)).fetchall())
            failure_details='\n\n'.join(f'{os.path.basename(path)}\nMotivo: {error or "Detalhe não registrado."}' for path,error in failures)
            item.setData(5,Qt.UserRole,failures)
            item.setToolTip(5,failure_details or ('Falha registrada sem detalhes disponíveis.' if state=='Com Falha' else ''))
            item.setData(6,SORT_ROLE,len(failures))
            button=self.history.itemWidget(item,6)
            if failures and (button is None or button.property('failure_paths') != failures):
                button=QPushButton('Abrir na pasta' if len(failures)==1 else f'Ver {len(failures)} falhas')
                button.setObjectName('FailureButton')
                button.setProperty('failure_paths',failures)
                if len(failures)==1:
                    path,error=failures[0];button.setToolTip(os.path.basename(path)+'\n'+error)
                    button.clicked.connect(lambda checked=False,p=path:reveal_in_file_manager(p))
                else:
                    menu=QMenu(button)
                    for path,error in failures:
                        action=menu.addAction(os.path.basename(path));action.setToolTip(error)
                        action.triggered.connect(lambda checked=False,p=path:reveal_in_file_manager(p))
                    button.setMenu(menu)
                cell=QWidget()
                cell.setProperty('failure_paths',failures)
                cell_layout=QHBoxLayout(cell)
                cell_layout.setContentsMargins(0,0,0,0)
                cell_layout.addWidget(button,0,Qt.AlignLeft | Qt.AlignVCenter)
                self.history.setItemWidget(item,6,cell)

        for rid,folder,*_ in records:
            item=self.rows[rid];latest=newest[os.path.normcase(os.path.normpath(folder))]
            parent=self.rows[latest] if latest!=rid else None
            if parent is None:
                ancestor=os.path.dirname(os.path.normpath(folder))
                while ancestor!=os.path.dirname(ancestor):
                    ancestor_id=newest.get(os.path.normcase(ancestor))
                    if ancestor_id is not None:
                        parent=self.rows[ancestor_id];break
                    ancestor=os.path.dirname(ancestor)
            if item.parent() is not parent:
                old_parent=item.parent()
                if old_parent is not None:old_parent.takeChild(old_parent.indexOfChild(item))
                else:self.history.takeTopLevelItem(self.history.indexOfTopLevelItem(item))
                if parent is not None:parent.addChild(item)
                else:self.history.insertTopLevelItem(0,item)
        for rid,item in self.rows.items():
            cell=self.history.itemWidget(item,6)
            if cell is None:
                cell=QWidget();cell_layout=QHBoxLayout(cell);cell_layout.setContentsMargins(0,0,4,0)
                self.history.setItemWidget(item,6,cell)
            cell.setAutoFillBackground(False)
            cell.setStyleSheet('background: transparent;')
            if cell.findChild(QPushButton,'RemoveHistory') is None:
                cell.layout().addStretch()
                remove=QPushButton('✕',cell);remove.setObjectName('RemoveHistory');remove.setFixedSize(26,26)
                remove.setAccessibleName('Excluir esta verificação do histórico')
                remove.setToolTip('Excluir somente esta verificação do histórico. Fotos e cache são mantidos.')
                remove.setStyleSheet('QPushButton { color: #dc2626; background: transparent; border: none; padding: 0; font-size: 18px; }')
                remove.clicked.connect(lambda checked=False,r=rid:self.delete_history(r))
                cell.layout().addWidget(remove,0,Qt.AlignVCenter)
            cell.findChild(QPushButton,'RemoveHistory').setEnabled(not self.running() and not self.external_busy)
        self.history.blockSignals(False)
        self._fit_history_height()
        if self.run_id is None and records:
            rid=self.worker.run_id if self.running() and self.worker.run_id else records[0][0]
            if rid in self.rows:self.history.setCurrentItem(self.rows[rid]);self.run_id=rid
    def _fit_history_height(self):
        header=self.history.header().sizeHint().height()
        def visible_count(item):
            return 1+(sum(visible_count(item.child(i)) for i in range(item.childCount())) if item.isExpanded() else 0)
        rows=38*sum(visible_count(self.history.topLevelItem(i)) for i in range(self.history.topLevelItemCount()))
        # Include borders/padding and any horizontal scrollbar, without reserving empty rows.
        extra=12
        if self.history.horizontalScrollBar().maximum()>0:
            extra+=self.history.horizontalScrollBar().sizeHint().height()
        limit=max(header+38+extra,min(150,int(self.height()*0.20)))
        self.history.setFixedHeight(min(header+rows+extra,limit))

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,'history'):self._fit_history_height()

    def select_run(self):
        item=self.history.currentItem()
        if item:self.run_id=item.data(0,Qt.UserRole);self.reset_page()
        self.update_controls()

    def expand_history(self,item,column):
        if column==5:
            failures=item.data(5,Qt.UserRole) or ()
            if len(failures)==1:
                reveal_in_file_manager(failures[0][0]);return
            if failures:
                menu=QMenu(self)
                for path,error in failures:
                    action=menu.addAction(os.path.basename(path))
                    action.setToolTip(error or 'Detalhe não registrado.')
                    action.triggered.connect(lambda checked=False,p=path:reveal_in_file_manager(p))
                from PySide6.QtGui import QCursor
                menu.exec(QCursor.pos());return
        if item.childCount():item.setExpanded(not item.isExpanded())

    def delete_history(self,rid=None):
        if rid is None:rid=self.run_id
        if rid is None or self.running() or self.external_busy:return
        record=self.db.execute('SELECT folder,started,level FROM runs WHERE id=?',(rid,)).fetchone()
        if not record:return
        folder,date,level=record
        answer=QMessageBox.question(self,'Excluir verificação do histórico',
            f'Excluir a verificação de {os.path.basename(os.path.normpath(folder))} feita em {date.replace("T"," ")} (nível {level})?\n\nSomente este registro e seus resultados serão removidos. As fotos, o cache e as outras verificações serão mantidos.',
            QMessageBox.Yes|QMessageBox.Cancel,QMessageBox.Cancel)
        if answer!=QMessageBox.Yes:return
        with self.db:
            for table in ('pairs','files'):self.db.execute(f'DELETE FROM {table} WHERE run=?',(rid,))
            self.db.execute('DELETE FROM runs WHERE id=?',(rid,))
        self.selections.pop(rid,None);self.column_selections.pop(rid,None);self.keepers.pop(rid,None)
        self.run_id=None;self.history.blockSignals(True);self.history.clear();self.rows={};self.history.blockSignals(False)
        self.refresh()
        if self.run_id is None:
            self.checkboxes={};self.set_option_groups([]);self.files.clear()
            self.browser.set_pairs([],None)
            self.page_label.setText('Nenhuma verificação no histórico');self.previous.setEnabled(False);self.next.setEnabled(False)
            self.update_selection()
        self.update_controls()
        self.status.clear()
    def reset_page(self,*_):self.page=0;self.load_page()
    def sort_files(self,column,order):
        self.files_sort=(column,order);self.reset_page()
    def change_page(self,delta):self.browser.go(self.browser.index+delta)
    def load_page(self):
        if self.run_id is None:
            self.browser.set_pairs([],None);return
        if self.run_id not in self.selections and not self.running():
            self.selections[self.run_id],self.keepers[self.run_id]=automatic_selection(self.db,self.run_id)
        self.checkboxes={}
        # Migrate stale pairs left by older versions after a successful deletion.
        with self.db:
            self.db.execute("DELETE FROM pairs WHERE EXISTS (SELECT 1 FROM files f WHERE f.run=pairs.run AND f.state='Na Lixeira' AND (f.path=pairs.a OR f.path=pairs.b))")
        pairs_all=self.db.execute('SELECT a,b FROM pairs WHERE run=?',(self.run_id,)).fetchall()
        active={p for pair in pairs_all for p in pair}
        self.selections[self.run_id]=self.selections.get(self.run_id,set()) & active
        if self.run_id in self.column_selections:
            self.column_selections[self.run_id]={key for key in self.column_selections[self.run_id] if key[1] in active}
        self.set_option_groups(pairs_all)
        self.update_selection()
        is_pairs=self.views.currentIndex()==0;table='pairs' if is_pairs else 'files'
        total=self.db.execute(f'SELECT count(*) FROM {table} WHERE run=?',(self.run_id,)).fetchone()[0]
        if is_pairs:
            pairs=self.db.execute('SELECT a,b,score FROM pairs WHERE run=? ORDER BY score DESC,a,b',(self.run_id,)).fetchall()
            self.browser.set_pairs(pairs,self.run_id)
        else:
            self.files.clear()
            column,order=self.files_sort
            field=('file_name(path)','state','error')[column]
            direction='ASC' if order==Qt.AscendingOrder else 'DESC'
            query=f'SELECT path,state,error FROM files WHERE run=? ORDER BY {field} COLLATE NATURAL_TEXT {direction},path COLLATE NATURAL_TEXT {direction}'
            for path,state,error in self.db.execute(query,(self.run_id,)):
                item=QTreeWidgetItem([os.path.basename(path),state,error]);item.setToolTip(0,path);self.files.addTopLevelItem(item)
        self.page_label.setText(f'{total:,} '+('pares' if is_pairs else 'imagens'))
        self.previous.hide();self.next.hide()
        self.update_cleanup_summary()

    @staticmethod
    def arrange_photo_details(layout,option,count,title,preview,labels,choice,button):
        image=QVBoxLayout();image.addWidget(title);image.addWidget(preview,1)
        details=QVBoxLayout();details.setSpacing(6)
        centered=count>2
        alignment=Qt.AlignHCenter if centered else (Qt.AlignRight if option==1 else Qt.AlignLeft)
        for label in labels:
            label.setMinimumWidth(0)
            label.setAlignment(alignment)
            details.addWidget(label)
        details.addWidget(choice,0,alignment);details.addWidget(button,0,alignment)
        if centered:
            layout.addLayout(image);layout.addLayout(details)
        else:
            side=QHBoxLayout();side.setSpacing(16)
            if option==1:side.addLayout(details,1);side.addLayout(image)
            else:side.addLayout(image);side.addLayout(details,1)
            side.setAlignment(details,Qt.AlignVCenter)
            layout.addLayout(side)

    def compare_photos(self,pair):
        if self.run_id is None or self.running():return
        # Include every related version, even when it is on another page.
        edges=self.db.execute('SELECT a,b FROM pairs WHERE run=?',(self.run_id,)).fetchall()
        neighbors={}
        for a,b in edges:
            neighbors.setdefault(a,set()).add(b);neighbors.setdefault(b,set()).add(a)
        paths=list(dict.fromkeys(pair));seen=set(paths)
        for path in paths:
            for other in sorted(neighbors.get(path,())):
                if other not in seen:seen.add(other);paths.append(other)
        keys={path:[(column,path)] for column,path in enumerate(pair)}
        for path in paths:
            if path not in keys:keys[path]=[key for key in self.selection_groups['all'] if key[1]==path]
        def selected(path):
            return any(key in self.column_selections.get(self.run_id,set()) for key in keys[path])
        def changed(path,marked):
            for column,_ in keys[path]:self.toggle_selection(path,marked,column)
        dialog=PhotoViewer(paths,self,selected,changed,not self.external_busy)
        dialog.exec();dialog.deleteLater()

    def set_option_groups(self,rows):
        """Match bulk controls to the positions in the displayed result rows."""
        count=max((len(row) for row in rows),default=0)
        groups={f'option_{i}':{(i,row[i]) for row in rows if len(row)>i} for i in range(count)}
        groups['all']=set().union(*groups.values()) if groups else set()
        for scope in list(self.bulk_boxes):
            if scope not in groups:
                check=self.bulk_boxes.pop(scope);self.option_layout.removeWidget(check);check.deleteLater()
        for i in range(count):
            scope=f'option_{i}'
            if scope not in self.bulk_boxes:
                check=QCheckBox(f'{i+1}ª Opção');check.setTristate(True)
                check.setToolTip('Marcar somente esta coluna em todos os resultados, limpando as outras colunas. Clique novamente para desmarcar.')
                check.clicked.connect(lambda checked=False,s=scope:self.toggle_bulk(s))
                self.bulk_boxes[scope]=check
        while self.option_layout.count():
            item=self.option_layout.takeAt(0)
            if isinstance(item.widget(),QLabel):item.widget().deleteLater()
        self.option_layout.addStretch()
        for i in range(count):
            if i:
                separator=QLabel('|');separator.setObjectName('Muted')
                separator.setAlignment(Qt.AlignCenter);self.option_layout.addWidget(separator)
            check=self.bulk_boxes[f'option_{i}']
            check.setLayoutDirection(Qt.RightToLeft if count==2 and i==1 else Qt.LeftToRight)
            self.option_layout.addWidget(check)
        self.option_layout.addStretch()
        self.selection_groups=groups
        if self.run_id not in self.column_selections:
            self.column_selections[self.run_id]={key for key in groups['all'] if key[1] in self.selections.get(self.run_id,set())}

    def update_selection(self):
        self.update_bulk_visibility()
        count=len(self.selections.get(self.run_id,set()))
        self.trash.setText(f'Mover selecionadas para a Lixeira ({count})')
        self.trash.setEnabled(bool(count) and not self.running() and not self.external_busy and not getattr(self,'file_operations_busy',False))
        selected=self.selections.get(self.run_id,set())
        for scope,check in self.bulk_boxes.items():
            if scope=='all':
                check.blockSignals(True);check.setChecked(False);check.blockSignals(False)
                check.setEnabled(bool(selected) and not self.running() and not self.external_busy)
                continue
            paths=self.selection_groups[scope];marked=len(paths & self.column_selections.get(self.run_id,set()))
            state=Qt.Checked if paths and marked==len(paths) else Qt.PartiallyChecked if marked else Qt.Unchecked
            check.blockSignals(True);check.setCheckState(state);check.blockSignals(False)
            check.setEnabled(bool(paths) and not self.running() and not self.external_busy)

    def update_bulk_visibility(self):
        record=self.db.execute('SELECT state,folder FROM runs WHERE id=?',(self.run_id,)).fetchone() if self.run_id is not None else None
        if record:
            folder_name=os.path.basename(os.path.normpath(record[1])) or record[1]
            if record[0] in ('Concluída','Com Falha'):
                subtitle=f'Resultados da verificação — {folder_name}'
            elif record[0]=='Interrompida':
                subtitle=f'Verificação interrompida — {folder_name}'
            else:
                subtitle=f'Verificação em andamento — {folder_name}'
        else:subtitle='Inicie a verificação para visualizar os resultados'
        self.result_folder.setText(subtitle)
        show_controls=bool(record and record[0] in ('Concluída','Com Falha') and not self.running())
        self.bulk_controls.setVisible(show_controls)
        self.option_controls.setVisible(show_controls)

    def toggle_bulk(self,scope):
        if self.run_id is None or self.running() or self.external_busy:return
        paths=self.selection_groups[scope]
        selected=self.column_selections.setdefault(self.run_id,set())
        if scope=='all':selected.clear()
        else:
            available={key for key in paths if os.path.isfile(key[1])}
            if available <= selected:selected.difference_update(paths)
            else:selected.clear();selected.update(available)
        self.sync_column_selection()

    def sync_column_selection(self):
        selected=self.column_selections.get(self.run_id,set())
        self.selections[self.run_id]={path for column,path in selected}
        for key,boxes in self.checkboxes.items():
            for box in boxes:
                box.blockSignals(True);box.setChecked(key in selected);box.blockSignals(False)
        self.update_selection()
        self.browser.sync_selection()

    def toggle_selection(self,path,checked,column):
        selected=self.column_selections.setdefault(self.run_id,set())
        key=(column,path)
        if checked:selected.add(key)
        else:selected.discard(key)
        self.sync_column_selection()

    def trash_selected(self):
        if self.running() or self.external_busy or getattr(self,'file_operations_busy',False):return
        selected=set(self.selections.get(self.run_id,set()))
        if not selected:return
        # Every selected photo must have a directly compared, retained counterpart.
        pairs=self.db.execute('SELECT a,b FROM pairs WHERE run=?',(self.run_id,)).fetchall()
        neighbors={}
        for a,b in pairs:
            neighbors.setdefault(a,set()).add(b);neighbors.setdefault(b,set()).add(a)
        def unchanged(path):
            try:
                st=os.stat(path)
                cached=self.db.execute('SELECT mtime,size FROM signatures WHERE path=?',(path,)).fetchone()
                return cached is not None and (st.st_mtime_ns,st.st_size)==tuple(cached)
            except OSError:return False
        def preserved(path):
            return any(q not in selected and unchanged(q) for q in neighbors.get(path,()))
        without_copy=[p for p in sorted(selected) if not preserved(p)]
        allow_all=False
        if without_copy:
            duplicate_errors={p for p in without_copy if neighbors.get(p)}
            review_paths=sorted(duplicate_errors | {q for p in duplicate_errors for q in neighbors[p]})
            if not review_paths:
                QMessageBox.warning(self,'Exclusão bloqueada','As fotos selecionadas não pertencem aos pares encontrados nesta verificação. Faça uma nova verificação.')
                return
            review_selected=set(selected)
            def mark(path,checked):
                if checked:review_selected.add(path)
                else:review_selected.discard(path)
            reason=('Esta revisão foi aberta porque algumas fotos selecionadas não têm uma versão correspondente preservada. '
                    'Confira as imagens e ajuste as marcações. Você pode continuar com todas as versões marcadas; '
                    'nesse caso, todas essas cópias serão enviadas para a Lixeira. '
                    'Arquivos alterados, indisponíveis ou sem comparação válida permanecem bloqueados.')
            review=PhotoViewer(review_paths,self,lambda p:p in review_selected,mark,True,reason=reason,review=True)
            accepted=review.exec();review.deleteLater()
            if accepted!=1:return
            selected=review_selected
            if not selected:return
            invalid=[p for p in selected if not unchanged(p) or not any(unchanged(q) for q in neighbors.get(p,()))]
            if invalid:
                duplicate_invalid=sorted(p for p in set(invalid) if neighbors.get(p))
                reason='Exclusão bloqueada: estas fotos ou suas versões correspondentes foram alteradas, estão indisponíveis ou não têm uma comparação válida. Faça uma nova verificação.'
                if duplicate_invalid:
                    notice=PhotoViewer(duplicate_invalid,self,reason=reason)
                    notice.exec();notice.deleteLater()
                else:QMessageBox.warning(self,'Exclusão bloqueada',reason)
                return
            allow_all=True
            self.selections[self.run_id]=set(selected)
            self.column_selections[self.run_id]={key for key in self.selection_groups['all'] if key[1] in selected}
            self.sync_column_selection()
        from ui.delete_confirmation import DeleteConfirmation
        dialog=DeleteConfirmation(selected,self)
        if dialog.exec()!=QMessageBox.Yes:return
        failures=[];failed_paths=[];moved=0
        for path in sorted(selected):
            journal_id=None
            journal=getattr(self,'deletion_history',None)
            try:
                if not allow_all and not preserved(path):raise ValueError('A imagem correspondente não está mais disponível ou foi alterada; verifique novamente')
                st=os.stat(path)
                cached=self.db.execute('SELECT mtime,size FROM signatures WHERE path=?',(path,)).fetchone()
                if not cached or (st.st_mtime_ns,st.st_size)!=tuple(cached):
                    raise ValueError('Arquivo alterado desde a análise; verifique novamente')
                if journal:
                    digest=self.db.execute('SELECT digest FROM signatures WHERE path=?',(path,)).fetchone()
                    journal_id=journal.begin(path,st.st_size,digest[0] if digest else None)
                send2trash(path)
                if journal_id is not None:journal.finish(journal_id)
                self.selections[self.run_id].discard(path)
                self.column_selections[self.run_id]={key for key in self.column_selections.get(self.run_id,set()) if key[1]!=path}
                moved+=1
                with self.db:
                    self.db.execute("UPDATE files SET state='Na Lixeira' WHERE path=?",(path,))
                    self.db.execute('DELETE FROM signatures WHERE path=?',(path,))
                    self.db.execute('DELETE FROM pairs WHERE a=? OR b=?',(path,path))
            except Exception as exc:
                from core.diagnostics import image_error
                image_error(path,str(exc),'Exclusão de duplicada')
                if journal_id is not None and os.path.exists(path):journal.finish(journal_id,str(exc))
                failures.append(os.path.basename(path)+': '+str(exc));failed_paths.append(path)
        self.cleanup_failures[self.run_id]=list(zip(failed_paths,failures))
        self.load_page()
        remaining=len(self.browser.pairs)
        self.status.setText(f'{moved} fotos enviadas para a Lixeira. Restam {remaining} pares para revisar.' + (f' {len(failures)} fotos não puderam ser removidas.' if failures else ''))

    def update_cleanup_summary(self):
        if self.run_id is None:return
        removed=self.db.execute("SELECT count(*) FROM files WHERE run=? AND state='Na Lixeira'",(self.run_id,)).fetchone()[0]
        retained=self.db.execute("SELECT count(*) FROM files WHERE run=? AND state='Analisada'",(self.run_id,)).fetchone()[0]
        remaining=self.db.execute('SELECT count(*) FROM pairs WHERE run=?',(self.run_id,)).fetchone()[0]
        self.cleanup_summary.setText(f'Resultado da revisão: {removed} fotos enviadas para a Lixeira. {remaining} pares restantes.' if removed else '')
        self.failure_list.clear()
        for path,error in self.cleanup_failures.get(self.run_id,[]):
            item=QListWidgetItem(os.path.basename(path));item.setData(Qt.UserRole,(path,error));item.setToolTip(error);self.failure_list.addItem(item)
        failures=self.failure_list.count()>0
        self.failure_list.setVisible(failures);self.failure_actions.setVisible(failures)
        if removed and not remaining:
            self.browser.empty_text.setText(f'✓ Revisão concluída — nenhum par pendente nesta análise.\n\n{removed} fotos enviadas para a Lixeira. {retained} arquivos analisados não enviados para a Lixeira.');self.browser.done_actions.show()
        else:
            self.browser.empty_text.setText('Nenhum par encontrado nesta análise.' if self.run_id else 'Selecione uma verificação para visualizar os pares encontrados.');self.browser.done_actions.hide()

    def show_cleanup_error(self):
        item=self.failure_list.currentItem()
        if item:QMessageBox.information(self,'Motivo da falha',item.data(Qt.UserRole)[1])

    def open_cleanup_failure(self):
        item=self.failure_list.currentItem()
        if item:reveal_in_file_manager(item.data(Qt.UserRole)[0])

    def retry_cleanup(self):
        paths={p for p,_ in self.cleanup_failures.get(self.run_id,[])}
        if not paths:return
        self.column_selections[self.run_id]={key for key in self.selection_groups['all'] if key[1] in paths}
        self.sync_column_selection();self.trash_selected()
