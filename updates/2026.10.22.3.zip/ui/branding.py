"""Display the supplied brand artwork without changing its PNG source files."""
from pathlib import Path
from functools import lru_cache
from core.app_profile import current_profile
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap,QIcon,QRegion
from PySide6.QtWidgets import QLabel

BRAND_DIR=Path(__file__).resolve().parent.parent/'logo'

@lru_cache(maxsize=3)
def artwork(kind):
    filename='icone Acervo pessoal.png' if kind=='icone' and current_profile().key=='pessoal' else f'{kind} Acervo em Foco.png'
    pix=QPixmap(str(BRAND_DIR/filename))
    if not pix.isNull() and pix.hasAlphaChannel():
        bounds=QRegion(pix.mask()).boundingRect()
        if not bounds.isEmpty():pix=pix.copy(bounds)
    return pix

def brand_label(kind,width,height,parent=None):
    label=QLabel(parent);label.setAlignment(Qt.AlignCenter)
    if kind=='nome':
        label.setText('<b>Acervo</b> em <b style="color:#ee9c23">Foco</b>')
        label.setStyleSheet('font-size:16pt;')
        label.setAccessibleName('Acervo em Foco');return label
    if kind=='logo':label.setObjectName('BrandArtwork');label.setFixedSize(width+16,height+16)
    pix=artwork(kind)
    if not pix.isNull():label.setPixmap(pix.scaled(width,height,Qt.KeepAspectRatio,Qt.SmoothTransformation))
    else:label.setText('Acervo em Foco')
    label.setAccessibleName('Acervo em Foco');return label

@lru_cache(maxsize=1)
def app_icon():
    filename='AcervoPessoal.ico' if current_profile().key=='pessoal' else 'AcervoEmFoco.ico'
    windows_icon=QIcon(str(BRAND_DIR/filename))
    return windows_icon if not windows_icon.isNull() else QIcon(artwork('icone'))
