import os
from PySide6.QtCore import QThread,Signal,Qt
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTreeWidget,QMessageBox
from core.auxiliary_cleanup import inspect_auxiliary,trash_auxiliary
from ui.table_sorting import SortableItem,enable_header_sort,SORT_ROLE
from core.utils_os import reveal_in_file_manager

def size_text(size):return f'{size/1024:,.1f} KiB'.replace(',',' ').replace('.',',')

class AuxiliaryScan(QThread):
    found=Signal(object)
    issue=Signal(str)
    def __init__(self,cache,parent):super().__init__(parent);self.cache=cache
    def run(self):
        try:
            folders=sorted({os.path.dirname(path) for path in self.cache.metadata_index()})
            for root in folders:
                if self.isInterruptionRequested():return
                try:
                    with os.scandir(root) as entries:files=[entry.name for entry in entries if entry.name.startswith('._') and entry.is_file(follow_symlinks=False)]
                except OSError as exc:self.issue.emit(str(exc));continue
                for name in files:
                    if self.isInterruptionRequested():return
                    if not name.startswith('._'):continue
                    try:
                        record=inspect_auxiliary(os.path.join(root,name))
                        if record:self.found.emit(record)
                    except OSError as exc:self.issue.emit(str(exc))
        except Exception as exc:self.issue.emit(str(exc))

class AuxiliaryCleanup(QWidget):
    def __init__(self,main):
        super().__init__(main);self.main=main;self.records=[];self.errors=[];self.moved=0;self.worker=None
        layout=QVBoxLayout(self)
        label=QLabel('Arquivos auxiliares nas pastas com fotos registradas no cache. Somente auxiliares idênticos ao padrão examinado podem ser selecionados. As fotos originais são preservadas.');label.setWordWrap(True);layout.addWidget(label)
        self.table=QTreeWidget();self.table.setHeaderLabels(['Arquivo auxiliar','Pasta','Tamanho','Avaliação']);enable_header_sort(self.table)
        self.table.setColumnWidth(0,230);self.table.setColumnWidth(1,300);layout.addWidget(self.table,1)
        self.summary=QLabel('Procurando arquivos auxiliares…');self.summary.setWordWrap(True);layout.addWidget(self.summary)
        self.space=QLabel('Enviado à Lixeira: 0 KiB. Espaço efetivamente liberado por esta limpeza: 0 KiB.');self.space.setWordWrap(True);layout.addWidget(self.space)
        note=QLabel('Mover para a Lixeira no mesmo HD não libera espaço. Restauração disponível na aba Fotos excluídas.');note.setWordWrap(True);layout.addWidget(note)
        row=QHBoxLayout();layout.addLayout(row)
        self.select=QPushButton('Selecionar elegíveis');self.select.clicked.connect(self.select_eligible);row.addWidget(self.select)
        reveal=QPushButton('Abrir na pasta');reveal.clicked.connect(self.reveal);row.addWidget(reveal)
        self.remove=QPushButton('Mover selecionados para a Lixeira');self.remove.clicked.connect(self.remove_selected);row.addWidget(self.remove)
        self.update_btn=QPushButton('Examinar pastas do cache');self.update_btn.clicked.connect(self.start_scan);row.addWidget(self.update_btn)
        self.stop_btn=QPushButton('Parar exame');self.stop_btn.clicked.connect(self.stop_scan);row.addWidget(self.stop_btn)
        self.table.itemChanged.connect(self.refresh);self.refresh()
    def showEvent(self,event):
        super().showEvent(event)
        if self.worker is None:self.start_scan()
    def running(self):return bool(self.worker and self.worker.isRunning())
    def stop_scan(self):
        if self.running():self.worker.requestInterruption()
    def start_scan(self):
        if self.running():return
        self.table.clear();self.records=[];self.errors=[]
        self.worker=AuxiliaryScan(self.main.cache,self);self.worker.found.connect(self.add_record);self.worker.issue.connect(self.errors.append);self.worker.finished.connect(self.refresh)
        self.worker.start();self.refresh()
    def add_record(self,record):
        self.records.append(record)
        item=SortableItem([os.path.basename(record['path']),os.path.dirname(record['path']),size_text(record['size']),record['reason']])
        item.setData(0,Qt.UserRole,record);item.setData(2,SORT_ROLE,record['size']);item.setToolTip(0,record['path'])
        if record['safe']:item.setCheckState(0,Qt.Unchecked)
        self.table.addTopLevelItem(item);self.refresh()
    def rows(self):return [self.table.topLevelItem(i) for i in range(self.table.topLevelItemCount())]
    def refresh(self,*_):
        busy=self.running();selected=[r for r in self.rows() if r.checkState(0)==Qt.Checked]
        eligible=sum(r['safe'] for r in self.records)
        self.summary.setText(('Examinando… ' if busy else 'Exame concluído. ')+f'{len(self.records)} auxiliares ({size_text(sum(r["size"] for r in self.records))}); {eligible} elegíveis; {len(self.records)-eligible} para revisão. Selecionados: {len(selected)} ({size_text(sum(r.data(0,Qt.UserRole)["size"] for r in selected))}).'+(f' {len(self.errors)} falha(s) de acesso; exame incompleto.' if self.errors else ''))
        self.summary.setToolTip('\n'.join(self.errors));self.select.setEnabled(not busy);self.remove.setEnabled(not busy and bool(selected))
        self.update_btn.setEnabled(not busy);self.stop_btn.setEnabled(busy)
        if self.worker is None:self.summary.setText('Abra esta aba para examinar as pastas registradas no cache.')
        elif not busy and self.worker.isInterruptionRequested():self.summary.setText('Exame interrompido. Resultados parciais. '+self.summary.text())
    def select_eligible(self):
        for row in self.rows():
            if row.data(0,Qt.UserRole)['safe']:row.setCheckState(0,Qt.Checked)
    def reveal(self):
        row=self.table.currentItem()
        if row:reveal_in_file_manager(row.data(0,Qt.UserRole)['path'])
    def remove_selected(self):
        if self.main._busy() or self.main._cache_running():
            QMessageBox.information(self,'Operação em andamento','Aguarde o término das análises antes de limpar os auxiliares.');return
        selected=[row for row in self.rows() if row.checkState(0)==Qt.Checked and row.data(0,Qt.UserRole)['safe']]
        if not selected:return
        box=QMessageBox(QMessageBox.Question,'Confirmar limpeza',f'Mover {len(selected)} arquivo(s) auxiliar(es) para a Lixeira? As fotos originais serão mantidas.',parent=self)
        yes=box.addButton('Mover para a Lixeira',QMessageBox.AcceptRole);cancel=box.addButton('Cancelar',QMessageBox.RejectRole);box.setDefaultButton(cancel);box.exec()
        if box.clickedButton()!=yes:return
        failures=[]
        for row in selected:
            record=row.data(0,Qt.UserRole)
            try:
                self.moved+=trash_auxiliary(record,self.main.deletion_history)
                self.records.remove(record);self.table.takeTopLevelItem(self.table.indexOfTopLevelItem(row))
            except Exception as exc:
                from core.diagnostics import image_error
                image_error(record['path'],str(exc),'Arquivo auxiliar');failures.append(os.path.basename(record['path'])+': '+str(exc))
        self.space.setText(f'Enviado à Lixeira: {size_text(self.moved)}. Espaço efetivamente liberado por esta limpeza: 0 KiB.')
        self.refresh()
        if failures:QMessageBox.warning(self,'Arquivos não removidos','\n'.join(failures))
