"""Export setup, optional sample comparison and review of exported copies."""
import os,tempfile
from pathlib import Path
from PySide6.QtCore import Qt,QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,
 QComboBox,QCheckBox,QProgressBar,QFileDialog,QMessageBox,QListWidget,QListWidgetItem,QGroupBox)
from core.export_pipeline import ExportOptions
from workers.export_batch import ExportBatch,ExportSamples,DiscardCopies
from ui.photo_viewer import PhotoViewer,show_photo
from core.utils_os import reveal_in_file_manager

class ExportDialog(QDialog):
    def __init__(self,rows,parent=None):
        super().__init__(parent);self.rows=list(dict((r[0],r) for r in rows).values());self.worker=None;self.sample_worker=None;self.discard_worker=None
        self.temp=tempfile.TemporaryDirectory(prefix='acervo-amostras-');self.results=[];self.destination_used=None;self.removed=set()
        self.setWindowTitle('Exportar fotos');self.resize(840,720)
        layout=QVBoxLayout(self)
        note=QLabel(f'{len(self.rows)} fotos selecionadas. Os originais serão preservados. As cópias serão gravadas somente na pasta de destino.');note.setWordWrap(True);layout.addWidget(note)
        self.settings=QGroupBox('Opções de exportação');form=QVBoxLayout(self.settings);layout.addWidget(self.settings)
        row=QHBoxLayout();self.destination=QLineEdit();self.destination.setPlaceholderText('Pasta de destino');choose=QPushButton('Escolher pasta');choose.clicked.connect(self.choose_destination);row.addWidget(self.destination,1);row.addWidget(choose);form.addLayout(row)
        self.format=QComboBox();self.format.addItems(['Manter os formatos originais','Converter para JPG']);form.addWidget(self.format)
        self.method=QComboBox();self.method.addItems(['Rápida — aparência da câmera (com revelação se necessário)','Revelar RAW — resolução completa']);form.addWidget(self.method)
        self.limit=QCheckBox('Limitar cada JPG a 15 MB');self.limit.setChecked(True);form.addWidget(self.limit)
        help=QLabel('O JPG utiliza compressão com perdas. O limite pode reduzir qualidade e dimensões. PNG com transparência recebe fundo branco. A prévia embutida só é usada quando tem resolução próxima à do RAW.');help.setWordWrap(True);form.addWidget(help)
        row=QHBoxLayout();self.sample=QComboBox()
        for r in self.rows:self.sample.addItem(os.path.basename(r[0]),r)
        self.preview=QPushButton('Comparar amostra');self.preview.clicked.connect(self.preview_sample);row.addWidget(self.sample,1);row.addWidget(self.preview);form.addLayout(row)
        self.summary=QLabel();self.summary.setWordWrap(True);form.addWidget(self.summary)
        self.format.currentIndexChanged.connect(self.refresh_options);self.refresh_options()
        self.status=QLabel('Escolha as opções e o destino.');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.progress=QProgressBar();layout.addWidget(self.progress)
        explanation=QLabel('Revisão de exposição: sombras profundas e altas luzes simultâneas são apenas indícios. Cenas noturnas e contraluz podem ser intencionais. Nenhuma foto será excluída automaticamente.');explanation.setWordWrap(True);layout.addWidget(explanation)
        self.review=QListWidget();self.review.itemDoubleClicked.connect(self.show_result);layout.addWidget(self.review,1)
        row=QHBoxLayout();self.inspect=QPushButton('Visualizar cópia');self.inspect.clicked.connect(lambda:self.show_result(self.review.currentItem()));row.addWidget(self.inspect)
        self.discard=QPushButton('Enviar cópias marcadas para a Lixeira');self.discard.clicked.connect(self.discard_selected);row.addWidget(self.discard);layout.addLayout(row)
        row=QHBoxLayout();self.start=QPushButton('Iniciar exportação');self.start.clicked.connect(self.start_export);self.stop=QPushButton('Parar exportação');self.stop.clicked.connect(self.stop_export)
        self.open=QPushButton('Abrir pasta de destino');self.open.clicked.connect(self.open_destination);self.close_btn=QPushButton('Fechar');self.close_btn.clicked.connect(self.reject)
        for button in (self.start,self.stop,self.open,self.close_btn):row.addWidget(button)
        layout.addLayout(row);self.update_buttons()

    def busy(self):return any(w and w.isRunning() for w in (self.worker,self.sample_worker,self.discard_worker))
    def update_buttons(self):
        busy=self.busy();self.settings.setEnabled(not busy and self.worker is None);self.start.setEnabled(not busy and self.worker is None)
        self.stop.setEnabled(bool(self.worker and self.worker.isRunning()));self.close_btn.setEnabled(not busy)
        self.discard.setEnabled(not busy and bool(self.results));self.inspect.setEnabled(not busy and bool(self.results));self.open.setEnabled(bool(self.destination_used))
    def refresh_options(self):
        jpeg=self.format.currentIndex()==1;self.method.setEnabled(jpeg);self.limit.setEnabled(jpeg)
        originals=sum(Path(r[0]).suffix.lower() in ('.jpg','.jpeg') for r in self.rows)
        self.summary.setText(f'{len(self.rows)} arquivos no lote; {originals} já são JPG/JPEG. '+('JPGs dentro do limite serão copiados sem recompressão; os demais formatos serão convertidos.' if jpeg else 'Todos serão copiados no formato original.'))
    def choose_destination(self):
        path=QFileDialog.getExistingDirectory(self,'Destino das cópias',self.destination.text())
        if path:self.destination.setText(path)
    def preview_sample(self):
        if self.busy():return
        self.sample_worker=ExportSamples(self.sample.currentData(),self.temp.name,15_000_000 if self.limit.isChecked() else None,self)
        self.sample_worker.finished.connect(self.sample_ready);self.status.setText('Preparando as duas amostras. O RAW completo pode demorar.');self.sample_worker.start();self.update_buttons()
    def sample_ready(self):
        w=self.sample_worker;self.update_buttons();self.status.setText('\n'.join(w.notes+w.errors))
        if w.paths:
            viewer=PhotoViewer(w.paths,self,reason='\n'.join(w.notes));viewer.exec();viewer.deleteLater()
    def start_export(self):
        if self.busy() or self.worker is not None:return
        target=Path(self.destination.text()).expanduser()
        if not self.destination.text().strip() or not target.is_dir():
            QMessageBox.warning(self,'Destino','Escolha uma pasta existente para receber as cópias.');return
        self.destination_used=str(target.resolve())
        options=ExportOptions(self.format.currentIndex()==1,'camera' if self.method.currentIndex()==0 else 'develop',15_000_000 if self.limit.isChecked() else None)
        self.worker=ExportBatch(self.rows,self.destination_used,options,self);self.worker.progress.connect(self.on_progress);self.worker.finished.connect(self.export_finished)
        self.worker.start();self.update_buttons()
    def on_progress(self,n,total,path):
        self.progress.setRange(0,total);self.progress.setValue(n);self.status.setText(f'{n}/{total} concluídos — {os.path.basename(path)}')
    def stop_export(self):
        if self.worker:self.worker.requestInterruption();self.status.setText('Parando após o arquivo atual…')
    def export_finished(self):
        self.results=self.worker.results;self.review.clear();count=0
        for record in self.results:
            if record['warning']:
                count+=1;item=QListWidgetItem(os.path.basename(record['path'])+'\n'+record['warning']);item.setData(Qt.UserRole,record);item.setFlags(item.flags()|Qt.ItemIsUserCheckable);item.setCheckState(Qt.Unchecked);item.setToolTip(record['path']);self.review.addItem(item)
        notes=[os.path.basename(r['path'])+': '+' '.join(r['notes']) for r in self.results if r['notes']]
        self.status.setText(f'{len(self.results)} cópias concluídas; {len(self.worker.errors)} falhas; {count} cópias para revisão visual.'+(' Exportação interrompida.' if self.worker.stopped else ''))
        self.update_buttons()
        # Keep a local report so warnings remain accessible after closing the dialog.
        import json
        report={'completed':len(self.results),'stopped':self.worker.stopped,'errors':self.worker.errors,'files':self.results}
        report_path=Path(self.temp.name)/'relatorio-exportacao.json'
        report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        if self.worker.errors or notes:
            box=QMessageBox(self);box.setWindowTitle('Relatório de exportação');box.setText('Consulte as falhas e observações sobre conversão, tamanho e metadados.');box.setDetailedText('\n'.join(self.worker.errors+notes));box.exec()
    def show_result(self,item):
        if item and not self.busy():show_photo(item.data(Qt.UserRole)['path'],self)
    def discard_selected(self):
        records=[self.review.item(i).data(Qt.UserRole) for i in range(self.review.count()) if self.review.item(i).checkState()==Qt.Checked]
        if not records or self.busy():return
        answer=QMessageBox.question(self,'Confirmar exclusão das cópias',f'Enviar {len(records)} cópias exportadas para a Lixeira? Os originais serão preservados.\n\n'+'\n'.join(os.path.basename(r['path']) for r in records[:10]),QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if answer!=QMessageBox.Yes:return
        self.discard_worker=DiscardCopies(records,self.destination_used,self);self.discard_worker.finished.connect(self.discard_finished);self.discard_worker.start();self.update_buttons()
    def discard_finished(self):
        self.removed.update(self.discard_worker.removed)
        for i in range(self.review.count()-1,-1,-1):
            if self.review.item(i).data(Qt.UserRole)['path'] in self.removed:self.review.takeItem(i)
        self.status.setText(f'{len(self.discard_worker.removed)} cópias enviadas para a Lixeira. Originais preservados.');self.update_buttons()
        if self.discard_worker.errors:QMessageBox.warning(self,'Cópias não removidas','\n'.join(self.discard_worker.errors))
    def open_destination(self):
        if self.destination_used:QDesktopServices.openUrl(QUrl.fromLocalFile(self.destination_used))
    def reject(self):
        if self.busy():
            self.status.setText('Aguarde o processamento atual; use Parar exportação para interromper o lote.');return
        super().reject()
    def closeEvent(self,event):
        if self.busy():event.ignore();return
        super().closeEvent(event)
