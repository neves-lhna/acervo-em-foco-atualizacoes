"""
ui/crop_dialog.py
--------------------
Diálogo para selecionar o rosto de referência na foto principal.

UX escolhida: em vez de pedir para o usuário desenhar manualmente um
retângulo "no escuro", o diálogo primeiro roda a detecção facial na
imagem inteira (rápido, uma única imagem) e desenha caixas ao redor de
cada rosto encontrado. O usuário simplesmente clica no rosto correto.

Como fallback (ex.: nenhum rosto detectado automaticamente, foto muito
grande angulada etc.), também é oferecido um modo de recorte manual via
arraste do mouse (rubber-band selection) sobre a imagem.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
from PySide6.QtCore import Qt, QRect, QPoint, Signal,QObject,QRunnable,QThreadPool
from PySide6.QtGui import QPixmap, QImage, QPainter, QPen, QColor
from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QWidget,
)

from core.face_engine import FaceEngine, DetectedFace


class DetectionSignals(QObject):
    ready=Signal(object,str)


class DetectionJob(QRunnable):
    def __init__(self,image):
        super().__init__();self.image=image;self.signals=DetectionSignals()
    def run(self):
        try:self.signals.ready.emit(FaceEngine.instance().detect_faces(self.image),'')
        except Exception as exc:self.signals.ready.emit([],str(exc))


def bgr_to_qpixmap(bgr: np.ndarray) -> QPixmap:
    rgb = bgr[:, :, ::-1].copy()
    h, w, ch = rgb.shape
    qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
    return QPixmap.fromImage(qimg)


class _ImageCanvas(QLabel):
    """Label que desenha a imagem + caixas detectadas e trata cliques
    (seleção automática) e arraste do mouse (recorte manual)."""

    face_clicked = Signal(int)          # índice do rosto detectado clicado
    manual_rect_selected = Signal(QRect)

    def __init__(self, pixmap: QPixmap, faces: list[DetectedFace], scale: float):
        super().__init__()
        self._base_pixmap = pixmap
        self._faces = faces
        self._scale = scale  # fator entre pixmap exibido e imagem original
        self._drag_start: Optional[QPoint] = None
        self._drag_rect: Optional[QRect] = None
        self.manual_mode = False
        self.setPixmap(pixmap)
        # Keep the image origin equal to the origin used by mouse coordinates.
        self.setFixedSize(pixmap.size())
        self.selected_index = None
        self.setMouseTracking(True)

    def set_manual_mode(self, enabled: bool):
        self.manual_mode = enabled
        self._drag_rect = None
        self.update()

    def mousePressEvent(self, event):
        if self.manual_mode:
            self._drag_start = event.position().toPoint()
            self._drag_rect = QRect(self._drag_start, self._drag_start)
            self.update()
            return

        pos = event.position().toPoint()
        for idx, face in enumerate(self._faces):
            x1, y1, x2, y2 = (face.bbox * self._scale).astype(int)
            if QRect(QPoint(x1, y1), QPoint(x2, y2)).contains(pos):
                self.face_clicked.emit(idx)
                return

    def mouseMoveEvent(self, event):
        if self.manual_mode and self._drag_start is not None:
            self._drag_rect = QRect(self._drag_start, event.position().toPoint()).normalized()
            self.update()

    def mouseReleaseEvent(self, event):
        if self.manual_mode and self._drag_rect is not None and self._drag_rect.width() > 5:
            self.manual_rect_selected.emit(self._drag_rect)
        self._drag_start = None

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        pen = QPen(QColor(0, 200, 255), 3)
        painter.setPen(pen)

        if not self.manual_mode:
            for index, face in enumerate(self._faces):
                painter.setPen(QPen(QColor(0, 220, 80) if index == self.selected_index
                                    else QColor(0, 200, 255), 3))
                x1, y1, x2, y2 = (face.bbox * self._scale).astype(int)
                painter.drawRect(QRect(QPoint(int(x1), int(y1)), QPoint(int(x2), int(y2))))
        elif self._drag_rect is not None:
            painter.setPen(QPen(QColor(255, 120, 0), 2, Qt.DashLine))
            painter.drawRect(self._drag_rect)


class CropDialog(QDialog):
    """
    Retorna, via `self.selected_embedding` (np.ndarray 512D) após
    `exec()` == QDialog.Accepted, o embedding do rosto escolhido pelo
    usuário como referência para a busca.
    """

    def __init__(self, bgr_image: np.ndarray, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Selecione o rosto de referência")
        self.resize(760, 640)

        self.original_bgr = bgr_image
        self.selected_embedding: Optional[np.ndarray] = None
        self.selected_pose: Optional[str] = None
        self.selected_crop = None

        # Detecta todos os rostos da foto de referência uma única vez.
        self._faces=[];self._detecting=False

        # Escala a imagem para caber na tela mantendo proporção.
        pixmap = bgr_to_qpixmap(bgr_image)
        max_dim = 720
        available_height = max(200, self.screen().availableGeometry().height() - 280)
        self._scale = min(1.0, max_dim / pixmap.width(), available_height / pixmap.height())
        display_pixmap = pixmap.scaled(
            int(pixmap.width() * self._scale),
            int(pixmap.height() * self._scale),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation,
        )

        self.canvas = _ImageCanvas(display_pixmap, self._faces, self._scale)
        self.canvas.face_clicked.connect(self._on_face_clicked)
        self.canvas.manual_rect_selected.connect(self._on_manual_rect)

        info_text = (
            f"{len(self._faces)} rosto(s) detectado(s) automaticamente. "
            "Clique em um rosto destacado para selecioná-lo."
            if self._faces
            else "Nenhum rosto detectado automaticamente. Use o recorte manual abaixo."
        )
        self.info_label = QLabel(info_text)
        self.info_label.setWordWrap(True)
        self.selection_preview = QLabel("Selecione o rosto que deseja buscar.")
        self.selection_preview.setFixedHeight(120)

        self.manual_btn = QPushButton("Recorte manual (arraste sobre o rosto)")
        self.manual_btn.setCheckable(True)
        self.manual_btn.toggled.connect(self.canvas.set_manual_mode)

        self.confirm_btn = QPushButton("Confirmar seleção")
        self.confirm_btn.setEnabled(False)
        self.confirm_btn.clicked.connect(self.accept)

        cancel_btn = QPushButton("Cancelar")
        cancel_btn.clicked.connect(self.reject)

        btn_row = QHBoxLayout()
        btn_row.addWidget(self.manual_btn)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(self.confirm_btn)

        layout = QVBoxLayout(self)
        layout.addWidget(self.info_label)
        layout.addWidget(self.selection_preview)
        layout.addWidget(self.canvas, stretch=1)
        layout.addLayout(btn_row)
        self._begin_detection(self.original_bgr,False)

    def _begin_detection(self,image,manual):
        if self._detecting:return
        self._detecting=True;self._detection_image=image;self._manual_detection=manual
        self.manual_btn.setEnabled(False);self.canvas.setEnabled(False);self.confirm_btn.setEnabled(False)
        self.info_label.setText('Detectando rostos… Aguarde ou cancele a seleção.')
        self._job=DetectionJob(image);self._job.signals.ready.connect(self._detection_ready)
        QThreadPool.globalInstance().start(self._job)

    def _detection_ready(self,faces,error):
        self._detecting=False;self.manual_btn.setEnabled(True);self.canvas.setEnabled(True)
        if error:self.info_label.setText('Não foi possível detectar os rostos: '+error);return
        if self._manual_detection:
            if not faces:self.info_label.setText('Nenhum rosto encontrado no recorte. Tente novamente.');return
            best=max(faces,key=lambda f:f.det_score)
            self.selected_embedding=best.embedding;self.selected_pose=best.pose
            self._show_selected_crop(self._detection_image,best.bbox)
            self.info_label.setText('Confira o rosto selecionado no recorte antes de confirmar.');self.confirm_btn.setEnabled(True)
        else:
            self._faces=faces;self.canvas._faces=faces;self.canvas.update()
            self.info_label.setText(f'{len(faces)} rosto(s) encontrado(s). Clique em um rosto ou use o recorte manual.')

    # ------------------------------------------------------------------
    def _on_face_clicked(self, idx: int):
        face = self._faces[idx]
        self.selected_embedding = face.embedding
        self.selected_pose = face.pose
        self.canvas.selected_index = idx
        self.canvas.update()
        self._show_selected_crop(self.original_bgr, face.bbox)
        self.info_label.setText("Confira o rosto abaixo antes de confirmar a referência.")
        self.confirm_btn.setEnabled(True)

    def _show_selected_crop(self, image, bbox):
        h, w = image.shape[:2]
        x1, y1, x2, y2 = bbox.astype(int)
        self.selected_crop = image[max(0, y1):min(h, y2), max(0, x1):min(w, x2)].copy()
        if self.selected_crop.size:
            self.selection_preview.setPixmap(bgr_to_qpixmap(self.selected_crop).scaled(
                120, 120, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _on_manual_rect(self, rect: QRect):
        # Converte coordenadas exibidas -> coordenadas da imagem original
        x1 = int(rect.left() / self._scale)
        y1 = int(rect.top() / self._scale)
        x2 = int(rect.right() / self._scale)
        y2 = int(rect.bottom() / self._scale)

        h, w = self.original_bgr.shape[:2]
        x1, x2 = max(0, x1), min(w, x2)
        y1, y2 = max(0, y1), min(h, y2)
        if x2 - x1 < 10 or y2 - y1 < 10:
            return

        crop = self.original_bgr[y1:y2, x1:x2]
        self._begin_detection(crop.copy(),True)
