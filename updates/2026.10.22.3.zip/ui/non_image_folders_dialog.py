import os
from collections import Counter

from PySide6.QtCore import QFileInfo, Qt, QThread, Signal, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel, QMenu,
    QAbstractItemView, QFileIconProvider, QHeaderView, QMessageBox, QProgressBar,
    QPushButton, QTreeWidget, QVBoxLayout, QWidget)

from ui.table_sorting import SORT_ROLE, SortableItem, enable_header_sort


def format_size(value):
    value = float(value)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if value < 1024 or unit == 'TB':
            return f'{value:.0f} {unit}' if unit == 'B' else f'{value:.1f} {unit}'
        value /= 1024


def inspect_non_image_folder(path):
    """Describe a folder that has no image recognized by the inventory."""
    size = file_count = folder_count = empty_folders = 0
    types = Counter()
    errors = []

    def walk_error(exc):
        errors.append(str(exc))

    if not os.path.isdir(path):
        return {
            'path': path, 'size': 0, 'file_count': 0, 'folder_count': 0,
            'empty_folders': 0, 'types': '—', 'status': 'Indisponível',
            'details': 'A pasta não está disponível no momento.'}

    root_key = os.path.normcase(os.path.abspath(path))
    for folder, dirs, files in os.walk(path, onerror=walk_error, followlinks=False):
        dirs[:] = [name for name in dirs if not os.path.islink(os.path.join(folder, name))]
        if os.path.normcase(os.path.abspath(folder)) != root_key:
            folder_count += 1
            if not dirs and not files:
                empty_folders += 1
        for name in files:
            file_count += 1
            file_path = os.path.join(folder, name)
            extension = os.path.splitext(name)[1].lower()
            types[extension or '(sem extensão)'] += 1
            try:
                size += os.path.getsize(file_path)
            except OSError as exc:
                errors.append(str(exc))

    type_text = ', '.join(
        f'{extension.upper()} ({count})' for extension, count in
        sorted(types.items(), key=lambda item: (-item[1], item[0]))) or '—'
    if errors:
        status = 'Acesso incompleto'
        details = errors[0]
    elif file_count:
        status = 'Outros tipos de arquivo'
        details = f'{file_count} arquivo(s) que não são imagens compatíveis.'
    elif folder_count:
        status = 'Somente subpastas vazias'
        details = f'{folder_count} subpasta(s), sem arquivos compatíveis.'
    else:
        status = 'Vazia'
        details = 'A pasta não contém arquivos nem subpastas.'
    return {
        'path': path, 'size': size, 'file_count': file_count,
        'folder_count': folder_count, 'empty_folders': empty_folders,
        'types': type_text, 'status': status, 'details': details}


def collapse_nested_paths(paths):
    """Keep only the broadest selected folders so a subtree is trashed once."""
    result = []
    for path in sorted({os.path.abspath(path) for path in paths}, key=len):
        key = os.path.normcase(path)
        if any(os.path.commonpath([key, existing]) == existing for existing in result):
            continue
        result.append(key)
    return result


class FolderDetailsWorker(QThread):
    record_ready = Signal(object)

    def __init__(self, paths, parent=None):
        super().__init__(parent)
        self.paths = tuple(paths)

    def run(self):
        for path in self.paths:
            if self.isInterruptionRequested():
                break
            self.record_ready.emit(inspect_non_image_folder(path))


class NonImageFoldersDialog(QDialog):
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.worker = None
        self.icon_provider = QFileIconProvider()
        self.setWindowTitle('Pastas vazias ou com outros tipos de arquivo')
        self.setWindowFlag(Qt.WindowMaximizeButtonHint, True)
        self.resize(1250, 680)
        layout = QVBoxLayout(self)
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels([
            'Pasta', 'Tamanho', 'Tipos de arquivos', 'Situação',
            'Subpastas vazias', 'Arquivos', 'Ações'])
        self.tree.setColumnWidth(0, 390)
        self.tree.setColumnWidth(1, 100)
        self.tree.setColumnWidth(2, 280)
        self.tree.setColumnWidth(3, 210)
        self.tree.setColumnWidth(4, 140)
        self.tree.setColumnWidth(5, 90)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(6, QHeaderView.Fixed)
        self.tree.setColumnWidth(6, 74)
        enable_header_sort(self.tree)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.open_menu)
        self.tree.itemDoubleClicked.connect(lambda item, column: self.open_selected())
        layout.addWidget(self.tree, 1)
        row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setTextVisible(True)
        self.refresh_btn = QPushButton('Atualizar detalhes')
        self.select_all_btn = QPushButton('Selecionar todas')
        self.trash_selected_btn = QPushButton('Mover selecionadas para a Lixeira (0)')
        self.open_btn = QPushButton('Abrir pasta')
        close_btn = QPushButton('Fechar')
        self.refresh_btn.clicked.connect(lambda: self.refresh(self.owner.non_image_records))
        self.select_all_btn.clicked.connect(self.tree.selectAll)
        self.trash_selected_btn.clicked.connect(self.trash_selected)
        self.open_btn.clicked.connect(self.open_selected)
        close_btn.clicked.connect(self.close)
        row.addWidget(self.progress, 1)
        row.addWidget(self.refresh_btn)
        row.addWidget(self.select_all_btn)
        row.addWidget(self.trash_selected_btn)
        row.addWidget(self.open_btn)
        row.addWidget(close_btn)
        layout.addLayout(row)
        self.tree.itemSelectionChanged.connect(self.sync_selection)
        self.sync_selection()

    def refresh(self, paths):
        if self.worker is not None and self.worker.isRunning():
            return
        paths = tuple(sorted(set(paths), key=str.casefold))
        self.tree.clear()
        self.tree.setSortingEnabled(False)
        self.progress.setRange(0, len(paths))
        self.progress.setValue(0)
        self.summary.setText(
            f'Conferindo {len(paths)} pasta(s) sem imagens compatíveis…')
        self.refresh_btn.setEnabled(False)
        self.worker = FolderDetailsWorker(paths, self)
        self.worker.record_ready.connect(self.add_record)
        self.worker.finished.connect(self.finish_loading)
        self.worker.start()

    def add_record(self, record):
        item = SortableItem(self.tree)
        path = record['path']
        values = [
            os.path.basename(os.path.normpath(path)) or path,
            format_size(record['size']), record['types'], record['status'],
            str(record['empty_folders']), str(record['file_count'])]
        for column, value in enumerate(values):
            item.setText(column, value)
        item.setData(0, Qt.UserRole, path)
        item.setToolTip(0, path)
        item.setToolTip(2, record['types'])
        item.setToolTip(3, record['details'])
        for column, value in ((1, record['size']), (4, record['empty_folders']),
                              (5, record['file_count'])):
            item.setData(column, SORT_ROLE, value)
        actions = QWidget()
        action_layout = QHBoxLayout(actions)
        action_layout.setContentsMargins(2, 1, 2, 1)
        action_layout.setSpacing(2)
        open_button = QPushButton()
        open_button.setIcon(self.icon_provider.icon(QFileInfo(path)))
        open_button.setToolTip('Abrir esta pasta no Explorer')
        open_button.setStyleSheet(
            'QPushButton {background:transparent;border:none;padding:0;}')
        open_button.clicked.connect(lambda checked=False, value=path: self.open_path(value))
        trash_button = QPushButton('×')
        trash_button.setToolTip('Mover esta pasta e todo o seu conteúdo para a Lixeira')
        trash_button.setStyleSheet(
            'QPushButton {background:transparent;border:none;padding:0;color:#e53935;}')
        trash_button.clicked.connect(
            lambda checked=False, value=path: self.trash_folder(value))
        for button in (open_button, trash_button):
            button.setFixedSize(28, 28)
            action_layout.addWidget(button)
        self.tree.setItemWidget(item, 6, actions)
        self.progress.setValue(self.progress.value() + 1)

    def finish_loading(self):
        count = self.tree.topLevelItemCount()
        self.summary.setText(
            f'{count} pasta(s) sem imagens compatíveis. '
            'O tamanho de cada linha inclui os arquivos existentes em suas subpastas.')
        self.tree.setSortingEnabled(True)
        self.refresh_btn.setEnabled(True)

    def selected_path(self):
        item = self.tree.currentItem()
        return item.data(0, Qt.UserRole) if item is not None else None

    def selected_paths(self):
        return [item.data(0, Qt.UserRole) for item in self.tree.selectedItems()]

    def sync_selection(self):
        count = len(self.tree.selectedItems())
        self.open_btn.setEnabled(count == 1)
        self.trash_selected_btn.setEnabled(count > 0)
        self.trash_selected_btn.setText(f'Mover selecionadas para a Lixeira ({count})')

    def open_selected(self):
        path = self.selected_path()
        self.open_path(path)

    def open_path(self, path):
        if path and os.path.isdir(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def trash_folder(self, path):
        self.trash_paths([path])

    def trash_selected(self):
        self.trash_paths(self.selected_paths())

    def trash_paths(self, paths):
        main = self.owner.window()
        if ((hasattr(main, '_busy') and main._busy()) or
                (hasattr(main, '_cache_running') and main._cache_running())):
            QMessageBox.information(
                self, 'Análise em andamento',
                'Pare a coleta ou aguarde a análise terminar antes de mover uma pasta.')
            return
        paths = [path for path in collapse_nested_paths(paths) if os.path.isdir(path)]
        if not paths:
            QMessageBox.information(
                self, 'Pasta indisponível',
                'As pastas selecionadas não estão mais disponíveis. Atualize os detalhes para conferir a lista.')
            return
        records = [inspect_non_image_folder(path) for path in paths]
        total_files = sum(record['file_count'] for record in records)
        total_size = sum(record['size'] for record in records)
        if len(paths) > 1:
            question = (f'Mover {len(paths)} pastas selecionadas para a Lixeira?')
            detail = (f'Elas contêm {total_files} arquivo(s), totalizando '
                      f'{format_size(total_size)}. Pastas internas selecionadas junto com '
                      'a pasta principal são contabilizadas apenas uma vez.')
        else:
            record = records[0]
            name = os.path.basename(os.path.normpath(paths[0])) or paths[0]
            if record['file_count']:
                question = (f'Mover “{name}” e seus {record["file_count"]} arquivo(s) '
                            f'({format_size(record["size"])}) para a Lixeira?')
                detail = ('A pasta contém outros tipos de arquivo: ' + record['types'] +
                          '. Nenhuma foto compatível foi encontrada. Confira antes de confirmar.')
            else:
                question = f'Mover a pasta vazia “{name}” para a Lixeira?'
                detail = (f'Também serão movidas {record["folder_count"]} subpasta(s) vazia(s). '
                          'A pasta poderá ser restaurada pela Lixeira do Windows.')
        box = QMessageBox(QMessageBox.Warning, 'Mover pasta para a Lixeira',
                          question, parent=self)
        box.setInformativeText(detail)
        move = box.addButton('Mover para a Lixeira', QMessageBox.AcceptRole)
        cancel = box.addButton('Cancelar', QMessageBox.RejectRole)
        box.setDefaultButton(cancel)
        box.exec()
        if box.clickedButton() != move:
            return
        from send2trash import send2trash
        moved = []
        failures = []
        for path in paths:
            try:
                send2trash(path)
                moved.append(path)
            except Exception as exc:
                failures.append(f'{path}: {exc}')
        targets = [os.path.normcase(os.path.abspath(path)) for path in moved]
        def outside(candidate):
            try:
                key = os.path.normcase(os.path.abspath(candidate))
                return not any(os.path.commonpath([target, key]) == target for target in targets)
            except ValueError:
                return True
        self.owner.non_image_records = [
            candidate for candidate in self.owner.non_image_records if outside(candidate)]
        if hasattr(self.owner, 'stat_values') and len(self.owner.stat_values) > 3:
            self.owner.stat_values[3].setText(str(len(self.owner.non_image_records)))
        self.refresh(self.owner.non_image_records)
        if moved and self.owner.refresh_btn.isEnabled():
            self.owner.refresh_inventory()
        if failures:
            QMessageBox.warning(
                self, 'Algumas pastas não foram movidas', '\n'.join(failures[:8]))

    def open_menu(self, position):
        item = self.tree.itemAt(position)
        if item is None:
            return
        self.tree.setCurrentItem(item)
        path = self.selected_path()
        menu = QMenu(self)
        action = menu.addAction('Abrir pasta no Explorer')
        action.setEnabled(bool(path and os.path.isdir(path)))
        action.triggered.connect(self.open_selected)
        menu.addAction('Copiar caminho da pasta').triggered.connect(
            lambda: QApplication.clipboard().setText(path))
        menu.exec(self.tree.viewport().mapToGlobal(position))

    def closeEvent(self, event):
        if self.worker is not None and self.worker.isRunning():
            self.worker.requestInterruption()
            self.worker.wait(2000)
        super().closeEvent(event)
