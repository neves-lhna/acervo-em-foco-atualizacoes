"""Independent duplicate-photo workspace; selection remains owned by DuplicatesTab."""
import os
from PySide6.QtCore import Qt,QSize,QThreadPool,Signal
from PySide6.QtGui import QIcon,QPixmap
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QTabBar,QStackedWidget,QListWidget,QListWidgetItem,QAbstractItemView,QCheckBox,QMenu,QApplication,QBoxLayout)
from ui.photo_viewer import PhotoCanvas
from ui.image_folder_dialog import PreviewJob,PreviewSignals
from core.duplicate_selection import image_info
from core.utils_os import reveal_files_in_file_manager


class DuplicatePreviewSignals(PreviewSignals):
    details=Signal(int,str)


class DuplicatePreviewJob(PreviewJob):
    def __init__(self,*args):
        super().__init__(*args);self.signals=DuplicatePreviewSignals()
    def run(self):
        try:
            stat=os.stat(self.path);text=image_info(self.path,stat.st_mtime_ns,stat.st_size)
        except OSError:text='Arquivo indisponível ou removido.'
        self.signals.details.emit(self.token,text)
        super().run()


class DuplicateCanvas(PhotoCanvas):
    double_clicked=Signal()
    def mouseDoubleClickEvent(self,event):
        if event.button()==Qt.LeftButton:
            self.double_clicked.emit();event.accept();return
        super().mouseDoubleClickEvent(event)


class DuplicateBrowser(QWidget):
    PAGE_PAIRS=12
    def __init__(self,owner):
        super().__init__(owner)
        self.owner=owner;self.pairs=[];self.run_id=None;self.index=0;self.focus=0
        self.generation=0;self.busy=[False,False];self.jobs=[None,None];self.desired=[None,None]
        self.path_keys=[];self.gallery_page=-1;self.loaded=[-1,-1]
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0)
        self.controls=QWidget();controls=QVBoxLayout(self.controls);controls.setContentsMargins(0,0,0,0)
        bar=QHBoxLayout();self.mode=QTabBar();self.mode.setExpanding(False);self.mode.setDrawBase(False)
        for title in ('Comparação','Galeria'):self.mode.addTab(title)
        self.mode.setToolTip('Troque a apresentação sem alterar as fotos marcadas para a Lixeira.')
        controls.addWidget(self.mode)
        self.previous=QPushButton('❮');self.previous.setAccessibleName('Par anterior')
        self.next=QPushButton('❯');self.next.setAccessibleName('Próximo par')
        self.counter=QLabel('Nenhum par');self.counter.setAlignment(Qt.AlignCenter)
        self.counter.setToolTip('Pares de fotos semelhantes. Uma mesma foto pode participar de vários pares; este número não é a quantidade de arquivos a excluir.')
        self.previous.clicked.connect(lambda:self.go(self.index-1));self.next.clicked.connect(lambda:self.go(self.index+1))
        bar.addWidget(self.previous);bar.addWidget(self.counter);bar.addWidget(self.next);bar.insertStretch(0);bar.addStretch();layout.addLayout(bar)
        self.score=QLabel();bar.addWidget(self.score)
        info=QHBoxLayout()
        self.folder_buttons=[]
        for column in range(2):
            button=QPushButton();button.clicked.connect(lambda checked=False,c=column:self.open_folder(c))
            info.addWidget(button);self.folder_buttons.append(button)
        bar.addLayout(info)
        self.stack=QStackedWidget();layout.addWidget(self.stack,1)
        self.comparison=QWidget();columns=QBoxLayout(QBoxLayout.LeftToRight,self.comparison);self.columns=columns;columns.setContentsMargins(0,0,0,0)
        self.canvases=[];self.panels=[];self.names=[];self.messages=[];self.choices=[];self.metadata=[]
        for column in range(2):
            panel=QWidget();panel.setMinimumWidth(0);col=QVBoxLayout(panel);col.setContentsMargins(4,4,4,4)
            
            canvas=DuplicateCanvas();canvas.setMinimumSize(80,100);col.addWidget(canvas,1)
            canvas.setStyleSheet('QGraphicsView {background:#17232e;border:0;}')
            canvas.zoom_requested.connect(self.zoom_at)
            canvas.double_clicked.connect(lambda c=column:self.open_image_folder(self.index,c))
            canvas.setContextMenuPolicy(Qt.CustomContextMenu)
            canvas.customContextMenuRequested.connect(lambda point,c=column:self.photo_menu(self.index,c,self.canvases[c].viewport().mapToGlobal(point)))
            canvas.setToolTip('Botão direito: opções da foto. Duplo clique: abrir na pasta.')
            name=QLabel();name.setTextFormat(Qt.PlainText);name.setWordWrap(True);name.setMinimumWidth(0);col.addWidget(name)
            metadata=QLabel();metadata.setObjectName("Muted");metadata.setWordWrap(True);col.addWidget(metadata);self.metadata.append(metadata)
            message=QLabel();message.setWordWrap(True);col.addWidget(message)
            choice=QCheckBox('Selecionar para a Lixeira');choice.toggled.connect(lambda marked,c=column:self.mark(c,marked));col.addWidget(choice)
            self.canvases.append(canvas);self.names.append(name);self.messages.append(message)
            tools=QHBoxLayout();tools.addStretch()
            for label,factor in [('−',.8),('+',1.25)]:
                button=QPushButton(label);button.setFixedWidth(34)
                button.clicked.connect(lambda checked=False,c=column,f=factor:self.zoom_photo(c,f));tools.addWidget(button)
            fit=QPushButton('Ajustar');fit.clicked.connect(lambda checked=False,c=column:self.fit_photo(c));tools.addWidget(fit)
            col.addLayout(tools)
            self.panels.append(panel);self.choices.append(choice);columns.addWidget(panel,1)
        self.stack.addWidget(self.comparison)
        self.gallery=QListWidget();self.gallery.setViewMode(QListWidget.IconMode);self.gallery.setResizeMode(QListWidget.Adjust)
        self.gallery.setMovement(QListWidget.Static);self.gallery.setIconSize(QSize(180,125));self.gallery.setGridSize(QSize(210,180))
        self.gallery.setSelectionMode(QAbstractItemView.SingleSelection)
        self.gallery.itemChanged.connect(self.gallery_mark);self.gallery.itemDoubleClicked.connect(self.open_item_folder)
        self.stack.addWidget(self.gallery)
        self.empty=QWidget();empty_layout=QVBoxLayout(self.empty);empty_layout.addStretch()
        self.empty_text=QLabel('Selecione uma verificação para visualizar os pares encontrados.');self.empty_text.setWordWrap(True);self.empty_text.setAlignment(Qt.AlignCenter);empty_layout.addWidget(self.empty_text)
        self.done_actions=QWidget();done=QHBoxLayout(self.done_actions)
        for title,callback in [('Verificar novamente',owner.rerun_selected),('Escolher outra pasta',owner.choose_folder),('Fotos excluídas',owner.open_deleted.emit)]:
            button=QPushButton(title);button.clicked.connect(callback);done.addWidget(button)
        empty_layout.addWidget(self.done_actions);self.done_actions.hide();empty_layout.addStretch()
        self.stack.addWidget(self.empty)
        self.zoom_bar=QWidget();zoom=QHBoxLayout(self.zoom_bar);zoom.setContentsMargins(0,0,0,0);zoom.addStretch()
        for label,factor in [('−',.8),('+',1.25)]:
            button=QPushButton(label);button.setAccessibleName('Diminuir zoom' if factor<1 else 'Aumentar zoom')
            button.clicked.connect(lambda checked=False,f=factor:self.zoom(f));zoom.addWidget(button)
        fit=QPushButton('Ajustar');fit.clicked.connect(self.fit);zoom.addWidget(fit)
        full=QPushButton('⛶');full.setToolTip('Abrir comparação ampliada de todas as versões relacionadas');full.setAccessibleName('Ampliar comparação');full.clicked.connect(self.open_comparison);zoom.addWidget(full);zoom.addStretch()
        self.zoom_bar.hide()
        self.thumbnails=QListWidget();self.thumbnails.setViewMode(QListWidget.IconMode);self.thumbnails.setGridSize(QSize(120,90));self.thumbnails.setFlow(QListWidget.LeftToRight);self.thumbnails.setWrapping(False)
        self.thumbnails.setIconSize(QSize(100,70));self.thumbnails.setFixedHeight(105)
        self.thumbnails.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.thumbnails.itemClicked.connect(self.activate_thumbnail);layout.addWidget(self.thumbnails)
        self.page_controls=QWidget();page_row=QHBoxLayout(self.page_controls);page_row.setContentsMargins(0,0,0,0)
        self.page_back=QPushButton('Miniaturas anteriores');self.page_forward=QPushButton('Mais miniaturas');self.page_info=QLabel()
        self.page_back.clicked.connect(lambda:self.go(max(0,(self.index//self.PAGE_PAIRS-1)*self.PAGE_PAIRS)))
        self.page_forward.clicked.connect(lambda:self.go((self.index//self.PAGE_PAIRS+1)*self.PAGE_PAIRS))
        page_row.addWidget(self.page_back);page_row.addWidget(self.page_info,1);page_row.addWidget(self.page_forward);layout.addWidget(self.page_controls)
        for view in (self.gallery,self.thumbnails):
            view.setContextMenuPolicy(Qt.CustomContextMenu)
            view.customContextMenuRequested.connect(lambda point,v=view:self.item_menu(v,point))
        self.thumbnails.itemDoubleClicked.connect(self.open_item_folder)
        self.mode.currentChanged.connect(self.apply_mode);self.apply_mode()

    def zoom_photo(self,column,factor):
        self.focus=column;self.zoom(factor)

    def fit_photo(self,column):
        self.focus=column;self.fit()

    def showEvent(self,event):
        super().showEvent(event)
        if self.mode.currentIndex()==0:
            for c in range(2):self.load(c)

    def set_pairs(self,pairs,run_id):
        pairs=list(pairs)
        if pairs==self.pairs and run_id==self.run_id:
            self.owner.checkboxes={key:[self.choices[c]] for c,key in enumerate(self.path_keys)}
            self.sync_selection();return
        previous=self.pairs[self.index][:2] if self.pairs and run_id==self.run_id else None
        old_index=self.index if run_id==self.run_id else 0
        self.pairs=pairs;self.run_id=run_id;self.gallery_page=-1
        self.index=next((i for i,p in enumerate(pairs) if p[:2]==previous),min(old_index,max(0,len(pairs)-1)))
        self.render()

    def go(self,index):
        if not 0<=index<len(self.pairs):return
        self.index=index;self.render()

    def render(self):
        self.generation+=1
        self.previous.setEnabled(self.index>0);self.next.setEnabled(self.index+1<len(self.pairs))
        self.counter.setText(f'Par {self.index+1} de {len(self.pairs)}' if self.pairs else 'Nenhum par')
        self.owner.checkboxes={};self.path_keys=[]
        if not self.pairs:
            self.desired=[None,None];self.score.clear();self.thumbnails.clear();self.gallery.clear();self.apply_mode();return
        a,b,score=self.pairs[self.index];self.score.setText(f'Similaridade: {score:.2f} / 10')
        same=os.path.normcase(os.path.dirname(a))==os.path.normcase(os.path.dirname(b))
        self.folder_buttons[0].setText('📁 Mesma pasta' if same else '📁 1ª pasta')
        self.folder_buttons[1].setText('📁 2ª pasta');self.folder_buttons[1].setVisible(not same)
        for c,path in enumerate((a,b)):
            self.folder_buttons[c].setToolTip(os.path.dirname(path))
            self.names[c].setText(f'{c+1}ª opção — {os.path.basename(path)}');self.names[c].setToolTip(path)
            self.path_keys.append((c,path));self.owner.checkboxes[(c,path)]=[self.choices[c]]
            self.desired[c]=path
            canvas=self.canvases[c];canvas.item=None;canvas.scene().clear();canvas.resetTransform()
            cached=self.owner.db.execute('SELECT thumb FROM signatures WHERE path=?',(path,)).fetchone()
            if cached and cached[0]:
                pix=QPixmap();pix.loadFromData(cached[0]);canvas.show_image(pix.toImage())
            self.messages[c].setText('Carregando prévia…');self.metadata[c].clear()
        self.refresh_thumbnails();self.sync_selection();self.apply_mode()
        if self.mode.currentIndex()==0:
            for c in range(2):self.load(c)

    def load(self,c):
        if not self.isVisible() or self.busy[c] or not self.desired[c] or self.loaded[c]==self.generation:return
        self.busy[c]=True
        job=DuplicatePreviewJob(self.desired[c],self.generation*2+c,1800)
        job.signals.details.connect(self.details_ready)
        self.jobs[c]=job;job.signals.ready.connect(self.ready);QThreadPool.globalInstance().start(job)

    def details_ready(self,token,text):
        if token//2==self.generation:self.metadata[token%2].setText(text)

    def ready(self,token,image):
        c=token%2;self.busy[c]=False
        if token//2!=self.generation:
            if self.mode.currentIndex()==0:self.load(c)
            return
        self.loaded[c]=self.generation
        if image.isNull():self.messages[c].setText('Prévia indisponível. Confira o arquivo na pasta.')
        else:self.canvases[c].show_image(image);self.messages[c].clear()

    def apply_mode(self,*args):
        has=bool(self.pairs);mode=self.mode.currentIndex()
        self.stack.setCurrentIndex(2 if not has else (1 if mode==1 else 0))
        for panel in self.panels:panel.setVisible(True)
        self.zoom_bar.hide()
        for control in (self.previous,self.counter,self.next,self.score):control.setVisible(has and mode==0)
        self.thumbnails.hide();self.page_controls.setVisible(has and mode==1)
        for c,button in enumerate(self.folder_buttons):
            button.setVisible(has and mode==0 and (c==0 or os.path.dirname(self.pairs[self.index][0])!=os.path.dirname(self.pairs[self.index][1])))
        if has and mode==0:
            for c in range(2):
                self.load(c)

    def refresh_thumbnails(self):
        page=self.index//self.PAGE_PAIRS
        if self.gallery_page==page:return
        self.gallery_page=page;self.gallery.blockSignals(True);self.gallery.clear();self.thumbnails.clear()
        start=page*self.PAGE_PAIRS;end=min(len(self.pairs),start+self.PAGE_PAIRS)
        for i in range(start,end):
            for c,path in enumerate(self.pairs[i][:2]):
                cached=self.owner.db.execute('SELECT thumb FROM signatures WHERE path=?',(path,)).fetchone()
                pix=QPixmap()
                if cached and cached[0]:pix.loadFromData(cached[0])
                for target in (self.gallery,self.thumbnails):
                    text=f'Par {i+1} • {c+1}ª' + ('\n'+os.path.basename(path) if target is self.gallery else '')
                    item=QListWidgetItem(QIcon(pix),text)
                    item.setData(Qt.UserRole,(i,c,path));item.setToolTip(path)
                    if target is self.gallery:item.setFlags(item.flags()|Qt.ItemIsUserCheckable);item.setCheckState(Qt.Unchecked)
                    target.addItem(item)
        self.gallery.blockSignals(False)
        self.page_info.setText(f'Pares {start+1}–{end} de {len(self.pairs)}')
        self.page_back.setEnabled(page>0);self.page_forward.setEnabled(end<len(self.pairs))

    def sync_selection(self):
        selected=self.owner.column_selections.get(self.owner.run_id,set())
        enabled=not self.owner.running() and not self.owner.external_busy and not getattr(self.owner,'file_operations_busy',False)
        for c,key in enumerate(self.path_keys):
            check=self.choices[c];check.blockSignals(True);check.setChecked(key in selected);check.blockSignals(False)
            check.setEnabled(enabled and os.path.isfile(key[1]))
        self.gallery.blockSignals(True)
        for i in range(self.gallery.count()):
            item=self.gallery.item(i);_,c,path=item.data(Qt.UserRole)
            item.setCheckState(Qt.Checked if (c,path) in selected else Qt.Unchecked)
            flags=item.flags()
            item.setFlags(flags|Qt.ItemIsUserCheckable if enabled and os.path.isfile(path) else flags & ~Qt.ItemIsUserCheckable)
        self.gallery.blockSignals(False)

    def mark(self,c,marked):
        if c<len(self.path_keys):self.owner.toggle_selection(self.path_keys[c][1],marked,c)

    def gallery_mark(self,item):
        _,c,path=item.data(Qt.UserRole);self.owner.toggle_selection(path,item.checkState()==Qt.Checked,c)

    def activate_thumbnail(self,item):
        i,c,_=item.data(Qt.UserRole);self.focus=c;self.mode.setCurrentIndex(0);self.go(i)

    def active_canvases(self):
        return self.canvases

    def zoom(self,factor):
        for canvas in self.active_canvases():canvas.zoom(factor)

    def zoom_at(self,factor,image_point,viewport_point):
        if self.sender() in self.canvases:self.focus=self.canvases.index(self.sender())
        canvases=self.active_canvases()
        for canvas in canvases:canvas.zoom_at(factor,image_point,viewport_point)

    def fit(self):
        for canvas in self.active_canvases():canvas.fit()

    def open_folder(self,c):
        if not self.pairs:return
        paths=self.pairs[self.index][:2]
        same=os.path.normcase(os.path.dirname(paths[0]))==os.path.normcase(os.path.dirname(paths[1]))
        reveal_files_in_file_manager(paths if same else [paths[c]])

    def open_comparison(self):
        if self.pairs:self.owner.compare_photos(self.pairs[self.index][:2])

    def open_image_folder(self,index,column):
        if 0<=index<len(self.pairs):
            reveal_files_in_file_manager([self.pairs[index][column]])

    def open_item_folder(self,item):
        index,column,_=item.data(Qt.UserRole)
        self.open_image_folder(index,column)

    def item_menu(self,view,point):
        item=view.itemAt(point)
        if item is None:return
        index,column,_=item.data(Qt.UserRole)
        self.photo_menu(index,column,view.viewport().mapToGlobal(point))

    def build_photo_menu(self,index,column):
        menu=QMenu(self)
        if not 0<=index<len(self.pairs):return menu
        path=self.pairs[index][column]
        action=menu.addAction('Abrir na pasta')
        action.triggered.connect(lambda:self.open_image_folder(index,column))
        action=menu.addAction('Ver na comparação')
        action.triggered.connect(lambda:self.show_photo(index,column))
        action=menu.addAction('Copiar caminho do arquivo')
        action.triggered.connect(lambda:QApplication.clipboard().setText(path))
        menu.addSeparator()
        marked=(column,path) in self.owner.column_selections.get(self.owner.run_id,set())
        action=menu.addAction('Desmarcar para a Lixeira' if marked else 'Selecionar para a Lixeira')
        action.setEnabled(os.path.isfile(path) and not self.owner.running() and not self.owner.external_busy and not getattr(self.owner,'file_operations_busy',False))
        action.triggered.connect(lambda:self.owner.toggle_selection(path,not marked,column))
        return menu

    def photo_menu(self,index,column,position):
        menu=self.build_photo_menu(index,column)
        menu.exec(position);menu.deleteLater()

    def show_photo(self,index,column):
        self.focus=column;self.mode.setCurrentIndex(0);self.go(index)
