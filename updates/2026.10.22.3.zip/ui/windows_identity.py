"""Explicit native Windows icons for source launches and auxiliary windows."""
import sys
from pathlib import Path
from functools import lru_cache
from core.app_profile import current_profile

@lru_cache(maxsize=4)
def _handle(path,size):
    import ctypes
    from ctypes import wintypes
    load=ctypes.windll.user32.LoadImageW
    load.argtypes=[wintypes.HINSTANCE,wintypes.LPCWSTR,wintypes.UINT,ctypes.c_int,ctypes.c_int,wintypes.UINT]
    load.restype=wintypes.HANDLE
    handle=load(None,path,1,size,size,0x10)
    if not handle:raise ctypes.WinError()
    return handle


def apply_native_icon(hwnd,profile=None):
    if sys.platform!='win32':return
    import ctypes
    from ctypes import wintypes
    key=profile or current_profile().key
    path=Path(__file__).resolve().parent.parent/'logo'/('AcervoPessoal.ico' if key=='pessoal' else 'AcervoEmFoco.ico')
    send=ctypes.windll.user32.SendMessageW
    send.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM];send.restype=ctypes.c_ssize_t
    small,big=_handle(str(path),16),_handle(str(path),32)
    send(hwnd,0x80,0,small)
    send(hwnd,0x80,1,big)
    # Windows may fall back to the window class icon when minimizing.
    # Keep these handles alive in _handle's cache for the process lifetime.
    user32=ctypes.windll.user32
    set_class=user32.SetClassLongPtrW if ctypes.sizeof(ctypes.c_void_p)==8 else user32.SetClassLongW
    set_class.argtypes=[wintypes.HWND,ctypes.c_int,ctypes.c_ssize_t]
    set_class.restype=ctypes.c_size_t
    set_class(hwnd,-14,big)   # GCLP_HICON
    set_class(hwnd,-34,small) # GCLP_HICONSM


def install_native_icons(app):
    if sys.platform!='win32':return
    from PySide6.QtCore import QObject,QEvent,QTimer
    from PySide6.QtWidgets import QWidget
    from shiboken6 import isValid
    import weakref
    class IconFilter(QObject):
        def restore(self,ref):
            obj=ref()
            if obj is None or not isValid(obj):return
            try:apply_native_icon(int(obj.winId()))
            except OSError:
                import logging
                logging.exception('Não foi possível aplicar o ícone nativo da janela')

        def eventFilter(self,obj,event):
            if (event.type() in (QEvent.Show,QEvent.WindowStateChange,QEvent.WinIdChange)
                    and isinstance(obj,QWidget) and obj.isWindow()):
                # Run after Qt has finished changing the native window state.
                ref=weakref.ref(obj)
                QTimer.singleShot(0,lambda:self.restore(ref))
            return False
    app.native_icon_filter=IconFilter(app);app.installEventFilter(app.native_icon_filter)
