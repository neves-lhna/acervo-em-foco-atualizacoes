"""Bounded status text that never resizes the results area on progress updates."""
from PySide6.QtCore import Qt, QEvent
from PySide6.QtWidgets import QLabel, QSizePolicy


class StableStatusLabel(QLabel):
    def __init__(self, lines=3, parent=None):
        super().__init__(parent)
        self.line_count=lines
        self.full_text=''
        self.setTextFormat(Qt.PlainText)
        self.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.setWordWrap(False)
        self.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
        self.update_height()

    def update_height(self):
        self.setFixedHeight(self.fontMetrics().lineSpacing()*self.line_count+4)

    def setText(self,text):
        self.full_text=text
        self.setToolTip(text)
        self.render_text()

    def render_text(self):
        lines=self.full_text.splitlines()
        if len(lines)>self.line_count:
            # Keep the summary visible; full per-file details remain in the tooltip.
            lines=lines[:self.line_count-1]+[f'… (+{len(lines)-self.line_count} linhas) '+lines[-1]]
        width=max(1,self.contentsRect().width())
        super().setText('\n'.join(self.fontMetrics().elidedText(line,Qt.ElideMiddle,width) for line in lines))

    def resizeEvent(self,event):
        super().resizeEvent(event)
        self.render_text()

    def changeEvent(self,event):
        super().changeEvent(event)
        if event.type() in (QEvent.FontChange,QEvent.ApplicationFontChange):
            self.update_height();self.render_text()
