"""Notification drawer anchored to the bell, within the main window."""
from PySide6.QtCore import Qt, QEvent, QPoint
from PySide6.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget, QListWidgetItem, QAbstractItemView


class NotificationsPanel(QFrame):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.setObjectName('NotificationsPanel')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        heading = QHBoxLayout()
        heading.addWidget(QLabel('Notificações'))
        heading.addStretch()
        close = QPushButton('X'); close.setAccessibleName('Fechar notificações')
        close.setObjectName('CloseNotifications'); close.setToolTip('Fechar notificações')
        close.setStyleSheet('QPushButton#CloseNotifications { padding: 0; font-size: 16px; font-weight: bold; }')
        close.setFixedSize(32, 32); close.clicked.connect(self.hide); heading.addWidget(close)
        layout.addLayout(heading)
        self.items = QListWidget()
        self.items.setWordWrap(True)
        self.items.setSelectionMode(QAbstractItemView.ExtendedSelection)
        layout.addWidget(self.items)
        actions = QHBoxLayout()
        self.read = QPushButton('Marcar selecionadas como lidas')
        self.delete = QPushButton('Excluir as lidas')
        actions.addWidget(self.read); actions.addWidget(self.delete)
        layout.addLayout(actions)
        self.read.clicked.connect(self.mark_read)
        self.delete.clicked.connect(self.delete_read)
        self.items.itemSelectionChanged.connect(self.update_buttons)
        main.installEventFilter(self)
        self.hide()

    def eventFilter(self, obj, event):
        if obj is self.main and event.type() == QEvent.Resize:
            self.reposition()
        return False

    def reposition(self):
        point = self.main.notification_button.mapTo(self.main, QPoint(0, self.main.notification_button.height()+8))
        width = min(700, max(1, self.main.width()-24))
        height = min(460, max(1, self.main.height()-point.y()-16))
        self.setGeometry(max(12, self.main.width()-width-16), point.y(), width, height)

    def refresh(self):
        selected = {item.data(Qt.UserRole)[0] for item in self.items.selectedItems() if item.data(Qt.UserRole)}
        scroll = self.items.verticalScrollBar().value()
        self.items.clear()
        for entry in reversed(self.main.notifications):
            read = any(entry is old for old in self.main._read_notifications)
            self.add_entry(('session', id(entry)), entry, read, entry[0]+' — '+entry[1], selected)
        if self.main.authorities_tab is not None:
            for key, name, count, stamp, read in self.main.authorities_tab.history.notification_entries():
                self.add_entry(('people', key), key, bool(read), f'{stamp} — {name}: {count} nova(s) foto(s) encontrada(s).', selected)
        if not self.items.count():
            item = QListWidgetItem('Nenhuma notificação.'); item.setFlags(Qt.NoItemFlags); self.items.addItem(item)
        self.items.verticalScrollBar().setValue(scroll)
        self.update_buttons()

    def add_entry(self, key, source, read, text, selected):
        item = QListWidgetItem(('Lida · ' if read else 'Nova · ')+text)
        item.setData(Qt.UserRole, (key, source, read))
        font = item.font(); font.setBold(not read); item.setFont(font)
        self.items.addItem(item); item.setSelected(key in selected)

    def update_buttons(self):
        self.read.setEnabled(any(item.data(Qt.UserRole) and not item.data(Qt.UserRole)[2] for item in self.items.selectedItems()))
        self.delete.setEnabled(any(self.items.item(i).data(Qt.UserRole) and self.items.item(i).data(Qt.UserRole)[2] for i in range(self.items.count())))

    def mark_read(self):
        people = []
        for item in self.items.selectedItems():
            data = item.data(Qt.UserRole)
            if not data or data[2]: continue
            key, source, _ = data
            if key[0] == 'people': people.append(source)
            else:
                # Resolve by identity: Qt may copy Python tuples stored in item data.
                self.main._read_notifications.extend(entry for entry in self.main.notifications if id(entry)==key[1])
        if people:self.main.authorities_tab.history.mark_notifications_read(people)
        self.main._update_notification_bell()

    def delete_read(self):
        self.main.notifications = [entry for entry in self.main.notifications if not any(entry is old for old in self.main._read_notifications)]
        self.main._read_notifications.clear()
        if self.main.authorities_tab is not None:self.main.authorities_tab.history.delete_read_notifications()
        self.main._update_notification_bell()
