"""Persistent extension review, separate from decoding failures and progress."""
import os
from core import database as sqlite3
import hashlib
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
                              QTreeWidget,QTreeWidgetItem,QMessageBox,QProgressBar)
from core.image_loader import RAW_EXTENSIONS, standard_image_signature
from core.jpeg_copy import copy_mislabeled_jpeg
from core.utils_os import reveal_in_file_manager
from core.file_errors import file_error_message


class ExtensionScan(QThread):
    found = Signal(str)
    progress = Signal(int,int)
    issue = Signal(str)

    def __init__(self,history,cache,parent=None):
        super().__init__(parent);self.history=history;self.cache=cache

    def run(self):
        try:
            roots,coverage=self.history.records()
            folders={os.path.normcase(os.path.abspath(row[2])):row[2] for row in coverage}
            for row in roots:folders.setdefault(os.path.normcase(os.path.abspath(row[1])),row[1])
            for path in self.cache.metadata_index():
                folder=os.path.dirname(path);folders.setdefault(os.path.normcase(os.path.abspath(folder)),folder)
            for index,folder in enumerate(folders.values(),1):
                if self.isInterruptionRequested():break
                try:
                    with os.scandir(folder) as entries:
                        for entry in entries:
                            if self.isInterruptionRequested():break
                            if Path(entry.name).suffix.lower() not in RAW_EXTENSIONS:continue
                            try:
                                if entry.is_file(follow_symlinks=False) and standard_image_signature(entry.path)=='JPEG':
                                    self.found.emit(os.path.abspath(entry.path))
                            except OSError as exc:self.issue.emit(file_error_message(exc))
                except OSError as exc:self.issue.emit(file_error_message(exc))
                self.progress.emit(index,len(folders))
        except Exception as exc:self.issue.emit(file_error_message(exc))


class ExtensionReview(QDialog):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner;self.main=owner.window();self.worker=None;self.groups={};self.rows={}
        self.setWindowTitle('Revisar extensões — arquivos legíveis');self.resize(1000,620)
        self.setWindowFlag(Qt.WindowMaximizeButtonHint,True)
        directory=Path(self.main.face_history.path).parent
        self.db=sqlite3.connect(str(directory/'extension_review.db'))
        self.db.execute('CREATE TABLE IF NOT EXISTS review(path TEXT PRIMARY KEY,copy TEXT NOT NULL DEFAULT \'\',state TEXT NOT NULL DEFAULT \'Revisar extensão\')')
        layout=QVBoxLayout(self)
        note=QLabel('Pastas com arquivos JPEG usando extensão RAW. Esta revisão é independente das falhas e inclui pastas concluídas ou ocultas na tabela. As fotos originais são preservadas.');note.setWordWrap(True);layout.addWidget(note)
        self.tree=QTreeWidget();self.tree.setHeaderLabels(['Pasta / arquivo','Situação','Cópia JPG'])
        self.tree.setColumnWidth(0,480);self.tree.setColumnWidth(1,230);layout.addWidget(self.tree,1)
        self.tree.itemSelectionChanged.connect(self.controls)
        actions=QHBoxLayout();layout.addLayout(actions)
        self.scan_btn=QPushButton('Examinar pastas registradas');self.scan_btn.clicked.connect(self.scan)
        self.stop_btn=QPushButton('Parar revisão');self.stop_btn.clicked.connect(self.stop)
        self.copy_btn=QPushButton('Criar cópia JPG');self.copy_btn.clicked.connect(self.copy_selected)
        self.open_btn=QPushButton('Abrir na pasta');self.open_btn.clicked.connect(self.open_selected)
        self.trash_btn=QPushButton('Enviar original à Lixeira');self.trash_btn.clicked.connect(self.trash_selected)
        for button in (self.scan_btn,self.stop_btn,self.copy_btn,self.open_btn,self.trash_btn):actions.addWidget(button)
        self.progress=QProgressBar();self.progress.hide();layout.addWidget(self.progress)
        self.status=QLabel('Clique em Examinar pastas registradas para localizar os arquivos, mesmo sem falhas atuais.');self.status.setWordWrap(True);layout.addWidget(self.status)
        for row in self.db.execute('SELECT path,copy,state FROM review ORDER BY path'):self.add_row(*row)
        self.controls()

    def running(self):return bool(self.worker and self.worker.isRunning())
    def stop(self):
        if self.running():self.worker.requestInterruption()
    def closeEvent(self,event):
        if self.running():self.stop();event.ignore();return
        super().closeEvent(event)
    def selected(self):
        item=self.tree.currentItem();return item.data(0,Qt.UserRole) if item else None
    def controls(self):
        path=self.selected();busy=self.running()
        self.scan_btn.setEnabled(not busy);self.stop_btn.setEnabled(busy)
        self.copy_btn.setEnabled(bool(path) and not busy)
        self.open_btn.setEnabled(bool(path))
        row=self.db.execute('SELECT copy,state FROM review WHERE path=?',(path,)).fetchone() if path else None
        self.trash_btn.setEnabled(bool(row and row[0] and row[1]!='Original enviado à Lixeira') and not busy)

    def add_row(self,path,copy='',state='Revisar extensão'):
        folder=os.path.dirname(path)
        if folder not in self.groups:
            group=QTreeWidgetItem([folder]);self.tree.addTopLevelItem(group);group.setExpanded(True);self.groups[folder]=group
        item=self.rows.get(path)
        if item is None:
            item=QTreeWidgetItem(self.groups[folder]);item.setData(0,Qt.UserRole,path);item.setToolTip(0,path);self.rows[path]=item
        item.setText(0,os.path.basename(path));item.setText(1,state);item.setText(2,os.path.basename(copy));item.setToolTip(2,copy)

    def found(self,path):
        with self.db:self.db.execute('INSERT OR IGNORE INTO review(path) VALUES(?)',(path,))
        row=self.db.execute('SELECT copy,state FROM review WHERE path=?',(path,)).fetchone()
        self.add_row(path,*row)

    def scan(self):
        if self.running():return
        self.errors=0;self.worker=ExtensionScan(self.main.history,self.main.cache,self)
        self.worker.found.connect(self.found);self.worker.issue.connect(self.issue)
        self.worker.progress.connect(self.update_progress);self.worker.finished.connect(self.finished_scan)
        self.progress.setRange(0,0);self.progress.show();self.status.setText('Conferindo assinaturas dos arquivos nas pastas registradas…')
        self.worker.start();self.controls()
    def issue(self,message):
        self.errors+=1;self.status.setToolTip(message)
    def update_progress(self,done,total):
        self.progress.setRange(0,max(1,total));self.progress.setValue(done)
        self.status.setText(f'{done} de {total} pastas verificadas. {len(self.rows)} arquivos no catálogo de revisão. Acessos não concluídos: {self.errors}.')
    def finished_scan(self):
        prefix='Revisão interrompida' if self.worker.isInterruptionRequested() else 'Revisão concluída'
        self.status.setText(f'{prefix}. {len(self.groups)} pastas e {len(self.rows)} arquivos no catálogo salvo. Acessos não concluídos: {self.errors}.')
        self.controls()
    def open_selected(self):
        if self.selected():reveal_in_file_manager(self.selected())
    def can_change_files(self):
        if self.main._busy() or self.main._cache_running():
            QMessageBox.information(self,'Análise em andamento','Aguarde a análise terminar antes de copiar ou excluir.');return False
        return True
    def copy_selected(self):
        path=self.selected()
        if not path or not self.can_change_files():return
        try:
            target=copy_mislabeled_jpeg(path)
            with self.db:self.db.execute('UPDATE review SET copy=?,state=? WHERE path=?',(target,'Cópia JPG criada; original preservado',path))
            self.add_row(path,target,'Cópia JPG criada; original preservado');self.controls()
        except Exception as exc:QMessageBox.warning(self,'Cópia não criada',file_error_message(exc))
    def trash_selected(self):
        path=self.selected()
        if not path or not self.can_change_files():return
        target=self.db.execute('SELECT copy FROM review WHERE path=?',(path,)).fetchone()[0]
        try:
            def digest(name):
                with open(name,'rb') as stream:return hashlib.file_digest(stream,'sha256').digest()
            if not target or digest(path)!=digest(target):raise ValueError('A cópia JPG não está disponível ou difere do original. Exclusão bloqueada.')
            box=QMessageBox(self);box.setWindowTitle('Preservar JPG e excluir original')
            box.setText(f'Enviar {os.path.basename(path)} para a Lixeira? A cópia JPG idêntica será preservada.')
            yes=box.addButton('Enviar original à Lixeira',QMessageBox.AcceptRole);box.addButton('Cancelar',QMessageBox.RejectRole);box.exec()
            if box.clickedButton()!=yes:return
            if digest(path)!=digest(target):raise ValueError('Os arquivos mudaram; confira novamente.')
            from send2trash import send2trash
            rid=self.main.deletion_history.begin(path,os.stat(path).st_size,None)
            try:send2trash(path)
            except Exception as exc:self.main.deletion_history.finish(rid,str(exc));raise
            self.main.deletion_history.finish(rid)
            with self.db:self.db.execute('UPDATE review SET state=? WHERE path=?',('Original enviado à Lixeira',path))
            self.add_row(path,target,'Original enviado à Lixeira');self.controls()
        except Exception as exc:QMessageBox.warning(self,'Original preservado',file_error_message(exc))
