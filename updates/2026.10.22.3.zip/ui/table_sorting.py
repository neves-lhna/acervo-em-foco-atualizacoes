import re
import unicodedata
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QTreeWidgetItem

SORT_ROLE=Qt.UserRole+20

def text_key(value):
    text=''.join(c for c in unicodedata.normalize('NFKD',str(value).casefold()) if not unicodedata.combining(c))
    return tuple((1,int(part)) if part.isdigit() else (0,part) for part in re.split(r'(\d+)',text))

class SortableItem(QTreeWidgetItem):
    def __lt__(self,other):
        column=self.treeWidget().sortColumn()
        def key(item):
            value=item.data(column,SORT_ROLE)
            if value is None:return (2,text_key(item.text(column)))
            if isinstance(value,(int,float)):return (0,value)
            return (1,text_key(value))
        return key(self)<key(other)

def enable_header_sort(tree,callback=None):
    header=tree.header();header.setSectionsClickable(True)
    tree._sort_column=None;tree._sort_order=Qt.AscendingOrder
    def clicked(column):
        order=Qt.DescendingOrder if tree._sort_column==column and tree._sort_order==Qt.AscendingOrder else Qt.AscendingOrder
        tree._sort_column=column;tree._sort_order=order
        header.setSortIndicatorShown(True);header.setSortIndicator(column,order)
        if callback:callback(column,order)
        else:
            tree.setSortingEnabled(True);tree.sortItems(column,order)
    header.sectionClicked.connect(clicked)
    header.setToolTip('Clique para ordenar em ordem crescente; clique novamente para inverter.')
