"""Explorer-style views over the same photo selection and cached thumbnails."""
import os
from datetime import datetime
from PySide6.QtCore import Qt, QSize, QSettings
from PySide6.QtGui import QActionGroup
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QLabel, QPushButton, QMenu,
                              QListView, QTreeWidget, QTreeWidgetItem, QHeaderView)
from core.app_profile import current_profile
from ui.photo_viewer import show_photo


class PhotoDisplay:
    MODES = ('Ícones extra grandes', 'Ícones grandes', 'Ícones médios', 'Ícones pequenos',
             'Lista', 'Detalhes', 'Blocos', 'Conteúdo')

    def __init__(self, owner):
        self.owner = owner
        self.mode = 'Ícones grandes'
        self.settings = QSettings('AcervoEmFoco', current_profile().settings_name)
        self.button = QPushButton('Exibir')
        self.menu = QMenu(self.button);self.button.setMenu(self.menu)
        group = QActionGroup(self.menu);group.setExclusive(True)
        self.actions = {}
        for mode in self.MODES:
            action = self.menu.addAction(mode);action.setCheckable(True);group.addAction(action)
            action.triggered.connect(lambda checked=False, name=mode: self.apply(name))
            self.actions[mode] = action
        self.menu.addSeparator()
        self.details_action = self.menu.addAction('Painel de detalhes');self.details_action.setCheckable(True)
        self.preview_action = self.menu.addAction('Painel de visualização');self.preview_action.setCheckable(True)
        self.details_action.triggered.connect(lambda checked:self.toggle_panel('details', checked))
        self.preview_action.triggered.connect(lambda checked:self.toggle_panel('preview', checked))
        self.container = QWidget()
        layout = QHBoxLayout(self.container);layout.setContentsMargins(0,0,0,0)
        self.replace_widget(owner.layout(), owner.photos, self.container)
        layout.addWidget(owner.photos, 1)
        self.table = QTreeWidget();self.table.setRootIsDecorated(False)
        self.table.setHeaderLabels(['Nome', 'Tipo', 'Tamanho', 'Similaridade', 'Modificado em', 'Pasta'])
        self.table.header().setSectionResizeMode(QHeaderView.Interactive)
        self.table.setColumnWidth(0,260);self.table.setSortingEnabled(True)
        self.table.itemChanged.connect(self.table_checked)
        self.table.currentItemChanged.connect(lambda item, previous:self.table_current(item))
        self.table.itemDoubleClicked.connect(lambda item,column:show_photo(item.data(0,Qt.UserRole),owner,[self.table.topLevelItem(i).data(0,Qt.UserRole) for i in range(self.table.topLevelItemCount())]))
        layout.addWidget(self.table,1)
        self.panel = QLabel('Selecione uma foto.');self.panel.setWordWrap(True)
        self.panel.setAlignment(Qt.AlignTop|Qt.AlignHCenter);self.panel.setFixedWidth(240)
        self.panel.hide();layout.addWidget(self.panel)
        owner.photos.currentItemChanged.connect(lambda item,previous:self.update_panel())
        owner.photos.itemDoubleClicked.connect(lambda item:show_photo(item.data(Qt.UserRole),owner,[row[0] for row in owner.rows]))
        self.apply(self.settings.value('authorities/view', 'Ícones grandes'))

    @classmethod
    def replace_widget(cls, layout, old, new):
        for index in range(layout.count()):
            item = layout.itemAt(index)
            if item.widget() is old:
                layout.removeWidget(old);layout.insertWidget(index,new,1);return True
            if item.layout() and cls.replace_widget(item.layout(),old,new):return True
        return False

    def apply(self, mode):
        self.mode = mode if mode in self.MODES else 'Ícones grandes'
        self.actions[self.mode].setChecked(True)
        self.settings.setValue('authorities/view', self.mode)
        photos = self.owner.photos
        grid = self.mode.startswith('Ícones') or self.mode == 'Blocos'
        sizes = {'Ícones extra grandes':256, 'Ícones grandes':160, 'Ícones médios':96,
                 'Ícones pequenos':32, 'Lista':24, 'Blocos':96, 'Conteúdo':180, 'Detalhes':24}
        size = sizes[self.mode]
        photos.setViewMode(QListView.IconMode if grid else QListView.ListMode)
        photos.setFlow(QListView.LeftToRight if grid else QListView.TopToBottom)
        photos.setWrapping(grid);photos.setResizeMode(QListView.Adjust)
        photos.setMovement(QListView.Static);photos.setWordWrap(True)
        photos.setIconSize(QSize(size,size));photos.setGridSize(QSize())
        photos.blockSignals(True)
        rows = {row[0]:row for row in self.owner.rows}
        for index in range(photos.count()):
            item = photos.item(index);path = item.data(Qt.UserRole);row = rows[path]
            text = os.path.basename(path)
            if self.mode in ('Blocos','Conteúdo'):
                text += f'\nSimilaridade: {row[1]:.0%} · {row[4]/1024/1024:.1f} MB'
            if self.mode == 'Conteúdo':text += '\n' + os.path.dirname(path)
            item.setText(text)
            item.setSizeHint(QSize(max(size+36,150),size+65) if grid else QSize(380,34 if self.mode=='Lista' else 200))
        photos.blockSignals(False)
        photos.setVisible(self.mode != 'Detalhes');self.table.setVisible(self.mode == 'Detalhes')
        self.rebuild_table();self.update_panel()

    def rebuild_table(self):
        self.table.blockSignals(True);self.table.setSortingEnabled(False);self.table.clear()
        self.table_items = {}
        for path,score,pose,mtime,size,preview in self.owner.rows:
            date = datetime.fromtimestamp(mtime/1e9).strftime('%d/%m/%Y %H:%M') if mtime else ''
            item = QTreeWidgetItem([os.path.basename(path),os.path.splitext(path)[1].upper().lstrip('.'),
                                   f'{size/1024/1024:.1f} MB',f'{score:.0%}',date,os.path.dirname(path)])
            item.setData(0,Qt.UserRole,path);item.setToolTip(0,path)
            item.setFlags(item.flags()|Qt.ItemIsUserCheckable)
            item.setCheckState(0,Qt.Checked if path in self.owner.selected else Qt.Unchecked)
            source = self.owner.items.get(path)
            if source:item.setIcon(0,source.icon())
            self.table.addTopLevelItem(item)
            self.table_items[path] = item
        self.table.setSortingEnabled(True);self.table.blockSignals(False)

    def table_checked(self,item,column):
        if column != 0:return
        source = self.owner.items.get(item.data(0,Qt.UserRole))
        if source:source.setCheckState(item.checkState(0))

    def table_current(self,item):
        if item:
            source = self.owner.items.get(item.data(0,Qt.UserRole))
            if source:self.owner.photos.setCurrentItem(source)
        self.update_panel()

    def toggle_panel(self,which,checked):
        if checked:
            (self.preview_action if which=='details' else self.details_action).setChecked(False)
        self.panel.setVisible(self.details_action.isChecked() or self.preview_action.isChecked())
        self.update_panel()

    def update_panel(self):
        item = self.owner.photos.currentItem()
        self.panel.clear()
        if not item:self.panel.setText('Selecione uma foto.');return
        path = item.data(Qt.UserRole)
        if self.preview_action.isChecked():
            if item.icon().isNull():self.panel.setText('Carregando prévia…')
            else:self.panel.setPixmap(item.icon().pixmap(QSize(232,300)))
            self.panel.setToolTip(os.path.basename(path))
        else:
            row = next((row for row in self.owner.rows if row[0]==path),None)
            if row:self.panel.setText(f'{os.path.basename(path)}\n\nSimilaridade: {row[1]:.0%}\n'
                                     f'Tamanho: {row[4]/1024/1024:.1f} MB\n\n{os.path.dirname(path)}')
