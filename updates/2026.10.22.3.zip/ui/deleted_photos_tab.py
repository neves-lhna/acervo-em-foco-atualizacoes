import os
from PySide6.QtCore import Qt,QTimer,QThread,Signal
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTreeWidget,QMessageBox
from ui.table_sorting import SortableItem,enable_header_sort
from core.deletion_history import DeletionHistory,recycle_entries,restore_entry,now


class HistoryRefreshWorker(QThread):
    loaded=Signal(object,object)
    failed=Signal(str)
    def __init__(self,path,parent=None):
        super().__init__(parent);self.path=path
    def run(self):
        history=None;com=None;entries=[]
        try:
            if os.name=='nt':
                import comtypes as com
                com.CoInitialize()
            history=DeletionHistory(self.path)
            entries=recycle_entries();history.refresh(entries)
            # Shell COM objects belong to this thread; only plain data crosses it.
            self.loaded.emit([e['key'] for e in entries],history.rows())
        except Exception as exc:
            from core.diagnostics import program_error
            program_error(str(exc),'Consulta da Lixeira');self.failed.emit(str(exc))
        finally:
            entries.clear()
            if history:history.db.close()
            if com:com.CoUninitialize()


class DeletedPhotosTab(QWidget):
    def __init__(self,history,parent=None):
        super().__init__(parent);self.history=history;self.entries={};self.pending=None;self.refresh_worker=None
        layout=QVBoxLayout(self)
        title=QLabel('Histórico de fotos excluídas');title.setObjectName('PageTitle');layout.addWidget(title)
        note=QLabel('Restaure as fotos que ainda estão na Lixeira. O histórico é salvo nos dados do usuário, fora da pasta do programa.');note.setWordWrap(True);layout.addWidget(note)
        self.table=QTreeWidget();self.table.setHeaderLabels(['Foto','Excluída pelo programa em','Situação','Restaurada em'])
        self.table.setColumnWidth(0,350);self.table.setColumnWidth(1,170);self.table.setColumnWidth(2,220)
        enable_header_sort(self.table);layout.addWidget(self.table,1)
        row=QHBoxLayout();self.refresh_button=QPushButton('Atualizar');self.restore_button=QPushButton('Restaurar foto selecionada')
        row.addWidget(self.refresh_button);row.addWidget(self.restore_button);row.addStretch();layout.addLayout(row)
        self.status=QLabel();self.status.setWordWrap(True);layout.addWidget(self.status)
        self.refresh_button.clicked.connect(self.refresh);self.restore_button.clicked.connect(self.restore)
        self.table.itemSelectionChanged.connect(self.controls)
        self.timer=QTimer(self);self.timer.setInterval(500);self.timer.timeout.connect(self.check_restore)
        self.controls()

    def refresh(self):
        if self.pending or self.refreshing():return
        self.status.setText('Consultando a Lixeira em segundo plano… Você pode continuar usando as outras abas.')
        self.refresh_worker=HistoryRefreshWorker(self.history.path,self)
        self.refresh_worker.loaded.connect(self.show_history)
        self.refresh_worker.failed.connect(self.refresh_failed)
        self.refresh_worker.finished.connect(self.controls)
        self.refresh_worker.start();self.controls()

    def refreshing(self):return bool(self.refresh_worker and self.refresh_worker.isRunning())

    def refresh_failed(self,error):
        self.entries={};self.status.setText('Não foi possível consultar a Lixeira: '+error)

    def show_history(self,keys,records):
        self.entries=set(keys)
        self.status.setText('Consulta concluída. Fotos não encontradas na Lixeira não podem ser restauradas por aqui.')
        selected=self.table.currentItem()
        selected_id=selected.data(0,Qt.UserRole)[0] if selected else None
        sorting=self.table.isSortingEnabled();self.table.setSortingEnabled(False);self.table.setUpdatesEnabled(False)
        self.table.clear()
        for record in records:
            rid,path,deleted,size,digest,state,key,missing,restored,error=record
            item=SortableItem([os.path.basename(path),deleted or 'Não registrada',state,restored or ''])
            item.setData(0,Qt.UserRole,record);item.setToolTip(0,path)
            item.setToolTip(2,error or ('Arquivo não encontrado na Lixeira; restauração indisponível.' if state=='Não encontrado na Lixeira' else state))
            self.table.addTopLevelItem(item)
            if rid==selected_id:self.table.setCurrentItem(item)
        self.table.setSortingEnabled(sorting);self.table.setUpdatesEnabled(True)
        self.controls()

    def controls(self):
        item=self.table.currentItem();record=item.data(0,Qt.UserRole) if item else None
        self.restore_button.setEnabled(bool(not self.pending and not self.refreshing() and record and record[5]=='Na Lixeira' and record[6] in self.entries))
        self.refresh_button.setEnabled(not self.pending and not self.refreshing())

    def restore(self):
        item=self.table.currentItem()
        if not item or self.pending:return
        rid,path,deleted,size,digest,state,key,*_=item.data(0,Qt.UserRole)
        if QMessageBox.question(self,'Restaurar foto',f'Restaurar {os.path.basename(path)} para a pasta original?',QMessageBox.Yes|QMessageBox.Cancel,QMessageBox.Cancel)!=QMessageBox.Yes:return
        try:
            entries={e['key']:e for e in recycle_entries()}
            if key not in entries:raise OSError('A foto não está mais disponível na Lixeira. A data da remoção definitiva é desconhecida.')
            restore_entry(entries[key],path)
            self.pending=(rid,path,size,0);self.timer.start();self.status.setText('Aguardando a restauração pelo Windows…');self.controls()
        except Exception as exc:
            from core.diagnostics import program_error
            program_error(str(exc),'Restauração');QMessageBox.warning(self,'Não foi possível restaurar',str(exc));self.refresh()

    def check_restore(self):
        rid,path,size,attempt=self.pending
        if os.path.isfile(path) and (size is None or os.path.getsize(path)==size):
            with self.history.db:self.history.db.execute("UPDATE deletions SET state='Restaurada',restored=? WHERE id=?",(now(),rid))
            self.timer.stop();self.pending=None;self.refresh();self.status.setText('Foto restaurada. Faça uma nova verificação da pasta para atualizar os resultados.');return
        if attempt>=60:
            self.timer.stop();self.pending=None;self.refresh();self.status.setText('A restauração ainda não foi confirmada. Confira a pasta e atualize o histórico.');return
        self.pending=(rid,path,size,attempt+1)
