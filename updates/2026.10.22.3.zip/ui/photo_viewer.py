"""Shared enlarged photo viewer; decoding stays off the UI thread."""
import os
from PySide6.QtCore import Qt, Signal, QThreadPool, QPoint
from PySide6.QtGui import QPixmap, QShortcut, QKeySequence
from PySide6.QtWidgets import (QLabel, QDialog, QVBoxLayout, QHBoxLayout, QWidget,
    QScrollArea, QPushButton, QCheckBox, QGraphicsView, QGraphicsScene)
from ui.image_folder_dialog import PreviewJob


class PhotoLabel(QLabel):
    clicked = Signal()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip('Clique para ampliar a imagem.')

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:self.clicked.emit()
        super().mouseReleaseEvent(event)


class PhotoCanvas(QGraphicsView):
    zoom_requested=Signal(float,object,object)
    def __init__(self):
        super().__init__()
        self.setScene(QGraphicsScene(self));self.setMinimumSize(300,300)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.item=None;self.fitted=True
        self.setTransformationAnchor(QGraphicsView.NoAnchor)

    def wheelEvent(self,event):
        if self.item and event.angleDelta().y():
            point=event.position().toPoint();scene_point=self.mapToScene(point)
            bounds=self.item.boundingRect()
            image_point=(scene_point.x()/bounds.width(),scene_point.y()/bounds.height())
            viewport_point=(point.x()/self.viewport().width(),point.y()/self.viewport().height())
            self.zoom_requested.emit(1.25 if event.angleDelta().y()>0 else .8,image_point,viewport_point)
            event.accept()
        else:super().wheelEvent(event)

    def zoom_at(self,factor,image_point,viewport_point):
        if not self.item:return
        bounds=self.item.boundingRect()
        target=bounds.topLeft();target.setX(image_point[0]*bounds.width());target.setY(image_point[1]*bounds.height())
        if not self.zoom(factor):return
        point=QPoint(round(viewport_point[0]*self.viewport().width()),round(viewport_point[1]*self.viewport().height()))
        delta=self.mapToScene(point)-target
        self.translate(delta.x(),delta.y())

    def fit(self):
        self.fitted=True
        if self.item:self.fitInView(self.item,Qt.KeepAspectRatio)

    def zoom(self, factor):
        if not self.item:return False
        bounds=self.item.boundingRect()
        minimum=min(max(1,self.viewport().width()-4)/bounds.width(),
                    max(1,self.viewport().height()-4)/bounds.height())
        if factor<1 and self.transform().m11()*factor<=minimum*1.001:
            self.fit()
            return False
        self.fitted=False;self.scale(factor,factor)
        return True

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if self.fitted:self.fit()

    def show_image(self,image):
        self.scene().clear()
        self.item=self.scene().addPixmap(QPixmap.fromImage(image))
        bounds=self.item.boundingRect()
        self.setSceneRect(bounds)
        self.fit()


class PhotoViewer(QDialog):
    def __init__(self, paths, parent=None, selection=None, changed=None, enabled=True, reason=None, review=False, gallery=None):
        super().__init__(parent)
        self.setWindowTitle('Comparar fotos duplicadas' if selection is not None else 'Visualizar imagem')
        self.setWindowFlag(Qt.WindowMaximizeButtonHint,True)
        area=self.screen().availableGeometry()
        self.resize(min(1400,int(area.width()*.9)),int(area.height()*.85))
        layout=QVBoxLayout(self)
        if reason:
            explanation=QLabel(reason);explanation.setTextFormat(Qt.PlainText);explanation.setWordWrap(True);layout.addWidget(explanation)
        scroll=QScrollArea();scroll.setWidgetResizable(True)
        body=QWidget();columns=QHBoxLayout(body);scroll.setWidget(body);layout.addWidget(scroll,1)
        self.gallery=list(dict.fromkeys(gallery or [])) if len(paths)==1 and selection is None else []
        if self.gallery and paths[0] not in self.gallery:self.gallery.insert(0,paths[0])
        self.position=self.gallery.index(paths[0]) if self.gallery else 0
        self.generation=0;self.loading=False;self.closed=False;self.names=[]
        self.finished.connect(self._closed)
        if self.gallery:
            self.previous=QPushButton('❮');self.previous.setFixedWidth(42)
            self.previous.setToolTip('Foto anterior (seta esquerda)');self.previous.setAccessibleName('Foto anterior')
            self.previous.clicked.connect(lambda:self.navigate(-1));columns.addWidget(self.previous)
        self.jobs=[];self.canvases=[];self.messages=[];self.choices=[]
        for index,path in enumerate(paths):
            panel=QWidget();col=QVBoxLayout(panel);columns.addWidget(panel,1)
            name=QLabel(os.path.basename(path));name.setTextFormat(Qt.PlainText);name.setWordWrap(True);col.addWidget(name);self.names.append(name)
            canvas=PhotoCanvas();self.canvases.append(canvas);col.addWidget(canvas,1)
            canvas.zoom_requested.connect(self.zoom_all)
            message=QLabel('Carregando imagem…');self.messages.append(message);col.addWidget(message)
            row=QHBoxLayout()
            row.addStretch()
            text_style='QPushButton { background: transparent; border: none; padding: 0; } '
            for title,action in [('−',lambda _,c=canvas:c.zoom(.8)),('+',lambda _,c=canvas:c.zoom(1.25))]:
                button=QPushButton(title);button.setFlat(True);button.setFixedSize(28,24)
                button.setStyleSheet(text_style+' QPushButton { font-size: 18px; }')
                button.setCursor(Qt.PointingHandCursor)
                button.setAccessibleName('Diminuir zoom' if title=='−' else 'Aumentar zoom')
                button.clicked.connect(action);row.addWidget(button)
            row.addStretch()
            col.addLayout(row)
            fit=QPushButton('Ajustar à janela');fit.setFlat(True);fit.setStyleSheet(text_style)
            fit.setCursor(Qt.PointingHandCursor);fit.clicked.connect(lambda _,c=canvas:c.fit())
            col.addWidget(fit,0,Qt.AlignHCenter)
            if selection is not None:
                check=QCheckBox('Selecionar para a Lixeira');check.setChecked(selection(path))
                check.setEnabled(enabled and os.path.isfile(path));self.choices.append(check)
                check.toggled.connect(lambda marked,p=path:changed(p,marked));col.addWidget(check)
            if not self.gallery:
                job=PreviewJob(path,index,2000);job.signals.ready.connect(self.ready)
                self.jobs.append(job);QThreadPool.globalInstance().start(job)
        if self.gallery:
            self.next=QPushButton('❯');self.next.setFixedWidth(42)
            self.next.setToolTip('Próxima foto (seta direita)');self.next.setAccessibleName('Próxima foto')
            self.next.clicked.connect(lambda:self.navigate(1));columns.addWidget(self.next)
            for key,step in [('Left',-1),('Right',1)]:
                shortcut=QShortcut(QKeySequence(key),self)
                shortcut.activated.connect(lambda step=step:self.navigate(step))
            self.navigate(0)
        actions=QHBoxLayout();actions.addStretch()
        if review:
            proceed=QPushButton('Continuar com as selecionadas');proceed.clicked.connect(self.accept);actions.addWidget(proceed)
        close=QPushButton('Cancelar' if review else 'Fechar');close.clicked.connect(self.reject);actions.addWidget(close)
        layout.addLayout(actions)

    def _closed(self,*args):
        self.closed=True

    def navigate(self,step):
        target=self.position+step
        if not 0<=target<len(self.gallery):return
        self.position=target;self.generation+=1
        self.previous.setEnabled(target>0);self.next.setEnabled(target<len(self.gallery)-1)
        path=self.gallery[target]
        self.names[0].setText(f'{os.path.basename(path)} — {target+1} / {len(self.gallery)}')
        canvas=self.canvases[0];canvas.item=None;canvas.scene().clear();canvas.resetTransform()
        self.messages[0].setText('Carregando imagem…')
        if not self.loading:self.load_current()

    def load_current(self):
        self.loading=True
        job=PreviewJob(self.gallery[self.position],self.generation,2000)
        job.signals.ready.connect(self.gallery_ready)
        self.jobs=[job];QThreadPool.globalInstance().start(job)

    def gallery_ready(self,token,image):
        self.loading=False
        if self.closed:return
        if token!=self.generation:
            self.load_current();return
        self.ready(0,image)

    def zoom_all(self,factor,image_point,viewport_point):
        for canvas in self.canvases:canvas.zoom_at(factor,image_point,viewport_point)

    def ready(self,index,image):
        self.messages[index].setText('Não foi possível abrir esta imagem.' if image.isNull() else '')
        if not image.isNull():self.canvases[index].show_image(image)


def show_photo(path,parent,paths=None):
    if path:
        dialog=PhotoViewer([path],parent,gallery=paths);dialog.exec();dialog.deleteLater()
