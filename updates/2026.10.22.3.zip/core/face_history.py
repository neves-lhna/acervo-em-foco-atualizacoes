"""Persistent reference portraits and their matching files, separate from embeddings."""
import hashlib
import os
from core import database as sqlite3
from datetime import datetime


class FaceHistory:
    def __init__(self, path):
        self.path = path
        self.db = sqlite3.connect(path, timeout=10)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS faces(
                id TEXT PRIMARY KEY, portrait BLOB, updated TEXT, folder TEXT, state TEXT);
            CREATE TABLE IF NOT EXISTS matches(
                face TEXT, path TEXT, score REAL, pose TEXT, mtime INTEGER, size INTEGER,
                preview BLOB, PRIMARY KEY(face,path));
        ''')

    def start(self, embedding, portrait, folder):
        key = hashlib.sha256(embedding.tobytes()).hexdigest()
        with self.db:
            self.db.execute('INSERT INTO faces VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET '
                            'portrait=excluded.portrait,updated=excluded.updated,folder=excluded.folder,state=excluded.state',
                            (key,portrait,datetime.now().isoformat(timespec='seconds'),folder,'Em busca'))
        return key

    def add(self, face, path, score, pose):
        try:
            st = os.stat(path)
        except OSError:
            return
        with self.db:
            self.db.execute('INSERT INTO matches VALUES(?,?,?,?,?,?,NULL) ON CONFLICT(face,path) '
                            'DO UPDATE SET score=excluded.score,pose=excluded.pose,mtime=excluded.mtime,'
                            'size=excluded.size,preview=CASE WHEN matches.mtime=excluded.mtime AND matches.size=excluded.size '
                            'THEN matches.preview ELSE NULL END',
                            (face,os.path.abspath(path),score,pose,st.st_mtime_ns,st.st_size))

    def finish(self, face, state):
        with self.db:
            self.db.execute('UPDATE faces SET state=?,updated=? WHERE id=?',
                            (state,datetime.now().isoformat(timespec='seconds'),face))

    def faces(self):
        return self.db.execute('SELECT f.id,f.portrait,f.updated,f.folder,f.state,count(m.path) '
                               'FROM faces f LEFT JOIN matches m ON m.face=f.id GROUP BY f.id ORDER BY f.updated DESC').fetchall()

    def results(self, face):
        return self.db.execute('SELECT path,score,pose,mtime,size,preview FROM matches WHERE face=? ORDER BY path',(face,)).fetchall()
