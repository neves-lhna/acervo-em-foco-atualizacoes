"""Stable launcher: dispatch to a verified version, or return to its predecessor."""
import os
from pathlib import Path
import sys


def _alive(pid):
    if not isinstance(pid,int) or pid<=0:return False
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.OpenProcess.restype=wintypes.HANDLE
        kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
        kernel.CloseHandle.argtypes=[wintypes.HANDLE]
        handle=kernel.OpenProcess(0x1000,False,pid)
        if not handle:return ctypes.get_last_error()==5
        try:
            code=wintypes.DWORD()
            return bool(kernel.GetExitCodeProcess(handle,ctypes.byref(code))) and code.value==259
        finally:kernel.CloseHandle(handle)
    try:os.kill(pid,0);return True
    except OSError:return False


def dispatch():
    from core.app_profile import current_profile
    if current_profile().key!='pessoal':return
    from core.signed_updates import read_state,write_state,verify_installed
    root=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[1]
    if os.environ.get('ACERVO_UPDATED_PROCESS')==str(os.getpid()):return
    if os.environ.get('ACERVO_INSTALL_ROOT') and Path(os.environ['ACERVO_INSTALL_ROOT']).resolve()!=root:
        installation=Path(os.environ['ACERVO_INSTALL_ROOT']).resolve()
        state=read_state(installation)
        if state['pending'] and '--maintenance' not in sys.argv and (
                not _alive(state.get('attempt_pid')) or state.get('attempt_pid')==os.getppid()):
            state.update(attempted=True,attempt_pid=os.getpid());write_state(installation,state)
        return
    state=read_state(root)
    if state['pending'] and state['attempted'] and not _alive(state.get('attempt_pid')):
        state.update(active=state['previous'],previous=None,pending=False,attempted=False)
        write_state(root,state);os.environ['ACERVO_UPDATE_ROLLBACK']='1'
    if not state['active']:return
    try:folder=verify_installed(root,state['active'])
    except Exception:
        state.update(active=state['previous'],previous=None,pending=False,attempted=False)
        write_state(root,state);os.environ['ACERVO_UPDATE_ROLLBACK']='1'
        if not state['active']:return
        folder=verify_installed(root,state['active'])
    # Maintenance remains accessible without treating it as a startup attempt.
    if state['pending'] and '--maintenance' not in sys.argv and not _alive(state.get('attempt_pid')):
        state.update(attempted=True,attempt_pid=os.getpid());write_state(root,state)
    from core.app_profile import current_profile
    env=dict(os.environ,ACERVO_INSTALL_ROOT=str(root),ACERVO_PROFILE=current_profile().key)
    # Avoid loading bytecode injected alongside otherwise signed source files.
    import uuid
    env['PYTHONPYCACHEPREFIX']=str(root/'.acervo-updates'/('runtime-cache-'+uuid.uuid4().hex))
    env['PYTHONDONTWRITEBYTECODE']='1'
    if getattr(sys,'frozen',False):
        import runpy
        os.environ.update(env)
        os.environ['ACERVO_UPDATED_PROCESS']=str(os.getpid())
        sys.dont_write_bytecode=True
        sys.pycache_prefix=env['PYTHONPYCACHEPREFIX']
        sys.path.insert(0,str(folder))
        import core
        core.__path__=[str(folder/'core')]
        for name in list(sys.modules):
            if name.startswith(('core.','ui.','workers.')) or name in ('ui','workers'):
                del sys.modules[name]
        runpy.run_path(str(folder/'main.py'),run_name='__main__')
        raise SystemExit(0)
    os.execve(sys.executable,[sys.executable,str(folder/'main.py'),*sys.argv[1:]],env)
