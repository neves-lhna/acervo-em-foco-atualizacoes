"""
core/embedding_cache.py
------------------------
Estratégia de indexação incremental.

Para uma galeria local grande (dezenas de milhares de fotos), recalcular
embeddings a cada busca seria proibitivo. A estratégia adotada aqui:

  1. Cache persistente em SQLite (arquivo único, sem servidor, nativo
     do Python) guardando, por arquivo de imagem:
        caminho_absoluto | mtime | tamanho | embeddings (BLOB de floats)
  2. Antes de rodar a inferência em uma imagem, verificamos se ela já
     está no cache E se mtime/tamanho não mudaram. Se sim, reutilizamos
     os embeddings salvos -> custo praticamente zero (apenas leitura).
  3. Se a imagem for nova ou tiver sido modificada, computamos os
     embeddings, atualizamos o cache e seguimos com a comparação.

Isso transforma buscas subsequentes na mesma pasta em operações quase
instantâneas (o gargalo passa a ser I/O de disco + comparação vetorial,
que é O(N) e muito rápida mesmo para dezenas de milhares de vetores
512D, já que é apenas uma multiplicação de matrizes).

Para bibliotecas muito grandes (milhões de fotos) o próximo passo
natural seria trocar a varredura linear por um índice ANN (ex.: FAISS,
HNSWlib), mas para o escopo de "galerias de fotos locais" (uso
pessoal, dezenas/centenas de milhares de arquivos) a busca linear com
NumPy vetorizado já roda em milissegundos por lote.
"""

from __future__ import annotations

import os
from core import database as sqlite3
import threading
from typing import List, Optional

import numpy as np

EMBEDDING_DIM = 512


class EmbeddingCache:
    def __init__(self, db_path: str):
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
        self._lock = threading.Lock()
        # check_same_thread=False: a conexão é acessada apenas dentro
        # do lock acima, então é seguro compartilhar entre chamadas
        # vindas da thread do worker.
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._init_schema()

    def _init_schema(self):
        with self._lock:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS faces (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT NOT NULL,
                    mtime REAL NOT NULL,
                    size INTEGER NOT NULL,
                    face_index INTEGER NOT NULL,
                    pose TEXT NOT NULL,
                    embedding BLOB NOT NULL,
                    UNIQUE(path, face_index)
                )
                """
            )
            self._conn.execute("CREATE TABLE IF NOT EXISTS scanned_images (path TEXT PRIMARY KEY, mtime REAL NOT NULL, size INTEGER NOT NULL)")
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_path ON faces(path)")
            # Windows file dialogs and pathlib use different slash conventions.
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_faces_slashes ON faces(replace(path, char(92), '/'))")
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_scanned_slashes ON scanned_images(replace(path, char(92), '/'))")
            self._conn.commit()

    @staticmethod
    def _path_key(path):
        return os.path.abspath(path).replace('\\', '/') if os.name == 'nt' else path

    def _stored_path(self, table, path):
        if os.name != 'nt':
            return path
        # table is an internal constant, never external input.
        row = self._conn.execute(
            f"SELECT path FROM {table} WHERE replace(path, char(92), '/') = ? ORDER BY rowid DESC LIMIT 1",
            (self._path_key(path),),
        ).fetchone()
        return row[0] if row else self._path_key(path)

    # ------------------------------------------------------------------
    def get_cached(self, path: str, mtime: float, size: int) -> Optional[List[np.ndarray]]:
        """Retorna a lista de embeddings já indexados para o arquivo,
        SE o cache ainda for válido (mesmo mtime/size). Caso contrário
        retorna None, sinalizando que é preciso reprocessar."""
        with self._lock:
            stored_path = self._stored_path('faces', path)
            rows = self._conn.execute(
                "SELECT mtime, size, embedding FROM faces WHERE path = ? ORDER BY face_index",
                (stored_path,),
            ).fetchall()

        if not rows:
            with self._lock:
                stored_path = self._stored_path('scanned_images', path)
                meta = self._conn.execute("SELECT mtime, size FROM scanned_images WHERE path = ?", (stored_path,)).fetchone()
            return [] if meta == (mtime, size) else None
        cached_mtime, cached_size, _ = rows[0]
        if cached_mtime != mtime or cached_size != size:
            return None  # arquivo mudou desde a última indexação

        return [np.frombuffer(r[2], dtype=np.float32) for r in rows]

    def store(self, path: str, mtime: float, size: int, embeddings: List[np.ndarray], poses: List[str]):
        path = self._path_key(path)
        with self._lock:
            if os.name == 'nt':
                self._conn.execute("DELETE FROM faces WHERE replace(path, char(92), '/') = ?", (path,))
                self._conn.execute("DELETE FROM scanned_images WHERE replace(path, char(92), '/') = ?", (path,))
            else:
                self._conn.execute("DELETE FROM faces WHERE path = ?", (path,))
            self._conn.executemany(
                "INSERT INTO faces (path, mtime, size, face_index, pose, embedding) VALUES (?,?,?,?,?,?)",
                [
                    (path, mtime, size, i, poses[i], emb.astype(np.float32).tobytes())
                    for i, emb in enumerate(embeddings)
                ],
            )
            self._conn.execute("INSERT OR REPLACE INTO scanned_images VALUES (?, ?, ?)", (path, mtime, size))
            self._conn.commit()

    def get_poses(self, path):
        with self._lock:
            path = self._stored_path('faces', path)
            return [r[0] for r in self._conn.execute("SELECT pose FROM faces WHERE path = ? ORDER BY face_index", (path,))]

    def metadata_index(self, cancelled=None, progress=None):
        """Stream signatures; cancellation also works while waiting for the cache lock."""
        cancelled = cancelled or (lambda: False)
        while not self._lock.acquire(timeout=0.1):
            if cancelled():raise InterruptedError('Leitura do cache interrompida')
        index = {};count = 0
        try:
            if cancelled():raise InterruptedError('Leitura do cache interrompida')
            self._conn.set_progress_handler(lambda: int(cancelled()),1000)
            # UNION sorts the entire result before returning its first row. Deduplicate
            # signatures in the index instead, allowing progress and cancellation.
            cursor=self._conn.execute(
                'SELECT path, mtime, size FROM scanned_images UNION ALL SELECT path, mtime, size FROM faces')
            try:
                while True:
                    if cancelled():raise InterruptedError('Leitura do cache interrompida')
                    rows=cursor.fetchmany(1000)
                    if not rows:break
                    for path,mtime,size in rows:
                        key=os.path.normcase(os.path.abspath(path))
                        index.setdefault(key,set()).add((mtime,size))
                    count+=len(rows)
                    if progress:progress(count)
            finally:cursor.close()
        except sqlite3.OperationalError:
            if cancelled():raise InterruptedError('Leitura do cache interrompida') from None
            raise
        finally:
            self._conn.set_progress_handler(None,0)
            self._lock.release()
        return index

    def inventory_revision(self, cancelled=lambda:False):
        while not self._lock.acquire(timeout=0.1):
            if cancelled():raise InterruptedError('Conferência interrompida')
        try:
            if cancelled():raise InterruptedError('Conferência interrompida')
            return self._conn.total_changes,self._conn.execute('PRAGMA data_version').fetchone()[0]
        finally:self._lock.release()

    def face_counts(self):
        with self._lock:rows=self._conn.execute('SELECT path,count(*) FROM faces GROUP BY path').fetchall()
        return {os.path.normcase(os.path.abspath(path)):count for path,count in rows}

    def close(self):
        with self._lock:
            self._conn.close()
