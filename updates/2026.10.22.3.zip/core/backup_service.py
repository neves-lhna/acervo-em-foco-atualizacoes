"""Encrypted offline backup and journaled restore. Caller holds application.lock."""
import base64
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import uuid
import zipfile

from core.database import key_for_database
from core.database_recovery import recover
from core.secure_database import connect_encrypted

MARKER = 'database-restore.json'
ACTIVE = 'database-security.json'
PENDING = 'database-security.pending.json'
DB_NAMES = {'authorities.db', 'deletions.db', 'duplicates.db', 'embeddings_cache.db',
            'extension_review.db', 'face_history.db', 'folder_history.db'}
REQUIRED = DB_NAMES - {'extension_review.db'}


def _write(path, data):
    with path.open('xb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())


def _names(root):
    names = sorted(p.name for p in root.glob('*.db'))
    if not REQUIRED.issubset(names) or not set(names).issubset(DB_NAMES):
        raise ValueError('Conjunto de bancos incompleto ou desconhecido.')
    return names


def _copy(source, target, total, progress, label):
    digest = hashlib.sha256(); done = 0
    while chunk := source.read(4*1024*1024):
        target.write(chunk); digest.update(chunk); done += len(chunk)
        progress(f'{label}: {done*100/max(total,1):.0f}%')
    if done != total:
        raise ValueError('O tamanho do arquivo mudou durante a operação.')
    return digest.hexdigest()


def export_backup(root, profile, destination, progress=lambda text: None):
    root, destination = Path(root).resolve(), Path(destination).resolve()
    if destination.exists() or destination.is_relative_to(root):
        raise ValueError('Escolha um arquivo novo fora da pasta dos bancos.')
    if (root/MARKER).exists() or (root/'database-activation.json').exists():
        raise ValueError('Há uma recuperação pendente. Reabra o aplicativo primeiro.')
    record = json.loads((root/ACTIVE).read_bytes())
    if record['profile'] != profile or record['state'] != 'encrypted':
        raise ValueError('O backup exige bancos criptografados desta edição.')
    names = _names(root)
    key = key_for_database(root/names[0])
    if key is None:
        raise ValueError('Proteção dos bancos indisponível.')
    for name in names:
        path = root/name
        if path.is_symlink() or path.is_junction():
            raise ValueError('Banco redirecionado não permitido.')
        progress('Conferindo banco: '+name)
        with closing(connect_encrypted(path, key)) as db:
            if db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0] != 0:
                raise ValueError('O banco ainda está em uso: '+name)
            if db.execute('PRAGMA quick_check').fetchall() != [('ok',)]:
                raise ValueError('O banco precisa de reparo antes do backup: '+name)
    if shutil.disk_usage(destination.parent).free < sum((root/n).stat().st_size for n in names)+64*1024**2:
        raise ValueError('Espaço insuficiente no destino.')
    temporary = destination.with_name('.'+destination.name+'.'+uuid.uuid4().hex+'.partial')
    report = dict(format=1, profile=profile, created=datetime.now(timezone.utc).isoformat(), files={})
    manifest = json.dumps(dict(record, databases=names)).encode('utf-8')
    try:
        with zipfile.ZipFile(temporary, 'x', compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
            for name in names:
                size = (root/name).stat().st_size
                with (root/name).open('rb') as source, archive.open(name, 'w', force_zip64=True) as output:
                    sha = _copy(source, output, size, progress, 'Copiando '+name)
                report['files'][name] = dict(size=size, sha256=sha)
            archive.writestr(ACTIVE, manifest)
            report['files'][ACTIVE] = dict(size=len(manifest), sha256=hashlib.sha256(manifest).hexdigest())
            archive.writestr('backup.json', json.dumps(report).encode())
        with temporary.open('r+b') as stream:
            os.fsync(stream.fileno())
        # Read back the saved archive, not just the source streams.
        with zipfile.ZipFile(temporary) as archive:
            for name, entry in report['files'].items():
                progress('Conferindo arquivo gravado: '+name)
                with archive.open(name) as stream:
                    if hashlib.file_digest(stream,'sha256').hexdigest() != entry['sha256']:
                        raise ValueError('Falha na conferência do backup.')
        # Windows rename refuses an existing destination, including a race.
        temporary.rename(destination)
    finally:
        if temporary.exists():
            temporary.unlink()
    return str(destination)


def inspect_backup(path, profile):
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        names = [m.filename for m in members]
        if len(names) != len(set(n.casefold() for n in names)) or len(names)>9:
            raise ValueError('Backup contém nomes duplicados ou arquivos inesperados.')
        if set(names)-DB_NAMES-{ACTIVE,'backup.json'} or 'backup.json' not in names or ACTIVE not in names:
            raise ValueError('Conteúdo de backup inválido.')
        if any(m.is_dir() or m.flag_bits & 1 or (m.external_attr>>16)&0o170000 == 0o120000 for m in members):
            raise ValueError('Formato de arquivo não permitido.')
        if archive.getinfo('backup.json').file_size>65536 or archive.getinfo(ACTIVE).file_size>65536:
            raise ValueError('Metadados inválidos.')
        report = json.loads(archive.read('backup.json'))
        if report['format']!=1 or report['profile']!=profile or set(report['files'])!=set(names)-{'backup.json'}:
            raise ValueError('O backup não pertence a esta edição ou está incompleto.')
        if not REQUIRED.issubset(names):
            raise ValueError('Bancos obrigatórios ausentes.')
        for name, entry in report['files'].items():
            if (type(entry['size']) is not int or entry['size']<0 or entry['size']!=archive.getinfo(name).file_size
                    or not re.fullmatch('[0-9a-f]{64}',entry['sha256'])):
                raise ValueError('Inventário de backup inválido.')
        return report


def reconcile_restore(root, profile, progress=lambda text: None):
    root=Path(root).resolve(); marker=root/MARKER
    if not marker.exists(): return None
    if marker.is_symlink() or marker.stat().st_size>65536: raise ValueError('Registro de restauração inválido.')
    record=json.loads(marker.read_bytes())
    allowed=DB_NAMES | {n+s for n in DB_NAMES for s in ('-wal','-shm','-journal')} | {ACTIVE,PENDING}
    if (record['profile']!=profile or record['version']!=1
            or not re.fullmatch(r'\.restore-[0-9a-f]{32}',record['directory'])
            or not set(record['old']).issubset(allowed) or not set(record['new']).issubset(DB_NAMES|{ACTIVE})
            or ACTIVE not in record['new'] or not REQUIRED.issubset(record['new'])):
        raise ValueError('Registro de restauração inválido.')
    transaction=root/record['directory']; backup=transaction/'originals'
    for folder in (transaction,backup):
        if not folder.is_dir() or folder.is_symlink() or folder.is_junction(): raise ValueError('Restauração indisponível.')
    if (transaction/'committed').exists():
        if hashlib.sha256((root/ACTIVE).read_bytes()).hexdigest()!=record['manifest_sha256']:
            raise ValueError('Manifesto restaurado divergente.')
        marker.unlink(); return 'committed'
    progress('Retomando a restauração dos dados anteriores…')
    for name in record['new']:
        if name not in record['old'] and (root/name).exists(): (root/name).unlink()
    for name in record['old']:
        if (backup/name).exists(): os.replace(backup/name,root/name)
        elif not (root/name).is_file(): raise ValueError('Arquivo anterior ausente: '+name)
    marker.unlink(); return 'restored'


def restore_backup(root, profile, source, recovery_path, password, progress=lambda text: None, checkpoint=lambda event: None):
    root=Path(root).resolve()
    if (root/MARKER).exists() or (root/'database-activation.json').exists():
        raise ValueError('Há uma operação interrompida; conclua sua recuperação primeiro.')
    report=inspect_backup(source,profile)
    if shutil.disk_usage(root).free < sum(e['size'] for e in report['files'].values())+64*1024**2:
        raise ValueError('Espaço insuficiente para restaurar preservando os dados atuais.')
    transaction=root/('.restore-'+uuid.uuid4().hex); transaction.mkdir()
    new=transaction/'new'; new.mkdir(); backup=transaction/'originals'; backup.mkdir()
    with zipfile.ZipFile(source) as archive:
        for name,entry in report['files'].items():
            with archive.open(name) as src,(new/name).open('xb') as dst:
                sha=_copy(src,dst,entry['size'],progress,'Restaurando '+name)
                dst.flush(); os.fsync(dst.fileno())
            if sha!=entry['sha256']: raise ValueError('Backup danificado: '+name)
    # Always require recovery credentials, even on the original computer.
    recover(new,profile,recovery_path,password,progress)
    key=key_for_database(new/next(iter(REQUIRED)))
    for name in _names(new):
        progress('Validando integridade: '+name)
        with closing(connect_encrypted(new/name,key,readonly=True)) as db:
            if db.execute('PRAGMA quick_check').fetchall()!=[('ok',)] or db.execute('PRAGMA cipher_integrity_check').fetchall()!=[]:
                raise ValueError('Banco restaurado inválido: '+name)
    old=sorted(p.name for p in root.iterdir() if p.name in DB_NAMES|{n+s for n in DB_NAMES for s in ('-wal','-shm','-journal')}|{ACTIVE,PENDING})
    for name in old:
        if not (root/name).is_file() or (root/name).is_symlink() or (root/name).is_junction(): raise ValueError('Destino inválido.')
    new_names=sorted(report['files'])
    journal=dict(version=1,profile=profile,directory=transaction.name,old=old,new=new_names,
                 manifest_sha256=hashlib.sha256((new/ACTIVE).read_bytes()).hexdigest())
    _write(transaction/'journal.json',json.dumps(journal).encode())
    os.replace(transaction/'journal.json',root/MARKER)
    try:
        checkpoint('journal')
        for name in old:
            os.replace(root/name,backup/name); checkpoint('saved:'+name)
        for name in new_names:
            os.replace(new/name,root/name); checkpoint('installed:'+name)
        _write(transaction/'commit.tmp',b'complete')
        os.replace(transaction/'commit.tmp',transaction/'committed'); checkpoint('committed')
    except Exception:
        reconcile_restore(root,profile,progress); raise
    reconcile_restore(root,profile,progress)
    return 'Restauração concluída. Dados anteriores preservados em '+str(backup)
