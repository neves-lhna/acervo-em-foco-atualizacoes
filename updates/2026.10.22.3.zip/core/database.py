"""Shared connection routing. Existing plaintext editions remain unchanged.

An encrypted edition must have a valid database-security.json; any failure to
unlock it aborts access. Preparation uses a different file and cannot activate
encryption. Only validated activation may write the active manifest.
"""
import base64
import json
from pathlib import Path
import re
import sqlite3 as _sqlite
from urllib.parse import urlsplit, parse_qs
from urllib.request import url2pathname
from core.key_protection import unprotect_local
from core.secure_database import connect_encrypted, _key_literal

OperationalError = (_sqlite.OperationalError,)
try:
    from sqlcipher3 import dbapi2 as _cipher
except ImportError:
    _cipher = None
else:
    OperationalError += (_cipher.OperationalError,)


class DatabaseProtectionError(RuntimeError):
    pass


def _path_and_mode(database, uri):
    if str(database) == ':memory:':
        return None, 'rwc'
    if uri:
        parsed = urlsplit(str(database))
        if parsed.scheme != 'file':
            raise ValueError('Endereço de banco inválido')
        mode = parse_qs(parsed.query).get('mode', ['rwc'])[0]
        if mode not in ('ro', 'rw', 'rwc'):
            raise ValueError('Modo de banco inválido')
        location = ('//' + parsed.netloc if parsed.netloc else '') + parsed.path
        return Path(url2pathname(location)).resolve(), mode
    return Path(database).resolve(), 'rwc'


def key_for_database(path):
    root = Path(path).resolve().parent
    manifest = root/'database-security.json'
    try:
        # Even a partially swapped edition must never route through plaintext.
        try:
            for name in ('database-activation.json', 'database-restore.json'):
                try:
                    (root/name).stat()
                except FileNotFoundError:
                    continue
                raise ValueError('Manutenção interrompida')
        except FileNotFoundError:
            pass
        try:
            size = manifest.stat().st_size
        except FileNotFoundError:
            return None
        if size > 65536:
            raise ValueError()
        data = json.loads(manifest.read_text(encoding='utf-8'))
        if data['version'] != 1 or data['state'] != 'encrypted':
            raise ValueError()
        return unprotect_local(base64.b64decode(data['local_key'], validate=True), data['profile'])
    except Exception:
        raise DatabaseProtectionError(
            'Não foi possível desbloquear os bancos protegidos. '
            'Use a recuperação nesta conta do Windows; os dados não foram alterados.') from None


def connect(database, timeout=5, *, check_same_thread=True, uri=False):
    path, mode = _path_and_mode(database, uri)
    key = key_for_database(path) if path is not None else None
    if key is None:
        return _sqlite.connect(database, timeout=timeout,
                               check_same_thread=check_same_thread, uri=uri)
    try:
        return connect_encrypted(path, key, readonly=mode == 'ro', create=mode == 'rwc',
                                 timeout=timeout, check_same_thread=check_same_thread)
    except ImportError:
        raise DatabaseProtectionError('O componente de criptografia não está instalado. A abertura foi interrompida.') from None


def attach(connection, path, alias):
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', alias) or alias.lower() in ('main', 'temp'):
        raise ValueError('Identificador de banco inválido')
    path = Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    key = key_for_database(path)
    cipher = connection.execute('PRAGMA cipher_version').fetchone()
    if key is not None and not cipher:
        raise DatabaseProtectionError('Não é possível anexar um banco protegido à conexão sem criptografia.')
    suffix = (' KEY ' + (_key_literal(key) if key is not None else "''")) if cipher else ''
    connection.execute(f'ATTACH DATABASE ? AS {alias}' + suffix, (str(path),))
