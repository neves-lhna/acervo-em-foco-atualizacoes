"""Export-only processing. Originals and recognition/cache are never modified."""
import io
import os
from pathlib import Path
from dataclasses import dataclass
from PIL import Image, ImageOps, ImageCms
import numpy as np
from core.image_loader import RAW_EXTENSIONS, open_raw, standard_image_signature
from workers.face_export_worker import copy_unique

@dataclass(frozen=True)
class ExportOptions:
    jpeg: bool = False
    method: str = 'camera'
    limit: int | None = 15_000_000


def metadata(path):
    try:
        with Image.open(path) as source:
            exif=source.getexif()
            # Keep capture/camera/GPS/copyright, not stale RAW offsets or thumbnails.
            clean=Image.Exif()
            for tag in (271,272,305,306,315,33432):
                if tag in exif:clean[tag]=exif[tag]
            for tag in (34665,34853):
                if tag in exif:
                    values=dict(exif.get_ifd(tag))
                    for stale in (37500,40962,40963):values.pop(stale,None)
                    clean[tag]=values
            clean[274]=1
            return clean.tobytes(), [] if len(exif) else ['Origem sem metadados EXIF disponíveis.']
    except Exception:
        return b'', ['Não foi possível transferir os metadados EXIF desta origem.']


def rendered(path,method='camera'):
    """Returns RGB with upright pixels, method label and metadata warnings."""
    raw_source=Path(path).suffix.lower() in RAW_EXTENSIONS and not standard_image_signature(path)
    if raw_source:
        import rawpy
        with open_raw(path) as raw:
            if method=='camera':
                try:
                    thumb=raw.extract_thumb()
                    image=Image.open(io.BytesIO(thumb.data)) if thumb.format==rawpy.ThumbFormat.JPEG else Image.fromarray(thumb.data)
                    image.load()
                    # A full-size embedded image must contain at least 90% of RAW pixels.
                    if image.width*image.height >= raw.sizes.width*raw.sizes.height*.9:
                        orientation=image.getexif().get(274)
                        if orientation:image=ImageOps.exif_transpose(image)
                        elif raw.sizes.flip in (3,5,6):
                            image=image.transpose({3:Image.Transpose.ROTATE_180,5:Image.Transpose.ROTATE_90,6:Image.Transpose.ROTATE_270}[raw.sizes.flip])
                        return to_srgb(image),'JPG da câmera',[]
                except Exception:
                    pass # Missing/unsupported preview falls back to full RAW decoding.
            rgb=raw.postprocess(half_size=False,use_camera_wb=True,output_bps=8,output_color=rawpy.ColorSpace.sRGB)
            return Image.fromarray(rgb),'RAW revelado',(['Prévia ausente ou insuficiente; utilizada revelação RAW.'] if method=='camera' else [])
    with Image.open(path) as source:
        image=ImageOps.exif_transpose(source)
        return to_srgb(image),'Imagem convertida',[]


def to_srgb(image):
    profile=image.info.get('icc_profile')
    if profile:
        image=ImageCms.profileToProfile(image,ImageCms.ImageCmsProfile(io.BytesIO(profile)),ImageCms.createProfile('sRGB'),outputMode='RGB')
    if image.mode in ('RGBA','LA') or 'transparency' in image.info:
        rgba=image.convert('RGBA');bg=Image.new('RGB',rgba.size,'white');bg.paste(rgba,mask=rgba.getchannel('A'));return bg
    return image.convert('RGB').copy()


def exposure_warning(image):
    small=image.convert('RGB');small.thumbnail((1024,1024))
    rgb=np.asarray(small,dtype=np.float32)
    y=.2126*rgb[:,:,0]+.7152*rgb[:,:,1]+.0722*rgb[:,:,2]
    dark=float(np.mean(y<=8));bright=float(np.mean(y>=247))
    if dark>=.02 and bright>=.02:
        return f'Possível perda de detalhes: {dark:.1%} em sombras profundas e {bright:.1%} em altas luzes. Avaliação visual necessária.'
    return ''


def jpeg_bytes(image,limit,exif=b''):
    image=image.convert('RGB');original=image.size
    icc=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    while True:
        for quality in ((98,) if limit is None else (98,95,92,90,87,85)):
            stream=io.BytesIO()
            image.save(stream,'JPEG',quality=quality,subsampling=0,optimize=False,exif=exif,icc_profile=icc)
            if limit is None or stream.tell()<=limit:return stream.getvalue(),image.size!=original
        if min(image.size)<=1:raise ValueError('Limite insuficiente para o JPG e seus metadados.')
        image=image.resize((max(1,int(image.width*.9)),max(1,int(image.height*.9))),Image.Resampling.LANCZOS)


def export_one(row,destination,options):
    path,_,_,mtime,size,*_=row;source=Path(path)
    before=source.stat()
    if (before.st_mtime_ns,before.st_size)!=(mtime,size):raise ValueError('Origem alterada desde a busca; atualize os resultados.')
    notes=[];method='Cópia original';warning=''
    already_jpeg=source.suffix.lower() in ('.jpg','.jpeg') and standard_image_signature(source)=='JPEG'
    if not options.jpeg or (already_jpeg and (options.limit is None or size<=options.limit)):
        target=copy_unique(path,destination,mtime,size)
        try:
            image,_,_=rendered(target,'camera');warning=exposure_warning(image)
        except Exception as exc:notes.append('Revisão de exposição indisponível: '+str(exc))
    else:
        image,method,notes=rendered(source,options.method)
        exif,metadata_notes=metadata(source);notes+=metadata_notes
        data,reduced=jpeg_bytes(image,options.limit,exif)
        if reduced:notes.append('Dimensões reduzidas para respeitar o limite de tamanho.')
        with Image.open(io.BytesIO(data)) as result:warning=exposure_warning(result)
        after=source.stat()
        if (after.st_mtime_ns,after.st_size)!=(mtime,size):raise ValueError('Origem alterada durante a conversão.')
        number=0
        while True:
            target=Path(destination)/(source.stem+(f' ({number})' if number else '')+'.jpg')
            try:output=target.open('xb');break
            except FileExistsError:number+=1
        try:
            with output:output.write(data)
        except Exception:
            target.unlink(missing_ok=True);raise
        target=str(target)
    st=os.stat(target)
    return dict(source=str(source),path=target,method=method,warning=warning,notes=notes,mtime=st.st_mtime_ns,size=st.st_size)


def discard_export(record,destination):
    """Only an unchanged copy produced in this batch can reach the Recycle Bin."""
    from send2trash import send2trash
    path=Path(record['path'])
    if path.is_symlink() or path.resolve().parent!=Path(destination).resolve():raise ValueError('Cópia fora do destino autorizado.')
    if path.resolve()==Path(record['source']).resolve():raise ValueError('O original não pode ser excluído.')
    st=path.stat()
    if (st.st_mtime_ns,st.st_size)!=(record['mtime'],record['size']):raise ValueError('Cópia alterada após a exportação; exclusão cancelada.')
    send2trash(str(path.resolve()))
