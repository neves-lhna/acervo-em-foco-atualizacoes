"""Prepare and verify recovery material; NEVER encrypt/replace live databases."""
import base64
import hashlib
import json
import os
from pathlib import Path
import secrets
from core.key_protection import protect_local, unprotect_local, wrap_recovery, unwrap_recovery


def _write_new(path, payload):
    with Path(path).open('xb') as output:
        output.write(payload)
        output.flush()
        os.fsync(output.fileno())


def prepare(root, profile, password, recovery_path):
    root, recovery_path = Path(root).resolve(), Path(recovery_path).resolve()
    pending = root/'database-security.pending.json'
    if not root.is_dir():
        raise ValueError('Pasta de dados indisponível')
    if pending.exists() or (root/'database-security.json').exists():
        raise ValueError('Já existe uma preparação ou proteção configurada. Preserve os arquivos de recuperação existentes.')
    if recovery_path.is_relative_to(root):
        raise ValueError('Guarde a recuperação fora da pasta dos bancos')
    if recovery_path.exists():
        raise ValueError('Escolha um arquivo novo; nenhum arquivo existente será substituído')
    # Validate local runtime before asking the user to rely on recovery material.
    from sqlcipher3 import dbapi2
    probe = dbapi2.connect(':memory:')
    try:
        if not probe.execute('PRAGMA cipher_version').fetchone():
            raise RuntimeError('Componente de criptografia indisponível')
    finally:
        probe.close()
    key = secrets.token_bytes(32)
    local = protect_local(key, profile)
    recovery = wrap_recovery(key, password, profile)
    if unprotect_local(local, profile) != key or unwrap_recovery(recovery, password, profile) != key:
        raise RuntimeError('A verificação da recuperação falhou')
    _write_new(recovery_path, recovery)
    # Read back the file actually saved, not only the in-memory envelope.
    if unwrap_recovery(recovery_path.read_bytes(), password, profile) != key:
        raise RuntimeError('O arquivo salvo não passou na verificação')
    record = {'version': 1, 'state': 'prepared', 'profile': profile,
              'local_key': base64.b64encode(local).decode('ascii'),
              'recovery_sha256': hashlib.sha256(recovery).hexdigest()}
    # A failure here leaves only a password-encrypted orphan recovery file;
    # it never marks live databases as encrypted or overwrites existing keys.
    _write_new(pending, json.dumps(record, indent=2).encode('utf-8'))
    return pending
