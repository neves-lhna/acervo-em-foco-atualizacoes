"""Image decoding for analysis; RAW previews avoid full demosaicing."""
from pathlib import Path
from contextlib import contextmanager
from core.file_errors import file_error_message

import cv2
import numpy as np
from pillow_heif import register_heif_opener
from PIL import Image,ImageOps
register_heif_opener()
HEIF_EXTENSIONS={'.heic','.heif','.hif'}

RAW_EXTENSIONS = {".raw", ".cr2", ".cr3", ".nef", ".nrw", ".arw", ".srf",
                  ".sr2", ".dng", ".raf", ".orf", ".rw2", ".pef", ".3fr"}


def standard_image_signature(path):
    """Recognize complete standard containers, never JPEG previews inside RAWs."""
    with open(path, 'rb') as source:
        header = source.read(8)
    if header.startswith(b'\xff\xd8\xff'):return 'JPEG'
    if header == b'\x89PNG\r\n\x1a\n':return 'PNG'
    return None


@contextmanager
def open_raw(path):
    import rawpy
    try:
        raw = rawpy.imread(str(path))
    except rawpy.LibRawIOError:
        # Python handles Unicode Windows paths; retry through LibRaw's buffer API.
        with open(path, 'rb') as source:
            raw = rawpy.imread(source)
    with raw:
        yield raw


def load_bgr_image(path):
    try:
        return _load_bgr_image(path)
    except Exception as exc:
        readable = file_error_message(exc)
        if readable != str(exc):
            raise OSError(readable) from exc
        raise


def _load_bgr_image(path):
    if Path(path).suffix.lower() in HEIF_EXTENSIONS:
        with Image.open(path) as source:
            rgb=np.asarray(ImageOps.exif_transpose(source).convert('RGB'))
            return cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
    if Path(path).suffix.lower() in RAW_EXTENSIONS and not standard_image_signature(path):
        import rawpy

        with open_raw(path) as raw:
            try:
                thumb = raw.extract_thumb()
                if thumb.format == rawpy.ThumbFormat.JPEG:
                    preview = cv2.imdecode(np.frombuffer(thumb.data, np.uint8),
                                           cv2.IMREAD_COLOR)
                else:
                    preview = cv2.cvtColor(thumb.data, cv2.COLOR_RGB2BGR)
                # Tiny thumbnails lose faces in groups; develop those RAWs.
                if preview is not None and min(preview.shape[:2]) >= 1080:
                    return preview
            except (rawpy.LibRawNoThumbnailError, rawpy.LibRawUnsupportedThumbnailError):
                pass
            try:
                rgb = raw.postprocess(half_size=True, use_camera_wb=True,
                                      output_bps=8, no_auto_bright=True)
            except rawpy.LibRawIOError as exc:
                raise OSError('O leitor RAW abriu o arquivo, mas não conseguiu decodificar os dados completos '
                              '(erro de entrada/saída). Uma miniatura pode aparecer no Explorer mesmo assim. '
                              'Confirme a leitura completa em um editor compatível com RAW e verifique a unidade '
                              'ou uma cópia de segurança. O arquivo não foi alterado nem considerado analisado.') from exc
            return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    try:
        image=cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
        if image is not None:return image
    except OSError:
        raise
    except (ValueError, cv2.error):
        pass
    # Qt can display some truncated JPEGs rejected by OpenCV. Decode without
    # repairing or rewriting the original file; QImage is safe in workers.
    from PySide6.QtGui import QImageReader,QImage
    reader=QImageReader(str(path));reader.setAutoTransform(True)
    image=reader.read()
    if image.isNull():return None
    image=image.convertToFormat(QImage.Format_RGB888)
    rows=np.frombuffer(image.constBits(),dtype=np.uint8).reshape(image.height(),image.bytesPerLine())
    rgb=rows[:,:image.width()*3].reshape(image.height(),image.width(),3)
    return cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
