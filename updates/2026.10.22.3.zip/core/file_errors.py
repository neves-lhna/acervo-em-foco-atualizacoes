"""Readable file errors, including legacy messages saved as byte representations."""
import ast
import errno


def file_error_message(error):
    message = str(error)
    if message.startswith(("b'", 'b"')):
        try:
            value = ast.literal_eval(message)
            if isinstance(value, bytes):message = value.decode('utf-8', errors='replace')
        except (ValueError, SyntaxError):
            pass
    if 'input/output error' in message.lower() or getattr(error, 'errno', None) == errno.EIO:
        return ('Não foi possível ler os dados do arquivo (erro de entrada/saída). '
                'Verifique se a unidade está conectada e se o arquivo pode ser aberto por completo. '
                'Depois, tente continuar a análise. Esse erro, sozinho, não confirma que a foto está corrompida.')
    return message
