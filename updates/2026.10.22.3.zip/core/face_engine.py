"""
core/face_engine.py
--------------------
Encapsula o modelo de detecção + reconhecimento facial.

Escolha técnica: InsightFace (pacote `insightface`), usando o bundle
"buffalo_l", que combina:
  - RetinaFace (det_10g)  -> detecção de rostos, robusta a rotação/perfil
  - ArcFace   (w600k_r50) -> extração de embedding de 512 dimensões

Por que InsightFace/ArcFace e não apenas dlib/face_recognition?
  - dlib/face_recognition (baseado em HOG ou CNN + ResNet pequena) tem
    excelente desempenho em rostos frontais, mas degrada bastante em
    poses de perfil/ângulo acentuado.
  - RetinaFace foi treinado com landmarks de 5 pontos que toleram bem
    rotação no plano e fora do plano (perfil), e o ArcFace (loss
    angular) produz embeddings mais discriminativos e robustos a
    variação de iluminação/expressão do que embeddings baseados em
    softmax comum.
  - O detector já retorna um `det_score` (confiança) e pode ser
    configurado com `det_size` maior para detectar rostos pequenos em
    fotos de grupo.

Os embeddings retornados pelo InsightFace (`face.normed_embedding`) já
são vetores L2-normalizados de 512D, portanto a similaridade de
cosseno entre dois vetores é simplesmente o produto escalar (dot
product), o que barateia bastante o cálculo em lote.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import List, Optional

import cv2
import numpy as np


@dataclass
class DetectedFace:
    """Representa um rosto detectado em uma imagem."""
    bbox: np.ndarray            # [x1, y1, x2, y2]
    det_score: float            # confiança da detecção (0-1)
    embedding: np.ndarray       # vetor 512D, L2-normalizado
    pose: str                   # "frontal" | "perfil" (heurística por yaw)
    landmarks: Optional[np.ndarray] = None


class FaceEngine:
    """
    Wrapper single-instance e thread-safe em torno do FaceAnalysis do
    InsightFace. Como o worker de varredura roda em outra thread, o
    engine é criado uma vez e reutilizado (carregar os modelos ONNX é
    caro: ~1-2s), mas cada chamada de inferência é protegida por um
    lock, pois a sessão ONNXRuntime não é garantidamente thread-safe
    para chamadas concorrentes vindas de múltiplos workers.
    """

    _instance: "FaceEngine | None" = None
    _instance_lock = threading.Lock()

    def __init__(self, ctx_id: int = 0, det_size: tuple[int, int] = (640, 640)):
        # Import tardio: evita custo de import do insightface/onnxruntime
        # antes de realmente ser necessário (melhora tempo de boot da UI).
        from insightface.app import FaceAnalysis

        self._infer_lock = threading.Lock()

        # `buffalo_l` inclui detecção (RetinaFace) + reconhecimento (ArcFace)
        # + gênero/idade (não usados aqui, mas fazem parte do bundle padrão).
        self.app = FaceAnalysis(
            name="buffalo_l",
            allowed_modules=["detection", "recognition"],
            providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
        )
        # ctx_id = -1 força CPU; 0 usa a primeira GPU disponível (CUDA).
        # det_size maior = detecta rostos menores em fotos de grupo, ao
        # custo de mais tempo de inferência.
        self.app.prepare(ctx_id=ctx_id, det_size=det_size)

    @classmethod
    def instance(cls) -> "FaceEngine":
        """Singleton lazy: garante um único carregamento dos modelos ONNX."""
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    # ------------------------------------------------------------------
    # Detecção / extração de embeddings
    # ------------------------------------------------------------------
    def detect_faces(self, bgr_image: np.ndarray) -> List[DetectedFace]:
        """
        Detecta todos os rostos em uma imagem (formato BGR, como o
        OpenCV lê por padrão) e retorna embeddings + heurística de pose.
        """
        if bgr_image is None:
            return []

        with self._infer_lock:
            faces = self.app.get(bgr_image)

        results: List[DetectedFace] = []
        for f in faces:
            pose = self._estimate_pose(f)
            results.append(
                DetectedFace(
                    bbox=f.bbox,
                    det_score=float(f.det_score),
                    embedding=f.normed_embedding.astype(np.float32),
                    pose=pose,
                    landmarks=getattr(f, "kps", None),
                )
            )
        return results

    @staticmethod
    def _estimate_pose(face) -> str:
        """
        Heurística simples de frontal x perfil usando os 5 landmarks
        (olhos, nariz, cantos da boca) que o RetinaFace já fornece.
        Compara a distância horizontal nariz-olho esquerdo vs
        nariz-olho direito: em rostos de perfil essa razão fica bem
        assimétrica. Não é uma estimativa de yaw exata, mas é
        suficiente para exibir/filtrar na UI sem custo adicional.
        """
        try:
            kps = face.kps  # [olho_esq, olho_dir, nariz, boca_esq, boca_dir]
            left_eye, right_eye, nose = kps[0], kps[1], kps[2]
            d_left = abs(nose[0] - left_eye[0])
            d_right = abs(nose[0] - right_eye[0])
            ratio = min(d_left, d_right) / max(d_left, d_right, 1e-6)
            return "frontal" if ratio > 0.35 else "perfil"
        except Exception:
            return "frontal"

    # ------------------------------------------------------------------
    # Similaridade
    # ------------------------------------------------------------------
    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        """
        Como os embeddings do ArcFace já são L2-normalizados, a
        similaridade de cosseno é apenas o produto escalar.
        Retorna valor aproximadamente entre -1 e 1 (na prática, entre
        rostos, fica entre ~0.0 e 1.0).
        """
        return float(np.dot(a, b))

    @staticmethod
    def best_match_score(query_embedding: np.ndarray, candidate_embeddings: List[np.ndarray]) -> float:
        """
        Quando uma foto tem vários rostos, o "score da foto" é a
        melhor similaridade entre o rosto de referência e qualquer
        rosto detectado naquela foto.
        """
        if not candidate_embeddings:
            return -1.0
        stacked = np.stack(candidate_embeddings)  # (N, 512)
        sims = stacked @ query_embedding  # produto escalar em lote
        return float(sims.max())


from core.image_loader import load_bgr_image
