"""SQLCipher connections and isolated export used by validated activation.

No fallback to plaintext. Keys must never be logged or passed on command lines.
This module alone never replaces live databases or activates a manifest.
"""
from pathlib import Path


def _key_literal(key):
    if not isinstance(key, bytes) or len(key) != 32:
        raise ValueError('Chave de banco inválida')
    return '"x\'' + key.hex() + '\'"'


def connect_encrypted(path, key, *, readonly=False, create=False, timeout=10,
                      check_same_thread=True):
    from sqlcipher3 import dbapi2
    literal = _key_literal(key)
    path = Path(path).resolve()
    mode = 'ro' if readonly else ('rwc' if create else 'rw')
    conn = dbapi2.connect(path.as_uri() + '?mode=' + mode, uri=True,
                         timeout=timeout, check_same_thread=check_same_thread)
    try:
        if not conn.execute('PRAGMA cipher_version').fetchone():
            raise RuntimeError('SQLCipher indisponível; acesso interrompido')
        conn.execute('PRAGMA key = ' + literal)
        conn.execute('PRAGMA temp_store=MEMORY')
        conn.execute('PRAGMA cipher_memory_security=ON')
        conn.execute('SELECT count(*) FROM sqlite_master').fetchone()
        if readonly:
            conn.execute('PRAGMA query_only=ON')
        return conn
    except Exception:
        conn.close()
        raise


def export_plaintext_copy(source, destination, key):
    """Export read-only source into a NEW encrypted file; never replace source."""
    from sqlcipher3 import dbapi2
    source, destination = Path(source).resolve(), Path(destination).resolve()
    literal = _key_literal(key)
    # Exclusive reservation avoids overwriting an existing backup/database.
    with destination.open('xb'):
        pass
    conn = None
    try:
        conn = dbapi2.connect(source.as_uri() + '?mode=ro', uri=True)
        if not conn.execute('PRAGMA cipher_version').fetchone():
            raise RuntimeError('SQLCipher indisponível')
        conn.execute('PRAGMA temp_store=MEMORY')
        version = int(conn.execute('PRAGMA user_version').fetchone()[0])
        app_id = int(conn.execute('PRAGMA application_id').fetchone()[0])
        conn.execute('ATTACH DATABASE ? AS encrypted KEY ' + literal, (str(destination),))
        conn.execute("SELECT sqlcipher_export('encrypted')").fetchone()
        conn.execute(f'PRAGMA encrypted.user_version={version}')
        conn.execute(f'PRAGMA encrypted.application_id={app_id}')
        conn.commit()
        conn.execute('DETACH DATABASE encrypted')
    except Exception:
        if conn is not None:
            conn.close()
            conn = None
        # Keep failed output for inspection; it must not be considered a migration.
        raise
    finally:
        if conn is not None:
            conn.close()
