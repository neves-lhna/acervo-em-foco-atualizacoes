"""Recognize drive-letter changes before opening any application database."""
import hashlib
import json
import ntpath
import os
from core import database as sqlite3
from pathlib import Path

PATH_COLUMNS = {
    'folder_history.db': {'roots': ('key', 'path'), 'coverage': ('root', 'key', 'path'), 'file_failures': ('root', 'key', 'path'), 'discovered_folders': ('key',), 'folder_observations': ('key','path'), 'cache_details': ('key',)},
    'embeddings_cache.db': {'faces': ('path',), 'scanned_images': ('path',)},
    'duplicates.db': {'signatures': ('path',), 'runs': ('folder',), 'files': ('path',), 'pairs': ('a', 'b')},
    'face_history.db': {'faces': ('folder',), 'matches': ('path',)},
    'authorities.db': {'faces': ('folder',), 'matches': ('path',),
                       'authority_settings': ('folder',), 'authority_checked': ('path',),
                       'authority_inventory_state': ('folder',), 'authority_inventory': ('path',)},
    'deletions.db': {'deletions': ('path',)},
    'extension_review.db': {'review': ('path', 'copy')},
}

def canonical(path):
    return ntpath.normpath(path).casefold()

def relocated(path, mappings):
    if not path:
        return path
    normalized = ntpath.normpath(path)
    for old, new in sorted(mappings, key=lambda pair: len(pair[0]), reverse=True):
        key = canonical(old)
        if canonical(normalized) == key or canonical(normalized).startswith(key + '\\'):
            suffix = normalized[len(ntpath.normpath(old)):]
            result = ntpath.normpath(new) + suffix
            return result.casefold() if path == path.casefold() else result
    return path

def fingerprint(path):
    """Bounded reads; no decoding and no writes to the photographic archive."""
    with open(path, 'rb') as stream:
        size = os.fstat(stream.fileno()).st_size
        first = stream.read(65536)
        stream.seek(max(0, size - 65536))
        last = stream.read(65536)
    return {'size': size, 'digest': hashlib.sha256(first + last).hexdigest()}

def available_drives():
    if os.name != 'nt':
        return []
    import ctypes
    mask = ctypes.windll.kernel32.GetLogicalDrives()
    # Fixed/removable drives only; avoid inaccessible network mappings and optical drives.
    return [chr(65+i) + ':\\' for i in range(26) if mask & (1 << i)
            and ctypes.windll.kernel32.GetDriveTypeW(chr(65+i) + ':\\') in (2, 3)]

def matches(root, samples):
    if len(samples) < 3:
        return False
    good = 0
    for sample in samples:
        try:
            actual = fingerprint(ntpath.join(root, sample['relative']))
        except OSError:
            continue
        if actual != sample['fingerprint']:
            return False
        good += 1
    return good >= 3

def locate(root, samples, drives):
    if matches(root, samples):
        return root, ''
    drive, relative = ntpath.splitdrive(ntpath.normpath(root))
    if not drive or drive.startswith('\\\\'):
        return None, 'Localização automática disponível somente para unidades locais.'
    candidates = [ntpath.join(d, relative.lstrip('\\/')) for d in drives]
    found = [candidate for candidate in candidates if canonical(candidate) != canonical(root)
             and matches(candidate, samples)]
    if len(found) == 1:
        return found[0], ''
    if len(found) > 1:
        return None, 'Mais de uma cópia compatível foi encontrada. Os caminhos foram mantidos.'
    return None, 'Acervo indisponível ou sem correspondência segura. Conecte o HD; o cache foi mantido.'

def collect_samples(data, root):
    cache = data / 'embeddings_cache.db'
    if not cache.exists():
        return []
    db = sqlite3.connect(cache.as_uri() + '?mode=ro', uri=True)
    samples = []
    try:
        # Normalize repeated separators left by earlier transfers before prefix filtering.
        prefix = ntpath.normpath(root).rstrip('\\') + '\\'
        like = prefix.replace('!', '!!').replace('%', '!%').replace('_', '!_') + '%'
        rows = db.execute("SELECT path FROM scanned_images WHERE replace(path, ?, ?) LIKE ? ESCAPE '!' LIMIT 128",
                          ('\\\\', '\\', like))
        for (path,) in rows:
            try:
                sample = fingerprint(path)
            except OSError:
                continue
            samples.append({'relative': ntpath.relpath(ntpath.normpath(path), ntpath.normpath(root)), 'fingerprint': sample})
            if len(samples) == 8:
                break
    finally:
        db.close()
    return samples

def migrate(data, mappings, progress=lambda message: None):
    """One SQLite super-journal transaction covers all databases, including collisions."""
    existing = [(name, tables) for name, tables in PATH_COLUMNS.items() if (data/name).exists()]
    if not existing:
        return
    connections = sqlite3.connect(data/existing[0][0], timeout=10)
    connections.create_function('relocate_path', 1, lambda p: relocated(p, mappings))
    try:
        schemas = []
        for i, (name, tables) in enumerate(existing):
            alias = 'main' if i == 0 else 'db' + str(i)
            if i:
                sqlite3.attach(connections, data/name, alias)
            mode = connections.execute(f'PRAGMA {alias}.journal_mode=DELETE').fetchone()[0]
            if mode.lower() != 'delete':
                raise RuntimeError('Feche as outras instâncias do programa antes de ajustar os caminhos.')
            connections.execute(f'PRAGMA {alias}.synchronous=FULL')
            schemas.append((alias, name, tables))
        connections.execute('BEGIN IMMEDIATE')
        for alias, name, tables in schemas:
            progress('Atualizando caminhos: ' + name + '. Aguarde; não é uma nova análise das fotos.')
            existing_tables = {r[0] for r in connections.execute(f"SELECT name FROM {alias}.sqlite_master WHERE type='table'")}
            for table, columns in tables.items():
                if table not in existing_tables:
                    continue
                actual_columns = {r[1] for r in connections.execute(f'PRAGMA {alias}.table_info("{table}")')}
                columns = [c for c in columns if c in actual_columns]
                if columns:
                    assignments = ','.join(f'"{c}"=relocate_path("{c}")' for c in columns)
                    condition = ' OR '.join(f'"{c}"<>relocate_path("{c}")' for c in columns)
                    connections.execute(f'UPDATE {alias}."{table}" SET {assignments} WHERE {condition}')
        connections.commit()
    except Exception:
        connections.rollback()
        raise
    finally:
        connections.close()

def synchronize(data, progress=lambda message: None):
    data = Path(data).resolve()
    history = data/'folder_history.db'
    if not history.exists():
        return {'mappings': [], 'warnings': []}
    registry = data/'archive_locations.json'
    try:
        identities = json.loads(registry.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        identities = {}
    db = sqlite3.connect(history.as_uri() + '?mode=ro', uri=True)
    try:
        roots = [r[0] for r in db.execute('SELECT path FROM roots')]
    finally:
        db.close()
    mappings, warnings = [], []
    drives = available_drives()
    for root in roots:
        progress('Procurando o acervo: ' + root)
        key = canonical(root)
        samples = identities.get(key, [])
        if not samples:
            if os.path.isdir(root):
                samples = collect_samples(data, root)
                if len(samples) >= 3:
                    identities[key] = samples
                    continue
            warnings.append(root + ': sem amostras suficientes para identificar o acervo automaticamente. Conecte-o no caminho original uma vez.')
            continue
        found, warning = locate(root, samples, drives)
        if warning:
            warnings.append(root + ': ' + warning)
        if found and canonical(found) != key:
            mappings.append((root, found))
    if mappings:
        migrate(data, mappings, progress)
        for old, new in mappings:
            identities[canonical(new)] = identities.pop(canonical(old))
    temp = registry.with_suffix('.tmp')
    temp.write_text(json.dumps(identities, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(registry)
    return {'mappings': mappings, 'warnings': warnings}
