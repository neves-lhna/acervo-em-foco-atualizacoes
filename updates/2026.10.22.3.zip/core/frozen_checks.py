"""Exercise packaged dependencies with temporary data, never user databases."""
import json
import tempfile
from pathlib import Path


def run_checks(output):
    report={'ok':False,'checks':[]}
    try:
        import cv2
        import numpy as np
        import rawpy
        from PySide6.QtWidgets import QApplication
        from ui.branding import artwork
        from ui.theme import apply_theme
        from ui.windows_folder_dialog import choose_folder_with_files
        from core.face_engine import FaceEngine
        from core.embedding_cache import EmbeddingCache
        from core.face_history import FaceHistory
        from workers.duplicate_worker import DuplicateWorker,connect
        from workers.face_export_worker import copy_unique
        app=QApplication.instance() or QApplication([])
        apply_theme(app)
        assert all(not artwork(kind).isNull() for kind in ('icone','nome','logo'))
        report['checks'].append('Qt, tema e três logos')
        report['checks'].append('RAW e seletor nativo importados')
        with tempfile.TemporaryDirectory() as temp:
            temp=Path(temp);photos=temp/'photos';photos.mkdir();dest=temp/'copies';dest.mkdir()
            bgr=np.full((128,192,3),127,dtype=np.uint8)
            data=cv2.imencode('.jpg',bgr)[1].tobytes()
            a=photos/'a.jpg';b=photos/'b.jpg';a.write_bytes(data);b.write_bytes(data)
            stat=a.stat();copied=copy_unique(str(a),str(dest),stat.st_mtime_ns,stat.st_size)
            assert Path(copied).read_bytes()==data
            report['checks'].append('Cópia preservando conteúdo')
            worker=DuplicateWorker(str(photos),10,str(temp/'duplicates.db'))
            worker.run()
            db=connect(str(temp/'duplicates.db'))
            assert db.execute('SELECT count(*) FROM pairs').fetchone()[0]==1
            db.close();report['checks'].append('Duplicidade de JPEGs idênticos')
            history=FaceHistory(str(temp/'faces.db'))
            key=history.start(np.ones(512,dtype=np.float32),b'',str(photos))
            history.add(key,str(a),.9,'frontal')
            assert len(history.results(key))==1
            history.db.close();report['checks'].append('Histórico persistente')
            cache=EmbeddingCache(str(temp/'cache.db'));cache.close()
            report['checks'].append('Banco de cache isolado')
            from core.export_pipeline import export_one,ExportOptions
            from ui.export_dialog import ExportDialog
            from PIL import Image
            png=photos/'export.png';Image.new('RGB',(64,48),'gray').save(png);st=png.stat()
            result=export_one((str(png),1,'frontal',st.st_mtime_ns,st.st_size,b''),str(dest),ExportOptions(True))
            assert Path(result['path']).suffix=='.jpg' and png.exists()
            report['checks'].append('Janela de exportação e conversão JPG com original preservado')
        engine=FaceEngine.instance()
        faces=engine.detect_faces(np.zeros((640,640,3),dtype=np.uint8))
        assert not faces
        report['checks'].append('Modelos ONNX carregados e detecção executada')
        report['ok']=True
    except Exception:
        import traceback
        report['error']=traceback.format_exc()
    Path(output).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0 if report['ok'] else 1
