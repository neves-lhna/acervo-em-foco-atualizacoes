"""Persistent inventory of folder coverage. It never runs face recognition."""
import os
from core import database as sqlite3
import threading
from datetime import datetime

from core.image_loader import RAW_EXTENSIONS,HEIF_EXTENSIONS

IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tiff', '.tif'} | RAW_EXTENSIONS | HEIF_EXTENSIONS


def is_image_file(path):
    if os.path.splitext(path)[1].lower() not in IMAGE_EXTENSIONS:return False
    if os.path.basename(path).startswith('._'):
        try:
            with open(path,'rb') as stream:
                if stream.read(4)==b'\x00\x05\x16\x07':return False
        except OSError:
            pass  # Inaccessible images must still be reported as failures.
    return True


def path_key(path):
    return os.path.normcase(os.path.abspath(path))


def is_within(path, parent):
    try:
        return os.path.commonpath([path_key(path), path_key(parent)]) == path_key(parent)
    except ValueError:
        return False


class FolderSnapshot:
    def __init__(self, root):
        self.root = os.path.abspath(root)
        self.folders = {}
        self.ready_paths = set()
        self.failures = {}
        self.dirty = set()
        self.file_signatures = {}
        self.directory_signatures = {}
        self.ensure(self.root)

    def ensure(self, folder):
        key = path_key(folder)
        if key not in self.folders:
            self.folders[key] = {'path': os.path.abspath(folder), 'total': 0, 'indexed': 0, 'errors': 0}
            self.dirty.add(key)

    def ancestors(self, path):
        folder = os.path.dirname(os.path.abspath(path))
        root = path_key(self.root)
        while os.path.commonpath([root, path_key(folder)]) == root:
            self.ensure(folder)
            yield path_key(folder)
            if path_key(folder) == root:
                break
            folder = os.path.dirname(folder)

    def add_file(self, path, ready):
        for key in self.ancestors(path):
            self.folders[key]['total'] += 1
            self.dirty.add(key)
        if ready:
            self.mark_ready(path)

    def mark_ready(self, path):
        key = path_key(path)
        if key in self.ready_paths:
            return
        self.ready_paths.add(key)
        for folder in self.ancestors(path):
            self.folders[folder]['indexed'] += 1
            self.dirty.add(folder)

    def mark_error(self, path, reason='Não foi possível acessar ou analisar o arquivo.'):
        from core.diagnostics import image_error
        image_error(path,reason)
        self.failures[path_key(path)] = (os.path.abspath(path), reason)
        for folder in self.ancestors(path):
            self.folders[folder]['errors'] += 1
            self.dirty.add(folder)


def inspect_folder(root, metadata, stopped=lambda: False, on_progress=None, on_activity=None):
    """Return an inventory and scan paths. None means cancelled, never a partial total."""
    if not os.path.isdir(root):
        raise OSError(f'Pasta indisponível: {root}')
    snapshot, paths = FolderSnapshot(root), []

    def walk_error(exc):
        snapshot.mark_error(os.path.join(exc.filename or root, '__directory__'),str(exc))

    for folder, dirs, files in os.walk(root, onerror=walk_error, followlinks=False):
        if stopped():
            return None, []
        # Do not count linked directories outside the selected collection.
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(folder, d))]
        snapshot.ensure(folder)
        try:
            directory_stat=os.stat(folder)
            snapshot.directory_signatures[folder]=(directory_stat.st_mtime_ns,directory_stat.st_ctime_ns,directory_stat.st_ino)
        except OSError:
            pass
        if on_activity:on_activity(len(paths),folder)
        for name in files:
            if stopped():
                return None, []
            if not is_image_file(os.path.join(folder,name)):
                continue
            path = os.path.join(folder, name)
            ready = False
            try:
                stat = os.stat(path)
                snapshot.file_signatures[path]=(stat.st_mtime_ns,stat.st_ctime_ns,stat.st_size,stat.st_ino)
                ready = (stat.st_mtime, stat.st_size) in metadata.get(path_key(path), ())
            except OSError as exc:
                snapshot.mark_error(path,str(exc))
            paths.append(path)
            snapshot.add_file(path, ready)
            if on_activity and len(paths) % 100 == 0:on_activity(len(paths),folder)
            if on_progress is not None and len(paths) % 1000 == 0:
                on_progress(len(paths))
    if on_activity:on_activity(len(paths),root)
    from core.diagnostics import folder_checked
    for folder in snapshot.folders.values():folder_checked(folder['path'],'Inventário')
    return snapshot, paths


class FolderHistory:
    def __init__(self, db_path):
        os.makedirs(os.path.dirname(db_path) or '.', exist_ok=True)
        self.lock = threading.Lock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False, timeout=10)
        with self.conn:
            self.conn.execute('CREATE TABLE IF NOT EXISTS roots (key TEXT PRIMARY KEY, path TEXT NOT NULL, state TEXT NOT NULL, checked_at TEXT, message TEXT NOT NULL DEFAULT "")')
            self.conn.execute('CREATE TABLE IF NOT EXISTS coverage (root TEXT NOT NULL, key TEXT NOT NULL, path TEXT NOT NULL, total INTEGER NOT NULL, indexed INTEGER NOT NULL, errors INTEGER NOT NULL, PRIMARY KEY(root,key))')
            self.conn.execute('CREATE TABLE IF NOT EXISTS file_failures (root TEXT, key TEXT, path TEXT, reason TEXT, PRIMARY KEY(root,key))')
            self.conn.execute('CREATE TABLE IF NOT EXISTS discovered_folders (key TEXT PRIMARY KEY)')
            self.conn.execute('CREATE TABLE IF NOT EXISTS folder_observations (key TEXT PRIMARY KEY,path TEXT,signature TEXT,first_seen TEXT,last_seen TEXT)')
            self.conn.execute('CREATE TABLE IF NOT EXISTS cache_details (key TEXT PRIMARY KEY,finished TEXT,faces INTEGER,without_faces INTEGER,reused INTEGER,computed INTEGER,state TEXT)')
            self.conn.execute('CREATE TABLE IF NOT EXISTS activity_events (id INTEGER PRIMARY KEY,stamp TEXT,message TEXT)')

    def log_activity(self,message):
        with self.lock,self.conn:
            self.conn.execute('INSERT INTO activity_events(stamp,message) VALUES(?,?)',(datetime.now().isoformat(timespec='seconds'),message))

    def recent_activity(self):
        with self.lock:return self.conn.execute('SELECT stamp,message FROM activity_events ORDER BY id DESC LIMIT 200').fetchall()

    def observed_signatures(self):
        import json
        with self.lock:return {key:tuple(json.loads(sig)) if sig else None for key,sig in self.conn.execute('SELECT key,signature FROM folder_observations')}

    def save_observations(self,observations):
        import json
        stamp=datetime.now().isoformat(timespec='seconds')
        with self.lock,self.conn:
            for path,sig in observations:
                key=path_key(path)
                self.conn.execute('INSERT INTO folder_observations VALUES(?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET signature=excluded.signature,last_seen=excluded.last_seen',
                    (key,path,json.dumps(sig) if sig is not None else None,stamp,stamp))

    def mark_changed(self,paths):
        with self.lock,self.conn:
            self.conn.executemany('INSERT OR IGNORE INTO discovered_folders VALUES(?)',[(path_key(path),) for path in paths])

    def folder_details(self,path):
        key=path_key(path)
        with self.lock:
            seen=self.conn.execute('SELECT first_seen,last_seen FROM folder_observations WHERE key=?',(key,)).fetchone()
            cache=self.conn.execute('SELECT finished,faces,without_faces,reused,computed,state FROM cache_details WHERE key=?',(key,)).fetchone()
        return seen,cache

    def record_cache_details(self,snapshot,face_counts,reused,computed,state):
        counts={key:[0,0,0,0] for key in snapshot.folders}
        for path in snapshot.ready_paths:
            folder=os.path.dirname(path);faces=face_counts.get(path_key(path),0)
            while is_within(folder,snapshot.root):
                key=path_key(folder)
                if key in counts:
                    row=counts[key];row[0]+=faces;row[1]+=int(faces==0);row[2]+=int(path_key(path) in reused);row[3]+=int(path_key(path) in computed)
                if key==path_key(snapshot.root):break
                folder=os.path.dirname(folder)
        stamp=datetime.now().isoformat(timespec='seconds')
        with self.lock,self.conn:
            self.conn.executemany('INSERT OR REPLACE INTO cache_details VALUES(?,?,?,?,?,?,?)',[(key,stamp,*values,state) for key,values in counts.items()])

    def discovered_keys(self):
        with self.lock:return {r[0] for r in self.conn.execute('SELECT key FROM discovered_folders')}

    def add_discovered(self,root,paths):
        with self.lock:
            owners=[key for key,path in self.conn.execute('SELECT key,path FROM roots') if is_within(root,path)]
        if not owners:self.register(root)
        with self.lock,self.conn:
            owners=[key for key,path in self.conn.execute('SELECT key,path FROM roots') if is_within(root,path)]
            owner=min(owners,key=len) if owners else path_key(root)
            known={r[0] for r in self.conn.execute('SELECT DISTINCT key FROM coverage')}
            added=0
            for path in paths:
                key=path_key(path)
                if key in known:continue
                self.conn.execute('INSERT OR IGNORE INTO coverage VALUES(?,?,?,?,?,?)',(owner,key,path,0,0,0))
                self.conn.execute('INSERT OR IGNORE INTO discovered_folders VALUES(?)',(key,))
                known.add(key);added+=1
            return added

    def register(self, root):
        with self.lock, self.conn:
            self.conn.execute('INSERT OR IGNORE INTO roots(key,path,state) VALUES(?,?,?)', (path_key(root), os.path.abspath(root), 'pending'))

    def set_state(self, root, state, message=''):
        self.register(root)
        with self.lock, self.conn:
            self.conn.execute('UPDATE roots SET state=?,message=? WHERE key=?', (state, message, path_key(root)))

    def recover_interrupted(self):
        with self.lock, self.conn:
            self.conn.execute("UPDATE roots SET state='interrupted' WHERE state IN ('scanning','inventory')")

    def save(self, snapshot, state, replace=False):
        self.register(snapshot.root)
        now = datetime.now().isoformat(timespec='seconds')
        root = path_key(snapshot.root)
        keys = list(snapshot.folders) if replace else list(snapshot.dirty)
        with self.lock, self.conn:
            if not self.conn.execute('SELECT 1 FROM coverage WHERE root=? LIMIT 1', (root,)).fetchone():
                keys = list(snapshot.folders)
            if replace:
                self.conn.execute('DELETE FROM coverage WHERE root=?', (root,))
                self.conn.execute('DELETE FROM file_failures WHERE root=?', (root,))
            self.conn.executemany('INSERT OR REPLACE INTO file_failures VALUES(?,?,?,?)',
                [(root,key,path,reason) for key,(path,reason) in snapshot.failures.items()])
            resolved=[(key,) for (key,) in self.conn.execute('SELECT DISTINCT key FROM file_failures')
                      if key in snapshot.ready_paths and key not in snapshot.failures]
            self.conn.executemany('DELETE FROM file_failures WHERE key=?',resolved)
            self.conn.executemany('INSERT OR REPLACE INTO coverage VALUES(?,?,?,?,?,?)', [
                (root, key, snapshot.folders[key]['path'], snapshot.folders[key]['total'], snapshot.folders[key]['indexed'], snapshot.folders[key]['errors']) for key in keys
            ])
            self.conn.executemany('DELETE FROM discovered_folders WHERE key=?',[(key,) for key in keys])
            self.conn.execute('UPDATE roots SET state=?, checked_at=?,message=? WHERE key=?', (state, now, '', root))
            if state == 'ready':
                self._consolidate_completed()
        if state in ('ready','interrupted','error'):
            from core.diagnostics import folder_checked
            folder_checked(snapshot.root,'Análise: '+state)
        snapshot.dirty.clear()

    def consolidate_completed(self):
        """Nest completed standalone searches under existing collection roots."""
        with self.lock, self.conn:
            self._consolidate_completed()

    def reconcile_inventory(self,snapshot):
        """A complete readable inventory supersedes nested snapshots, including removed paths."""
        if snapshot.failures:return
        root=path_key(snapshot.root)
        with self.lock,self.conn:
            children=[key for (key,) in self.conn.execute('SELECT key FROM roots') if key!=root and is_within(key,root)]
            stale=[(key,) for (key,) in self.conn.execute('SELECT key FROM discovered_folders') if is_within(key,root) and key not in snapshot.folders]
            self.conn.executemany('DELETE FROM discovered_folders WHERE key=?',stale)
            for child in children:
                self.conn.execute('DELETE FROM coverage WHERE root=?',(child,))
                self.conn.execute('DELETE FROM file_failures WHERE root=?',(child,))
                self.conn.execute('DELETE FROM roots WHERE key=?',(child,))

    def forget_missing_root(self,path):
        """Only forget a missing directory when its parent was successfully enumerated."""
        parent=os.path.dirname(os.path.abspath(path))
        if path_key(parent)==path_key(path):return False
        try:
            with os.scandir(parent) as entries:
                if any(entry.name.casefold()==os.path.basename(path).casefold() for entry in entries):return False
        except OSError:return False
        key=path_key(path)
        with self.lock,self.conn:
            self.conn.execute('DELETE FROM coverage WHERE root=?',(key,))
            self.conn.execute('DELETE FROM file_failures WHERE root=?',(key,))
            self.conn.execute('DELETE FROM roots WHERE key=?',(key,))
        return True

    def _consolidate_completed(self):
        before = self.conn.execute('SELECT count(*) FROM roots').fetchone()[0]
        # Deepest first lets an event complete its year before the year is merged.
        candidates = self.conn.execute(
            "SELECT r.key,r.path FROM roots r JOIN coverage c ON c.root=r.key AND c.key=r.key "
            "WHERE r.state='ready' AND c.total>0 AND c.indexed=c.total AND c.errors=0 "
            "ORDER BY length(r.key) DESC"
        ).fetchall()
        for child, child_path in candidates:
            source = self.conn.execute('SELECT key,path,total,indexed,errors FROM coverage WHERE root=?', (child,)).fetchall()
            summary = next((r for r in source if r[0] == child), None)
            if summary is None:
                continue
            ancestors = [(key, state) for key, state in self.conn.execute('SELECT key,state FROM roots').fetchall()
                         if key != child and is_within(child, key)]
            if not ancestors:
                continue  # Never hide a folder with no tracked parent to display it.
            if any(state in ('scanning', 'inventory', 'unavailable', 'pending') for _,state in ancestors):
                continue
            plans = []
            for parent, _ in ancestors:
                existing = {r[0]: r for r in self.conn.execute(
                    'SELECT key,path,total,indexed,errors FROM coverage WHERE root=?', (parent,)).fetchall()}
                if parent not in existing:
                    break
                old = existing.get(child, (child,child_path,0,0,0))
                delta = tuple(summary[i] - old[i] for i in (2,3,4))
                updates = []
                folder = os.path.dirname(child_path)
                valid = True
                while is_within(folder, parent):
                    key = path_key(folder)
                    previous = existing.get(key, (key,folder,0,0,0))
                    values = tuple(previous[i+2]+delta[i] for i in range(3))
                    if min(values) < 0 or values[1] > values[0]:
                        valid = False
                        break
                    updates.append((parent,key,previous[1],*values))
                    if key == parent:
                        break
                    folder = os.path.dirname(folder)
                if not valid:
                    break
                plans.append((parent,existing,updates))
            if len(plans) != len(ancestors):
                continue
            for parent, existing, updates in plans:
                self.conn.executemany('DELETE FROM coverage WHERE root=? AND key=?',
                    [(parent,key) for key in existing if is_within(key, child)])
                self.conn.executemany('INSERT OR REPLACE INTO coverage VALUES(?,?,?,?,?,?)',
                    [(parent,*row) for row in source] + updates)
                self.conn.execute('UPDATE roots SET message=? WHERE key=?',
                    (f'Progresso atualizado pela conclusão de {child_path}. A data indica a última conferência completa desta raiz.', parent))
            # This removes only duplicate history rows. Photos and facial cache are untouched.
            self.conn.execute('DELETE FROM coverage WHERE root=?', (child,))
            self.conn.execute('DELETE FROM roots WHERE key=?', (child,))

        after = self.conn.execute('SELECT count(*) FROM roots').fetchone()[0]
        if after < before:
            self._consolidate_completed()

    def records(self):
        with self.lock:
            roots = self.conn.execute('SELECT key,path,state,checked_at,message FROM roots ORDER BY path').fetchall()
            coverage = self.conn.execute('SELECT root,key,path,total,indexed,errors FROM coverage ORDER BY path').fetchall()
        return roots, coverage

    def failures_for(self, folder):
        with self.lock:
            rows=self.conn.execute('SELECT path,reason FROM file_failures').fetchall()
        return sorted({path:reason for path,reason in rows if is_within(path,folder)}.items())

    def close(self):
        with self.lock:
            self.conn.close()
