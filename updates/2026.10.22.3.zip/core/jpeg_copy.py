"""Correct a misleading RAW extension by making a byte-identical JPEG copy."""
from pathlib import Path
import shutil
from PIL import Image
from core.image_loader import standard_image_signature, RAW_EXTENSIONS


def copy_mislabeled_jpeg(path):
    source = Path(path)
    before = source.stat()
    if source.suffix.lower() not in RAW_EXTENSIONS or standard_image_signature(source) != 'JPEG':
        raise ValueError('O conteúdo deste arquivo não é JPEG com extensão RAW. Esta opção não converte nem repara dados RAW.')
    with Image.open(source) as image:
        if image.format != 'JPEG':raise ValueError('O arquivo não contém uma imagem JPEG.')
        image.load()
    number = 0
    while True:
        target = source.with_name(source.stem + (f' ({number})' if number else '') + '.jpg')
        try:
            output = target.open('xb');break
        except FileExistsError:
            number += 1
    try:
        with output, source.open('rb') as original:
            shutil.copyfileobj(original, output, 1024 * 1024)
        after = source.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise ValueError('O original mudou durante a cópia. Tente novamente.')
        shutil.copystat(source, target)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    return str(target)
