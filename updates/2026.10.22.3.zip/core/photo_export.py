"""Export RAW originals as bounded high-quality JPEG copies."""
import io
import os
from pathlib import Path
from PIL import Image
from core.image_loader import RAW_EXTENSIONS
from workers.face_export_worker import copy_unique

MAX_JPEG_BYTES=15_000_000


def bounded_jpeg(image,limit=MAX_JPEG_BYTES):
    image=image.convert('RGB')
    while True:
        # Keep the highest available quality and full dimensions whenever possible.
        for quality in (98,95,92,90,87,85):
            stream=io.BytesIO();image.save(stream,format='JPEG',quality=quality,subsampling=0,optimize=True)
            data=stream.getvalue()
            if len(data)<=limit:return data
        if min(image.size)<=1:raise ValueError('Não foi possível ajustar o JPEG ao limite de tamanho.')
        image=image.resize((max(1,round(image.width*.9)),max(1,round(image.height*.9))),Image.Resampling.LANCZOS)


def export_photo(path,destination,mtime,size):
    if Path(path).suffix.lower() not in RAW_EXTENSIONS:return copy_unique(path,destination,mtime,size)
    import rawpy
    source=Path(path);before=source.stat()
    if (before.st_mtime_ns,before.st_size)!=(mtime,size):raise ValueError('Arquivo alterado desde a busca; faça uma nova busca.')
    from core.image_loader import open_raw, standard_image_signature
    standard = standard_image_signature(source)
    if standard:
        with Image.open(source) as image:
            image.load()
            data = source.read_bytes() if standard == 'JPEG' and before.st_size <= MAX_JPEG_BYTES else bounded_jpeg(image)
    else:
        with open_raw(source) as raw:
            rgb=raw.postprocess(half_size=False,use_camera_wb=True,output_bps=8,output_color=rawpy.ColorSpace.sRGB)
        data=bounded_jpeg(Image.fromarray(rgb))
    after=source.stat()
    if (after.st_mtime_ns,after.st_size)!=(mtime,size):raise ValueError('Arquivo alterado durante a conversão.')
    number=0
    while True:
        target=Path(destination)/(source.stem+(f' ({number})' if number else '')+'.jpg')
        try:output=target.open('xb');break
        except FileExistsError:number+=1
    try:
        with output:output.write(data)
    except Exception:
        target.unlink(missing_ok=True);raise
    return str(target)
