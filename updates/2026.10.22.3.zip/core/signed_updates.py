"""Pinned Ed25519 source updates; no in-place code or database replacement."""
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import urllib.request
from urllib.parse import urlsplit
import uuid
import zipfile

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from core.release_identity import PUBLIC_KEY, REPOSITORY, CHANNEL_URL, SEQUENCE

MAX_PACKAGE=32*1024**2
MAX_EXPANDED=128*1024**2


def canonical(data):
    return json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')


def verify_envelope(raw):
    if len(raw)>1024**2: raise ValueError('Manifesto de atualização muito grande.')
    envelope=json.loads(raw); data=envelope['release']
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY,validate=True)).verify(
            base64.b64decode(envelope['signature'],validate=True),canonical(data))
    except Exception:
        raise ValueError('Assinatura da atualização inválida. Nenhum código foi instalado.') from None
    if (data['format']!=1 or data['repository']!=REPOSITORY or data['data_format']!=1
            or type(data['sequence']) is not int or data['sequence']<1
            or not re.fullmatch(r'[0-9]+(?:\.[0-9]+){3}',data['version'])
            or type(data['size']) is not int or not 0<data['size']<=MAX_PACKAGE
            or not re.fullmatch('[0-9a-f]{64}',data['sha256'])
            or not isinstance(data['files'],dict) or not 1<=len(data['files'])<=1000):
        raise ValueError('Manifesto incompatível.')
    expected='https://raw.githubusercontent.com/'+REPOSITORY+'/main/updates/'+data['version']+'.zip'
    if data['url']!=expected: raise ValueError('Origem de atualização não autorizada.')
    for name,entry in data['files'].items():
        safe_name(name)
        if type(entry['size']) is not int or entry['size']<0 or not re.fullmatch('[0-9a-f]{64}',entry['sha256']):
            raise ValueError('Inventário inválido.')
    if sum(e['size'] for e in data['files'].values())>MAX_EXPANDED:
        raise ValueError('Atualização excede o limite de tamanho.')
    if not {'main.py','requirements.txt','core/release_identity.py','ui/maintenance.py'}.issubset(data['files']):
        raise ValueError('Atualização incompleta.')
    if len(set(n.casefold() for n in data['files']))!=len(data['files']):
        raise ValueError('Caminhos duplicados.')
    return data


def safe_name(name):
    path=PurePosixPath(name)
    if ('\\' in name or ':' in name or path.is_absolute() or '..' in path.parts
            or str(path)!=name or any(p.endswith(('.', ' ')) or p.startswith('.') for p in path.parts)):
        raise ValueError('Caminho de atualização inválido.')
    if (len(path.parts)==1 and name in ('main.py','requirements.txt')): return
    if len(path.parts)>1 and path.parts[0] in ('core','ui','workers','logo') and path.suffix in ('.py','.qss','.qm','.png','.ico'):
        if any(re.fullmatch(r'(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?',p) for p in path.parts):
            raise ValueError('Nome reservado.')
        return
    raise ValueError('Arquivo não permitido no pacote de atualização.')


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        raise ValueError('Redirecionamento de atualização recusado.')


def download(url, limit, progress=lambda text: None):
    if not url.startswith('https://raw.githubusercontent.com/'+REPOSITORY+'/main/updates/'):
        raise ValueError('Origem não autorizada.')
    headers={'User-Agent':'Acervo-em-Foco-Updater','Accept-Encoding':'identity'}
    request=urllib.request.Request(url,headers=headers)
    result=bytearray()
    try:response=urllib.request.build_opener(_NoRedirect()).open(request,timeout=30)
    except urllib.error.HTTPError as error:
        if error.code in (401,403,404):
            raise ValueError('O canal de atualizações está indisponível. Tente novamente mais tarde.') from None
        raise
    with response:
        while chunk:=response.read(256*1024):
            result.extend(chunk)
            if len(result)>limit: raise ValueError('Download maior que o permitido.')
            progress(f'Baixando atualização: {len(result)//1024} KB')
    return bytes(result)


def install_root():
    default=Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[1]
    return Path(os.environ.get('ACERVO_INSTALL_ROOT',default)).resolve()


def application_command(*args):
    if getattr(sys,'frozen',False):return [sys.executable,*args]
    return [sys.executable,str(install_root()/'main.py'),*args]


def read_state(root):
    path=Path(root)/'.acervo-updates'/'state.json'
    if not path.exists(): return dict(active=None,previous=None,highest=SEQUENCE,pending=False,attempted=False)
    if path.is_symlink() or path.stat().st_size>65536: raise ValueError('Estado de atualização inválido.')
    state=json.loads(path.read_bytes())
    for key in ('active','previous'):
        if state[key] is not None and not re.fullmatch(r'[0-9]+(?:\.[0-9]+){3}',state[key]):
            raise ValueError('Versão local inválida.')
    if type(state['highest']) is not int: raise ValueError('Estado de atualização inválido.')
    return state


def write_state(root,state):
    folder=Path(root)/'.acervo-updates';folder.mkdir(exist_ok=True)
    temporary=folder/('state-'+uuid.uuid4().hex+'.tmp')
    try:
        with temporary.open('xb') as out:
            out.write(canonical(state));out.flush();os.fsync(out.fileno())
        os.replace(temporary,folder/'state.json')
    finally:
        if temporary.exists():temporary.unlink()


def check_update(root,progress=lambda text:None):
    raw=download(CHANNEL_URL,1024**2,progress)
    data=verify_envelope(raw)
    if data['sequence']<=max(SEQUENCE,read_state(root)['highest']): return None
    return raw


def verify_installed(root,version):
    folder=Path(root)/'.acervo-updates'/'versions'/version
    if folder.is_symlink() or folder.is_junction():raise ValueError('Versão redirecionada.')
    data=verify_envelope((folder/'release.json').read_bytes())
    if data['version']!=version:raise ValueError('Versão divergente.')
    actual={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if actual!=set(data['files'])|{'release.json'}:raise ValueError('Arquivos não assinados encontrados na versão instalada.')
    for name,entry in data['files'].items():
        path=folder/name
        if any(p.is_symlink() or p.is_junction() for p in (path,*path.parents) if p!=Path(p.anchor)):
            raise ValueError('Caminho redirecionado.')
        if path.stat().st_size!=entry['size'] or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
            raise ValueError('Arquivos da atualização foram alterados.')
    return folder


def install_update(root,raw,progress=lambda text:None, fetch=download, probe=True):
    root=Path(root).resolve();data=verify_envelope(raw);state=read_state(root)
    if data['sequence']<=max(SEQUENCE,state['highest']):raise ValueError('Versão antiga ou já instalada.')
    if data['requirements_sha256']!=hashlib.sha256((root/'requirements.txt').read_bytes()).hexdigest():
        raise ValueError('Esta versão exige novas dependências. Faça uma instalação assistida; nada foi substituído.')
    if sys.version_info[:2]<tuple(data['python_min']): raise ValueError('Versão do Python incompatível.')
    versions=root/'.acervo-updates'/'versions';versions.mkdir(parents=True,exist_ok=True)
    final=versions/data['version']
    if final.exists():raise ValueError('Já existe uma cópia desta versão. Preserve-a e solicite suporte.')
    if shutil.disk_usage(root).free<MAX_EXPANDED+MAX_PACKAGE:raise ValueError('Espaço insuficiente.')
    payload=fetch(data['url'],data['size'],progress)
    if len(payload)!=data['size'] or hashlib.sha256(payload).hexdigest()!=data['sha256']:
        raise ValueError('Download incompleto ou alterado. Nenhum código foi instalado.')
    temporary=versions/('.download-'+uuid.uuid4().hex);temporary.mkdir()
    import io
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        members=archive.infolist()
        if len(members)!=len(data['files']) or {m.filename for m in members}!=set(data['files']):
            raise ValueError('Conteúdo do pacote divergente.')
        for member in members:
            name=member.filename;safe_name(name);entry=data['files'][name]
            if member.file_size!=entry['size'] or member.is_dir() or member.flag_bits&1 or (member.external_attr>>16)&0o170000==0o120000:
                raise ValueError('Arquivo de atualização inválido.')
            content=archive.read(member)
            if hashlib.sha256(content).hexdigest()!=entry['sha256']:raise ValueError('Arquivo de atualização alterado.')
            target=temporary/name;target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as out:out.write(content)
    (temporary/'release.json').write_bytes(raw)
    # Import only authenticated code, in a separate process. No application
    # objects or live databases are opened by this probe.
    if probe and getattr(sys,'frozen',False):
        for name,content in data['files'].items():
            if name.endswith('.py'):compile((temporary/name).read_bytes(),name,'exec')
    elif probe:
        progress('Conferindo os componentes da nova versão…')
        result=subprocess.run([sys.executable,'-c','import ui.maintenance; import ui.main_window'],cwd=temporary,
                              capture_output=True,timeout=90,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:raise ValueError('A nova versão não passou no teste de abertura dos componentes.')
    temporary.rename(final)
    verify_installed(root,data['version'])
    state.update(previous=state['active'],active=data['version'],highest=data['sequence'],pending=True,attempted=False)
    write_state(root,state)
    return 'Atualização instalada. Abra o programa para concluir. A versão anterior foi preservada.'


def rollback(root):
    state=read_state(root)
    if state['active'] is None:raise ValueError('Você já está na versão original desta instalação.')
    previous=state['previous']
    if previous is not None:verify_installed(root,previous)
    state.update(active=previous,previous=None,pending=False,attempted=False)
    write_state(root,state)
    return 'Versão anterior selecionada. Os bancos e as fotos não foram alterados.'


def mark_healthy():
    root=install_root(); state=read_state(root)
    if state['active'] and Path(__file__).resolve().parents[1]==root/'.acervo-updates'/'versions'/state['active']:
        state.update(pending=False,attempted=False);write_state(root,state)
