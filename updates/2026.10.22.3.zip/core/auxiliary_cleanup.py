"""Conservative classification: only the audited, byte-identical metadata is eligible."""
import hashlib
import os

AUDITED_DIGEST='1d95d4902d48264109fe13c7395ebacf18c14310ab9a10384f701b966b4d55ae'

def inspect_auxiliary(path):
    if not os.path.basename(path).startswith('._') or os.path.islink(path):return None
    stat=os.stat(path)
    with open(path,'rb') as stream:
        if stream.read(4)!=b'\x00\x05\x16\x07':return None
        stream.seek(0)
        digest=hashlib.sha256(stream.read()).hexdigest() if stat.st_size==4096 else None
    original=os.path.join(os.path.dirname(path),os.path.basename(path)[2:])
    safe=digest==AUDITED_DIGEST and os.path.isfile(original) and not os.path.islink(original)
    return dict(path=path,size=stat.st_size,digest=digest,safe=safe,
                reason='Padrão examinado; original presente' if safe else 'Conteúdo diferente ou original ausente — preservar para revisão')

def trash_auxiliary(record,journal):
    from send2trash import send2trash
    current=inspect_auxiliary(record['path'])
    if not current or not current['safe'] or current['digest']!=record['digest']:
        raise ValueError('O arquivo mudou ou não atende aos critérios de limpeza.')
    rid=journal.begin(current['path'],current['size'],current['digest'])
    try:send2trash(current['path'])
    except Exception as exc:
        journal.finish(rid,str(exc));raise
    journal.finish(rid)
    return current['size']
