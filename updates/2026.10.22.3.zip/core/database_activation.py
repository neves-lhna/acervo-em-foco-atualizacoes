"""Journaled activation of previously validated SQLCipher copies.

All entry points require the edition's application.lock. No application may
open databases while database-activation.json exists. Originals are retained
on success; interrupted swaps are restored before normal startup.
"""
import base64
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import uuid

from core.key_protection import unprotect_local
from core.secure_database import connect_encrypted

MARKER = 'database-activation.json'
ACTIVE = 'database-security.json'
PENDING = 'database-security.pending.json'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _write_new(path, payload):
    with path.open('xb') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def _regular(path):
    if path.is_symlink() or path.is_junction() or not path.is_file():
        raise ValueError('Arquivo indisponível ou redirecionado: ' + path.name)


def _key(record, profile, state):
    if record['version'] != 1 or record['profile'] != profile or record['state'] != state:
        raise ValueError('Configuração de proteção incompatível.')
    return unprotect_local(base64.b64decode(record['local_key'], validate=True), profile)


def _verify_open(root, names, key):
    for name in names:
        _regular(root/name)
        with closing(connect_encrypted(root/name, key, readonly=True)) as connection:
            connection.execute('SELECT count(*) FROM sqlite_master').fetchone()


def reconcile(root, profile, progress=lambda text: None):
    """Finish a committed swap or roll back an interrupted one, with lock held.

    Safe to retry if rollback itself is interrupted. Never removes backups.
    """
    root = Path(root).resolve()
    marker = root/MARKER
    if not marker.exists():
        return None
    _regular(marker)
    if marker.stat().st_size > 65536:
        raise ValueError('Registro de ativação inválido.')
    record = json.loads(marker.read_bytes())
    names = record['names']
    files = record['files']
    if (record['version'] != 1 or record['profile'] != profile
            or not re.fullmatch(r'\.activation-[0-9a-f]{32}', record['directory'])
            or not names or len(names) != len(set(names))
            or any(not re.fullmatch(r'[A-Za-z0-9_]+\.db', name) for name in names)
            or len(files) != len(set(files))
            or not set(names).issubset(files)
            or any(name not in {n+s for n in names for s in ('', '-wal', '-shm', '-journal')} for name in files)):
        raise ValueError('Registro de ativação inválido; abertura bloqueada.')
    transaction = root/record['directory']
    backup = transaction/'originals'
    for directory in (transaction, backup):
        if directory.is_symlink() or directory.is_junction() or not directory.is_dir():
            raise ValueError('Pasta de restauração indisponível; abertura bloqueada.')
    active = root/ACTIVE
    if active.exists():
        _regular(active)
        if digest(active) != record['manifest_sha256']:
            raise ValueError('Configuração ativa inesperada; nenhuma restauração automática realizada.')
        # Manifest replacement is the commit point. No app opened the databases
        # yet because the marker gates connection routing and startup.
        progress('Conferindo a ativação concluída…')
        key = _key(json.loads(active.read_bytes()), profile, 'encrypted')
        _verify_open(root, names, key)
        marker.unlink()
        return 'committed'
    progress('Restaurando os bancos anteriores após interrupção…')
    for name in files:
        saved = backup/name
        if saved.exists():
            _regular(saved)
            os.replace(saved, root/name)
        elif not (root/name).is_file():
            raise ValueError('Arquivo necessário à restauração ausente: ' + name)
    marker.unlink()
    return 'restored'


def activate(root, stage, profile, progress=lambda text: None, checkpoint=lambda event: None):
    """Activate validated copies; caller must hold application.lock throughout.

    The report is a local preparation artifact, not a downloaded trust source.
    Stale originals/WAL, altered ciphertext or a different preparation abort
    before any live database is moved.
    """
    root, stage = Path(root).resolve(), Path(stage).resolve()
    if (root/MARKER).exists() or (root/ACTIVE).exists():
        raise ValueError('Já há ativação em andamento ou proteção ativa.')
    pending = (root/PENDING).read_bytes()
    preparation = json.loads(pending)
    key = _key(preparation, profile, 'prepared')
    report = json.loads((stage/'validation.json').read_bytes())
    names = sorted(report['databases'])
    if (report['state'] != 'verified' or report['profile'] != profile
            or report['preparation_sha256'] != hashlib.sha256(pending).hexdigest()
            or not names or any(not re.fullmatch(r'[A-Za-z0-9_]+\.db', name) for name in names)
            or names != sorted(path.name for path in root.glob('*.db'))):
        raise ValueError('Cópias ou preparação não correspondem ao conjunto atual de bancos.')
    required = sum(report['databases'][name]['bytes'] for name in names) + 256*1024**2
    if shutil.disk_usage(root).free < required:
        raise ValueError('Espaço insuficiente para ativar preservando os originais.')

    def verify_sources():
        for name in names:
            _regular(root/name)
            entry = report['databases'][name]
            progress('Conferindo banco atual: ' + name)
            if digest(root/name) != entry['source_sha256']:
                raise ValueError('O banco mudou desde a preparação: ' + name + '. Gere uma nova cópia validada.')
            wal = root/(name+'-wal')
            if wal.exists():
                _regular(wal)
            wal_hash = digest(wal) if wal.exists() and wal.stat().st_size else None
            if wal_hash != entry.get('source_wal_sha256'):
                raise ValueError('Há alterações recentes no banco: ' + name + '. Gere uma nova cópia validada.')
            journal = root/(name+'-journal')
            if journal.exists() and journal.stat().st_size:
                raise ValueError('Transação SQLite pendente: ' + name)

    verify_sources()
    transaction = root/('.activation-' + uuid.uuid4().hex)
    transaction.mkdir()
    new = transaction/'encrypted'; new.mkdir()
    backup = transaction/'originals'; backup.mkdir()
    for name in names:
        progress('Preparando banco protegido: ' + name)
        _regular(stage/name)
        entry = report['databases'][name]
        with (stage/name).open('rb') as source, (new/name).open('xb') as target:
            shutil.copyfileobj(source, target, 4*1024*1024)
            target.flush(); os.fsync(target.fileno())
        if (new/name).stat().st_size != entry['bytes'] or digest(new/name) != entry['encrypted_sha256']:
            raise ValueError('A cópia criptografada não passou na conferência: ' + name)
    _verify_open(new, names, key)
    verify_sources()
    if (root/PENDING).read_bytes() != pending:
        raise ValueError('A preparação mudou. Ativação interrompida.')
    active_bytes = json.dumps(dict(preparation, state='encrypted', databases=names), indent=2).encode('utf-8')
    _write_new(transaction/'active.json', active_bytes)
    files = [name+suffix for name in names for suffix in ('', '-wal', '-shm', '-journal')
             if (root/(name+suffix)).exists()]
    for name in files:
        _regular(root/name)
    journal = dict(version=1, profile=profile, directory=transaction.name, names=names, files=files,
                   manifest_sha256=hashlib.sha256(active_bytes).hexdigest())
    # Publish a complete marker atomically BEFORE the first original is moved.
    _write_new(transaction/'journal.json', json.dumps(journal).encode('utf-8'))
    os.replace(transaction/'journal.json', root/MARKER)
    try:
        checkpoint('journal')
        for name in files:
            os.replace(root/name, backup/name)
            checkpoint('saved:'+name)
        for name in names:
            os.replace(new/name, root/name)
            checkpoint('installed:'+name)
        _verify_open(root, names, key)
        checkpoint('verified')
        os.replace(transaction/'active.json', root/ACTIVE)
        checkpoint('committed')
    except Exception:
        reconcile(root, profile, progress)
        raise
    reconcile(root, profile, progress)
    progress('Proteção ativada. Os bancos originais foram preservados para restauração.')
    return backup
