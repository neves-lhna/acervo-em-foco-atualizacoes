"""Separate editions while retaining the original professional data location."""
import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AppProfile:
    key: str
    label: str
    directory: str
    settings_name: str

    @property
    def title(self):
        return f'Acervo em Foco — {self.label}'

    def data_directory(self):
        return Path.home() / self.directory


PROFILES = {
    'dcta': AppProfile('dcta', 'Acervo DCTA', '.face_search_app', 'AcervoEmFoco'),
    'pessoal': AppProfile('pessoal', 'Acervo pessoal', '.face_search_app_pessoal', 'AcervoEmFocoPessoal'),
}


def current_profile():
    key = os.environ.get('ACERVO_PROFILE', 'pessoal')
    if key not in PROFILES:
        raise ValueError(f'Edição desconhecida: {key}')
    return PROFILES[key]
