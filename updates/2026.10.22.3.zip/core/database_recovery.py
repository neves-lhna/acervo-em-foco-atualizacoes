"""Rebind an existing encrypted archive to this Windows account.

The caller must hold application.lock and have no database connections open.
This does not activate pending encryption or modify database contents.
"""
import base64
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import tempfile

from core.key_protection import protect_local, unprotect_local, unwrap_recovery
from core.secure_database import connect_encrypted


def recover(root, profile, recovery_path, password, progress=lambda message: None):
    root = Path(root).resolve()
    manifest = root / 'database-security.json'
    with manifest.open('rb') as stream:
        original = stream.read(65537)
    if len(original) > 65536:
        raise ValueError('Configuração de proteção inválida. Preserve os bancos e restaure um backup completo.')
    try:
        record = json.loads(original)
        if record['version'] != 1 or record['state'] != 'encrypted' or record['profile'] != profile:
            raise ValueError()
    except (ValueError, KeyError, TypeError):
        raise ValueError('A configuração não corresponde a bancos protegidos desta edição.') from None
    with Path(recovery_path).open('rb') as stream:
        envelope = stream.read(4097)
    if len(envelope) > 4096:
        raise ValueError('Arquivo de recuperação inválido.')
    expected = record.get('recovery_sha256')
    if expected and hashlib.sha256(envelope).hexdigest() != expected:
        raise ValueError('Este arquivo de recuperação não corresponde a este banco de dados.')
    progress('Desbloqueando a chave de recuperação…')
    key = unwrap_recovery(envelope, password, profile)
    databases = sorted(root.glob('*.db'))
    if not databases:
        raise ValueError('Nenhum banco encontrado. Restaure o conjunto completo antes de recuperar o acesso.')
    # Later features may create additional encrypted stores (e.g. extension
    # review). Require every original store and validate all extra stores too.
    if 'databases' in record and not set(record['databases']).issubset(path.name for path in databases):
        raise ValueError('O conjunto de bancos está incompleto ou diferente. Restaure o backup completo.')
    for index, path in enumerate(databases, 1):
        if path.is_symlink() or not path.is_file():
            raise ValueError('Local de banco inválido.')
        progress(f'Conferindo acesso ao banco {index} de {len(databases)}…')
        # Read-only: a wrong key or mixed/incomplete installation must never
        # replace the account binding. Full integrity was checked at conversion.
        with closing(connect_encrypted(path, key, readonly=True)) as connection:
            connection.execute('SELECT count(*) FROM sqlite_master').fetchone()
    progress('Protegendo a chave para esta conta do Windows…')
    local = protect_local(key, profile)
    if unprotect_local(local, profile) != key:
        raise RuntimeError('Falha ao conferir a proteção local.')
    updated = dict(record, local_key=base64.b64encode(local).decode('ascii'))
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='wb', dir=root, prefix='.recovery-', suffix='.tmp', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(json.dumps(updated, indent=2).encode('utf-8'))
            stream.flush()
            os.fsync(stream.fileno())
        if manifest.read_bytes() != original:
            raise RuntimeError('A configuração mudou durante a recuperação. Tente novamente com o aplicativo fechado.')
        # A crash before replace leaves the old binding; after replace the new
        # binding is complete. Only a DPAPI-protected blob is written to disk.
        os.replace(temporary, manifest)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return len(databases)
