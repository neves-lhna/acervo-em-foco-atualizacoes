"""Opt-in key protection primitives. Not yet enabled for application databases.

DPAPI protects against other accounts, not malware running as the same user.
Python cannot guarantee erasure of every in-memory copy of a secret.
"""
import base64
import ctypes
import json
import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


def _context(profile):
    if profile not in ('dcta', 'pessoal'):
        raise ValueError('Edição inválida')
    return ('Acervo/key-recovery/v1/' + profile).encode('ascii')


def _password_key(password, salt):
    if not isinstance(password, str) or not 16 <= len(password) <= 1024:
        raise ValueError('Use uma senha de recuperação com pelo menos 16 caracteres')
    return Scrypt(salt=salt, length=32, n=2**17, r=8, p=1).derive(password.encode('utf-8'))


def wrap_recovery(key, password, profile):
    context = _context(profile)
    if not isinstance(key, bytes) or len(key) != 32:
        raise ValueError('Chave inválida')
    salt, nonce = os.urandom(16), os.urandom(12)
    ciphertext = AESGCM(_password_key(password, salt)).encrypt(nonce, key, context)
    return json.dumps({'version': 1, 'profile': profile,
                       'salt': base64.b64encode(salt).decode('ascii'),
                       'nonce': base64.b64encode(nonce).decode('ascii'),
                       'ciphertext': base64.b64encode(ciphertext).decode('ascii')}).encode('utf-8')


def unwrap_recovery(envelope, password, profile):
    context = _context(profile)
    try:
        if len(envelope) > 4096:
            raise ValueError()
        data = json.loads(envelope)
        if data['version'] != 1 or data['profile'] != profile:
            raise ValueError()
        salt, nonce, ciphertext = (base64.b64decode(data[k], validate=True)
                                   for k in ('salt', 'nonce', 'ciphertext'))
        if (len(salt), len(nonce), len(ciphertext)) != (16, 12, 48):
            raise ValueError()
        return AESGCM(_password_key(password, salt)).decrypt(nonce, ciphertext, context)
    except Exception:
        raise ValueError('Senha incorreta ou arquivo de recuperação inválido') from None


def _dpapi(data, profile, decrypt=False):
    if os.name != 'nt':
        raise OSError('Proteção local requer Windows')
    context = _context(profile)
    if not isinstance(data, bytes) or not 0 < len(data) <= 16384:
        raise ValueError('Dados inválidos')
    class Blob(ctypes.Structure):
        _fields_ = [('size', ctypes.c_ulong), ('data', ctypes.POINTER(ctypes.c_ubyte))]
    source_buffer = ctypes.create_string_buffer(data)
    entropy_buffer = ctypes.create_string_buffer(context)
    source = Blob(len(data), ctypes.cast(source_buffer, ctypes.POINTER(ctypes.c_ubyte)))
    entropy = Blob(len(context), ctypes.cast(entropy_buffer, ctypes.POINTER(ctypes.c_ubyte)))
    output = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    fn = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.POINTER(Blob),
                   ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(Blob)]
    fn.restype = ctypes.c_int
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    # CRYPTPROTECT_UI_FORBIDDEN; no machine-wide scope.
    if not fn(ctypes.byref(source), None, ctypes.byref(entropy), None, None, 1, ctypes.byref(output)):
        raise OSError('O Windows não conseguiu proteger/desbloquear a chave local')
    try:
        return ctypes.string_at(output.data, output.size)
    finally:
        ctypes.memset(output.data, 0, output.size)
        kernel.LocalFree(output.data)


def protect_local(key, profile):
    if not isinstance(key, bytes) or len(key) != 32:
        raise ValueError('Chave inválida')
    return _dpapi(key, profile)


def unprotect_local(blob, profile):
    key = _dpapi(blob, profile, decrypt=True)
    if len(key) != 32:
        raise ValueError('Chave inválida')
    return key
