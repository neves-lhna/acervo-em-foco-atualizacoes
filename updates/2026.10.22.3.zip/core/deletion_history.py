"""Persistent deletion journal; never infer permanent deletion from an offline drive."""
import os
from core import database as sqlite3
import hashlib
from datetime import datetime,timezone


def now():return datetime.now().isoformat(timespec='seconds')
def normalized(path):return os.path.normcase(os.path.realpath(path))


class DeletionHistory:
    def __init__(self,path):
        self.path=path
        self.db=sqlite3.connect(path,timeout=10)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('''CREATE TABLE IF NOT EXISTS deletions(
            id INTEGER PRIMARY KEY,path TEXT NOT NULL,deleted TEXT,size INTEGER,digest TEXT,
            state TEXT NOT NULL,bin_path TEXT,missing_since TEXT,restored TEXT,error TEXT)''')
        self.db.commit()

    def begin(self,path,size,digest):
        with self.db:
            return self.db.execute('INSERT INTO deletions(path,deleted,size,digest,state) VALUES(?,?,?,?,?)',
                (path,now(),size,digest,'Preparando exclusão')).lastrowid

    def finish(self,rid,error=None):
        with self.db:self.db.execute('UPDATE deletions SET state=?,error=? WHERE id=?',
            ('Falha na exclusão' if error else 'Aguardando consulta',error,rid))

    def import_previous(self,duplicates):
        paths=duplicates.execute("SELECT DISTINCT path FROM files WHERE state='Na Lixeira'").fetchall()
        with self.db:
            for (path,) in paths:
                if not self.db.execute('SELECT 1 FROM deletions WHERE path=?',(path,)).fetchone():
                    self.db.execute("INSERT INTO deletions(path,state) VALUES(?,'Registro anterior')",(path,))

    def rows(self):
        return self.db.execute('SELECT id,path,deleted,size,digest,state,bin_path,missing_since,restored,error FROM deletions ORDER BY id DESC').fetchall()

    def refresh(self,entries):
        used=set()
        by_path={}
        for entry in entries:
            by_path.setdefault(normalized(entry['original']),[]).append(entry)
        for rid,path,deleted,size,digest,state,bin_path,missing,restored,error in self.rows():
            if state in ('Restaurada','Falha na exclusão'):continue
            matches=[e for e in by_path.get(normalized(path),[]) if e['key'] not in used
                     and (size is None or size==e['size']) and (not bin_path or bin_path==e['key'])]
            if not bin_path and digest:
                verified=[]
                for entry in matches:
                    try:
                        with open(entry['key'],'rb') as stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
                        if actual==digest:verified.append(entry)
                    except OSError:pass
                matches=verified
            if len(matches)==1:
                item=matches[0];used.add(item['key'])
                with self.db:self.db.execute("UPDATE deletions SET state='Na Lixeira',bin_path=?,deleted=COALESCE(deleted,?),size=COALESCE(size,?),missing_since=NULL WHERE id=?",
                    (item['key'],item['deleted'],item['size'],rid))
            elif len(matches)>1:
                with self.db:self.db.execute("UPDATE deletions SET state='Correspondência ambígua' WHERE id=?",(rid,))
            else:
                drive=os.path.splitdrive(path)[0]
                online=os.path.isdir(drive+os.sep) if drive else os.path.isdir(os.path.dirname(path))
                new_state='Unidade indisponível' if not online else ('Arquivo presente na pasta' if os.path.isfile(path) else 'Não encontrado na Lixeira')
                observed=(missing or now()) if online and not os.path.isfile(path) else missing
                with self.db:self.db.execute('UPDATE deletions SET state=?,missing_since=? WHERE id=?',(new_state,observed,rid))


def recycle_entries():
    import comtypes.client
    shell=comtypes.client.CreateObject('Shell.Application',dynamic=True)
    folder=shell.NameSpace(10)
    if folder is None:raise OSError('Não foi possível consultar a Lixeira do Windows.')
    items=folder.Items();entries=[]
    for index in range(items.Count):
        item=items.Item(index)
        origin=item.ExtendedProperty('System.Recycle.DeletedFrom')
        name=item.ExtendedProperty('System.FileName')
        if not origin or not name or item.IsFolder:continue
        date=item.ExtendedProperty('System.Recycle.DateDeleted')
        if isinstance(date,datetime):date=date.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)
        entries.append(dict(key=str(item.Path),original=os.path.join(str(origin),str(name)),
            size=int(item.Size),deleted=date.isoformat(timespec='seconds') if hasattr(date,'isoformat') else str(date),item=item))
    return entries


def restore_entry(entry,path):
    if os.path.exists(path):raise OSError('Já existe um arquivo nesse destino. Nenhum arquivo foi substituído.')
    if normalized(entry['original'])!=normalized(path):raise OSError('A origem do item não corresponde ao registro.')
    verbs=entry['item'].Verbs()
    for index in range(verbs.Count):
        verb=verbs.Item(index)
        if verb.Name.replace('&','').strip().casefold() in ('restaurar','restore'):
            verb.DoIt();return
    raise OSError('O Windows não disponibilizou a ação Restaurar para esta foto.')
