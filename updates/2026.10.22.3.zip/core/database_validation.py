"""Content comparison for a staged migration, independent of physical row IDs."""
import hashlib
import struct


def schema(connection):
    return connection.execute("SELECT type,name,tbl_name,sql FROM sqlite_master "
                              "WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").fetchall()


def table_fingerprint(connection, table, progress=lambda count: None):
    quoted = '"' + table.replace('"', '""') + '"'
    cursor = connection.execute('SELECT * FROM ' + quoted)
    hashes = []
    try:
        for row in cursor:
            digest = hashlib.sha256()
            for value in row:
                if value is None:
                    tag, encoded = b'N', b''
                elif isinstance(value, int):
                    tag, encoded = b'I', str(value).encode('ascii')
                elif isinstance(value, float):
                    tag, encoded = b'F', struct.pack('>d', value)
                elif isinstance(value, str):
                    tag, encoded = b'T', value.encode('utf-8')
                elif isinstance(value, bytes):
                    tag, encoded = b'B', value
                else:
                    raise TypeError('Tipo de dado não suportado para comparação')
                digest.update(tag)
                digest.update(len(encoded).to_bytes(8, 'big'))
                digest.update(encoded)
            hashes.append(digest.digest())
            if len(hashes) % 10000 == 0:
                progress(len(hashes))
    finally:
        cursor.close()
    # Export may renumber implicit rowids. Sort bounded-size hashes rather than
    # whole rows/BLOBs, retaining duplicates and avoiding SQL sort temp files.
    hashes.sort()
    total = hashlib.sha256()
    for digest in hashes:
        total.update(digest)
    return {'rows': len(hashes), 'sha256': total.hexdigest()}


def compare_contents(original, encrypted, progress=lambda stage: None):
    if schema(original) != schema(encrypted):
        raise ValueError('A estrutura do banco convertido difere da origem')
    names = [row[0] for row in original.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND (name NOT LIKE 'sqlite_%' OR name='sqlite_sequence') ORDER BY name")]
    results = {}
    for name in names:
        progress('Conferindo registros originais: ' + name)
        before = table_fingerprint(original, name, lambda n: progress(f'Originais: {name}, {n} registros'))
        progress('Conferindo registros criptografados: ' + name)
        after = table_fingerprint(encrypted, name, lambda n: progress(f'Criptografados: {name}, {n} registros'))
        if before != after:
            raise ValueError('Os registros do banco convertido diferem da origem')
        results[name] = before
    return results
