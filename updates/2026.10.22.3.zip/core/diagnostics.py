"""Password-protected diagnostics. Public-key writes never need the creator password."""
import base64,json,os,threading,traceback
from collections import deque
from datetime import datetime
from pathlib import Path
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def b64(value):return base64.b64encode(value).decode('ascii')
def un64(value):return base64.b64decode(value,validate=True)
def oaep():return padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),algorithm=hashes.SHA256(),label=None)


class DiagnosticLog:
    def __init__(self,directory,max_bytes=10*1024*1024):
        self.directory=Path(directory);self.key_path=self.directory/'creator-key.json'
        self.path=self.directory/'activity.enc';self.max_bytes=max_bytes
        self.lock=threading.RLock();self.pending=deque(maxlen=2000);self.public=None
        if self.key_path.exists():
            config=json.loads(self.key_path.read_text(encoding='utf-8'))
            self.public=serialization.load_pem_public_key(config['public'].encode())

    @property
    def configured(self):return self.public is not None

    def configure(self,password):
        if len(password)<12:raise ValueError('Use pelo menos 12 caracteres.')
        with self.lock:
            if self.key_path.exists():raise ValueError('A senha já foi configurada.')
            key=rsa.generate_private_key(public_exponent=65537,key_size=3072)
            public=key.public_key()
            config={'public':public.public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo).decode(),
                'private':key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.BestAvailableEncryption(password.encode())).decode()}
            self.directory.mkdir(parents=True,exist_ok=True)
            with self.key_path.open('x',encoding='utf-8') as f:json.dump(config,f)
            self.public=public
            for record in self.pending:self._write(record)
            self.pending.clear()

    def append(self,kind,folder='',error='',image='',stage=''):
        if kind not in ('folder','error'):return
        record={'when':datetime.now().isoformat(timespec='seconds'),'kind':kind,'stage':stage,'folder':str(folder)}
        if kind=='error':record.update(error=str(error),image=str(image))
        with self.lock:
            if not self.configured:self.pending.append(record);return
            self._write(record)

    def _write(self,record):
        secret=AESGCM.generate_key(bit_length=256);nonce=os.urandom(12)
        payload=AESGCM(secret).encrypt(nonce,json.dumps(record,ensure_ascii=False).encode(),b'acervo-log-v1')
        line=json.dumps({'key':b64(self.public.encrypt(secret,oaep())),'nonce':b64(nonce),'data':b64(payload)})+'\n'
        self.directory.mkdir(parents=True,exist_ok=True)
        if self.path.exists() and self.path.stat().st_size+len(line)>self.max_bytes:
            for i in range(3,0,-1):
                source=self.path.with_suffix(f'.enc.{i}')
                if source.exists():
                    if i==3:source.unlink()
                    else:source.replace(self.path.with_suffix(f'.enc.{i+1}'))
            self.path.replace(self.path.with_suffix('.enc.1'))
        with self.path.open('a',encoding='utf-8') as f:f.write(line)

    def read(self,password,limit=2000):
        config=json.loads(self.key_path.read_text(encoding='utf-8'))
        key=serialization.load_pem_private_key(config['private'].encode(),password=password.encode())
        with self.lock:
            lines=deque(maxlen=limit)
            for path in [self.path.with_suffix(f'.enc.{i}') for i in (3,2,1)]+[self.path]:
                if path.exists():
                    with path.open(encoding='utf-8') as f:lines.extend(f)
        records=[]
        for line in lines:
            try:
                row=json.loads(line);secret=key.decrypt(un64(row['key']),oaep())
                records.append(json.loads(AESGCM(secret).decrypt(un64(row['nonce']),un64(row['data']),b'acervo-log-v1')))
            except Exception:
                records.append({'when':'','kind':'error','error':'Registro danificado ou de outra chave; conteúdo não lido.'})
        return records

_store=None
_listener=None

def initialize(directory,listener=None):
    global _store,_listener
    _store=DiagnosticLog(directory);_listener=listener
    return _store

def notify(message):
    if _listener:_listener(str(message))

def record(kind,folder='',error='',image='',stage=''):
    try:
        if _store:_store.append(kind,folder,error,image,stage)
    except Exception:
        notify('Não foi possível gravar o log técnico. Verifique espaço e acesso à pasta de dados.')
    if kind=='error':notify('Foi encontrado um erro: '+str(error).splitlines()[0][:220])

def folder_checked(folder,stage='Verificação'):record('folder',folder=folder,stage=stage)
def image_error(path,error,stage='Imagem'):record('error',folder=os.path.dirname(str(path)),image=os.path.basename(str(path)),error=error,stage=stage)
def program_error(error,stage='Programa'):record('error',error=error,stage=stage)

def install_exception_hooks():
    import sys,logging
    def hook(kind,value,tb):
        if issubclass(kind,KeyboardInterrupt):return sys.__excepthook__(kind,value,tb)
        program_error(''.join(traceback.format_exception(kind,value,tb)),'Exceção não tratada')
    sys.excepthook=hook
    threading.excepthook=lambda args:hook(args.exc_type,args.exc_value,args.exc_traceback)
    class Handler(logging.Handler):
        def emit(self,entry):
            program_error(self.format(entry),entry.name)
    logging.getLogger().addHandler(Handler(level=logging.ERROR))
