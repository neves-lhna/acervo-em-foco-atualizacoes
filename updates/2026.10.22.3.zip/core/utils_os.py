"""
core/utils_os.py
------------------
Utilitário multiplataforma para "Abrir na pasta" / "Mostrar no
gerenciador de arquivos", replicando o comportamento nativo de cada SO
(Explorer no Windows já seleciona o arquivo; Finder no macOS também;
no Linux o comportamento varia por gerenciador de arquivos, então
usamos um fallback razoável).
"""

from __future__ import annotations

import os
import platform
import subprocess


def reveal_in_file_manager(file_path: str) -> None:
    """Abre o gerenciador de arquivos do SO com o arquivo selecionado
    (quando o SO/gerenciador suporta), ou ao menos abre a pasta que o
    contém."""
    file_path = os.path.abspath(file_path)
    system = platform.system()

    if system == "Windows":
        try:
            _select_windows_file(file_path)
        except (OSError, ValueError) as exc:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(None, 'Abrir na pasta', f'Não foi possível selecionar o arquivo no Explorer.\n{file_path}\n\n{exc}')

    elif system == "Darwin":  # macOS
        # -R ("reveal") seleciona o arquivo dentro do Finder.
        subprocess.run(["open", "-R", file_path])

    else:  # Linux e afins
        folder = os.path.dirname(file_path)
        # Gerenciadores de arquivo populares no Linux que suportam
        # selecionar um arquivo específico via linha de comando.
        candidates = [
            ["nautilus", "--select", file_path],   # GNOME Files
            ["dolphin", "--select", file_path],     # KDE Dolphin
            ["nemo", file_path],                     # Cinnamon
            ["thunar", folder],                      # XFCE (sem seleção)
        ]
        for cmd in candidates:
            try:
                subprocess.run(cmd, check=True)
                return
            except (FileNotFoundError, subprocess.CalledProcessError):
                continue
        # Fallback genérico: abre a pasta com o handler padrão do SO.
        subprocess.run(["xdg-open", folder])


def _select_windows_file(file_path: str) -> None:
    _select_windows_files([file_path])


def reveal_files_in_file_manager(paths):
    paths=list(dict.fromkeys(os.path.abspath(p) for p in paths))
    if not paths:return
    if platform.system()=='Windows':
        try:_select_windows_files(paths)
        except (OSError,ValueError) as exc:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(None,'Abrir na pasta',f'Não foi possível selecionar os arquivos no Explorer.\n{exc}')
    else:
        for path in paths:reveal_in_file_manager(path)


def _select_windows_files(paths):
    """Use Shell item IDs so spaces, accents and commas cannot alter selection."""
    import ctypes
    from ctypes import wintypes
    if not paths or any(not os.path.isfile(path) for path in paths):
        raise FileNotFoundError('O arquivo não está disponível neste caminho.')
    file_path=paths[0]
    if len({os.path.normcase(os.path.dirname(os.path.abspath(p))) for p in paths})!=1:
        raise ValueError('Os arquivos precisam estar na mesma pasta.')
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    ole = ctypes.WinDLL('ole32')
    ole.CoInitializeEx.argtypes = [ctypes.c_void_p, wintypes.DWORD]
    ole.CoInitializeEx.restype = ctypes.c_long
    ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
    ole.CoTaskMemFree.restype = None
    shell.SHParseDisplayName.argtypes = [wintypes.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p), wintypes.DWORD, ctypes.c_void_p]
    shell.SHParseDisplayName.restype = ctypes.c_long
    shell.ILFindLastID.argtypes = [ctypes.c_void_p]
    shell.ILFindLastID.restype = ctypes.c_void_p
    shell.SHOpenFolderAndSelectItems.argtypes = [ctypes.c_void_p, wintypes.UINT, ctypes.POINTER(ctypes.c_void_p), wintypes.DWORD]
    shell.SHOpenFolderAndSelectItems.restype = ctypes.c_long
    initialized = False
    folder_id = ctypes.c_void_p(); file_ids = []
    def check(result):
        if result < 0:raise OSError(f'Windows: erro 0x{result & 0xffffffff:08X}')
    try:
        result = ole.CoInitializeEx(None, 2)
        # Qt may already have initialized this thread in another COM mode.
        if result != -2147417850:
            check(result); initialized = True
        check(shell.SHParseDisplayName(os.path.dirname(file_path), None, ctypes.byref(folder_id), 0, None))
        for path in paths:
            file_id=ctypes.c_void_p();file_ids.append(file_id)
            check(shell.SHParseDisplayName(path, None, ctypes.byref(file_id), 0, None))
        children = (ctypes.c_void_p * len(file_ids))(*(shell.ILFindLastID(pid) for pid in file_ids))
        check(shell.SHOpenFolderAndSelectItems(folder_id, len(file_ids), children, 0))
    finally:
        for file_id in file_ids:
            if file_id.value:ole.CoTaskMemFree(file_id)
        if folder_id.value:ole.CoTaskMemFree(folder_id)
        if initialized:ole.CoUninitialize()
