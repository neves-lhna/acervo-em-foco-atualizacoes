"""Short-lived inventory handoff. Never trusts age or directory dates alone."""
import copy
import os
import time
from core.folder_history import path_key


def remember(cache, snapshot, paths, revision):
    if revision is None or snapshot.failures:return
    if len(snapshot.file_signatures)!=len(paths):return
    if len(snapshot.directory_signatures)!=len(snapshot.folders):return
    if cache.inventory_revision()!=revision:return
    # Retain a single completed root to bound memory.
    cache._recent_inventory=(time.monotonic(),revision,copy.deepcopy(snapshot),list(paths))


def reuse(cache, root, stopped=lambda:False, progress=None):
    saved=getattr(cache,'_recent_inventory',None)
    if not saved:return None
    stamp,revision,snapshot,paths=saved
    if time.monotonic()-stamp>120 or path_key(root)!=path_key(snapshot.root):return None
    if cache.inventory_revision(stopped)!=revision:return None
    try:
        for folder,signature in snapshot.directory_signatures.items():
            if stopped():raise InterruptedError('Conferência interrompida')
            st=os.stat(folder)
            if (st.st_mtime_ns,st.st_ctime_ns,st.st_ino)!=signature:return None
        for count,(path,signature) in enumerate(snapshot.file_signatures.items(),1):
            if stopped():raise InterruptedError('Conferência interrompida')
            st=os.stat(path)
            if (st.st_mtime_ns,st.st_ctime_ns,st.st_size,st.st_ino)!=signature:return None
            if progress and count%1000==0:progress(count)
    except OSError as exc:
        if isinstance(exc,InterruptedError):raise
        return None
    if cache.inventory_revision(stopped)!=revision:return None
    return copy.deepcopy(snapshot),list(paths)
