"""User-supplied authority references and results, independent of search history."""
import uuid
import os
import hashlib
from datetime import datetime
import numpy as np
from core.face_history import FaceHistory


class AuthorityStore(FaceHistory):
    def __init__(self, path):
        super().__init__(path)
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS authorities(id TEXT PRIMARY KEY, name TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS authority_references(
                id TEXT PRIMARY KEY, authority TEXT NOT NULL, embedding BLOB NOT NULL,
                portrait BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS authority_settings(
                face TEXT PRIMARY KEY,folder TEXT NOT NULL,threshold REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS authority_checked(
                face TEXT,path TEXT,mtime INTEGER,size INTEGER,signature TEXT,
                PRIMARY KEY(face,path));
            CREATE TABLE IF NOT EXISTS authority_inventory_state(face TEXT PRIMARY KEY,folder TEXT,signature TEXT);
            CREATE TABLE IF NOT EXISTS authority_inventory(face TEXT,path TEXT,mtime INTEGER,size INTEGER,PRIMARY KEY(face,path));
            CREATE TABLE IF NOT EXISTS authority_notifications(
                id INTEGER PRIMARY KEY,face TEXT,count INTEGER,created TEXT,read INTEGER DEFAULT 0);
        ''')

    def add_authority(self, name, embedding, portrait):
        name = name.strip()
        if not name:
            raise ValueError('Informe o nome da autoridade.')
        if any(row[1].casefold() == name.casefold() for row in self.authorities()):
            raise ValueError('Esse nome já está cadastrado. Adicione outra referência ao cadastro existente.')
        vector = self.valid_vector(embedding)
        key = uuid.uuid4().hex
        with self.db:
            self.db.execute('INSERT INTO authorities VALUES(?,?)', (key, name))
            self.db.execute('INSERT INTO faces VALUES(?,?,?,?,?)',
                            (key, portrait, datetime.now().isoformat(timespec='seconds'), '', 'Cadastrada'))
            self.db.execute('INSERT INTO authority_references VALUES(?,?,?,?)',
                            (uuid.uuid4().hex, key, vector.tobytes(), portrait))
        return key

    @staticmethod
    def valid_vector(embedding):
        vector = np.asarray(embedding, dtype=np.float32)
        if vector.shape != (512,) or not np.isfinite(vector).all() or np.linalg.norm(vector) == 0:
            raise ValueError('Referência facial inválida. Selecione o rosto novamente.')
        return vector / np.linalg.norm(vector)

    def add_reference(self, key, embedding, portrait):
        vector = self.valid_vector(embedding)
        with self.db:
            if not self.db.execute('SELECT 1 FROM authorities WHERE id=?', (key,)).fetchone():
                raise ValueError('Cadastro não encontrado.')
            self.db.execute('INSERT INTO authority_references VALUES(?,?,?,?)',
                            (uuid.uuid4().hex, key, vector.tobytes(), portrait))

    def authorities(self):
        return self.db.execute('SELECT a.id,a.name,count(r.id) FROM authorities a '
                               'LEFT JOIN authority_references r ON r.authority=a.id '
                               'GROUP BY a.id ORDER BY a.name COLLATE NOCASE').fetchall()

    def references(self, only=None):
        grouped = {}
        for key, blob in self.db.execute('SELECT authority,embedding FROM authority_references'):
            if only is not None and key not in only:
                continue
            grouped.setdefault(key, []).append(np.frombuffer(blob, dtype=np.float32).copy())
        return grouped

    def scan_settings(self, key):
        row = self.db.execute('SELECT folder,threshold FROM authority_settings WHERE face=?',(key,)).fetchone()
        if row:
            return row
        row = self.db.execute('SELECT folder FROM faces WHERE id=?',(key,)).fetchone()
        return ((row[0] if row else '') or '', .6)

    def default_folder(self):
        row = self.db.execute("SELECT folder FROM faces WHERE folder<>'' ORDER BY updated DESC LIMIT 1").fetchone()
        return row[0] if row else ''

    def remember_scan(self, key, folder, threshold):
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO authority_settings VALUES(?,?,?)',(key,folder,threshold))

    def scan_signature(self, key, threshold):
        digest = hashlib.sha256(f'authority-v1:{threshold:.6f}'.encode())
        for vector in self.references({key}).get(key, []):
            digest.update(vector.tobytes())
        return digest.hexdigest()

    def checked_files(self, key, signature):
        return {os.path.normcase(os.path.abspath(path)): (mtime, size)
                for path,mtime,size in self.db.execute(
                    'SELECT path,mtime,size FROM authority_checked WHERE face=? AND signature=?',(key,signature))}

    def save_checked(self, rows):
        with self.db:
            self.db.executemany('INSERT OR REPLACE INTO authority_checked VALUES(?,?,?,?,?)',rows)

    def save_inventory(self,key,folder,signature,files):
        with self.db:
            self.db.execute('DELETE FROM authority_inventory WHERE face=?',(key,))
            self.db.executemany('INSERT INTO authority_inventory VALUES(?,?,?,?)',
                ((key,p,m,s) for p,(m,s) in files.items()))
            self.db.execute('INSERT OR REPLACE INTO authority_inventory_state VALUES(?,?,?)',
                (key,os.path.normcase(os.path.abspath(folder)),signature))

    def reconcile_inventory(self,key,folder,files):
        root=os.path.normcase(os.path.abspath(folder))
        # Remove catalog entries only after a successful, complete enumeration.
        with self.db:
            for path, in self.db.execute('SELECT path FROM matches WHERE face=?',(key,)).fetchall():
                normalized=os.path.normcase(os.path.abspath(path))
                if normalized.startswith(root+os.sep) and normalized not in files:
                    self.db.execute('DELETE FROM matches WHERE face=? AND path=?',(key,path))

    def notify_new(self, key, count):
        if count:
            with self.db:
                self.db.execute('INSERT INTO authority_notifications(face,count,created) VALUES(?,?,?)',
                                (key,count,datetime.now().isoformat(timespec='seconds')))

    def notifications(self):
        return self.db.execute('SELECT n.id,a.name,n.count,n.created FROM authority_notifications n '
                               'JOIN authorities a ON a.id=n.face WHERE n.read=0 ORDER BY n.id').fetchall()

    def notification_entries(self):
        return self.db.execute('SELECT n.id,a.name,n.count,n.created,n.read FROM authority_notifications n '
                               'JOIN authorities a ON a.id=n.face ORDER BY n.id DESC').fetchall()

    def delete_read_notifications(self):
        with self.db:
            self.db.execute('DELETE FROM authority_notifications WHERE read=1')

    def mark_notifications_read(self, ids):
        with self.db:
            self.db.executemany('UPDATE authority_notifications SET read=1 WHERE id=?',((key,) for key in ids))

    def begin_scan(self, keys, folder):
        with self.db:
            for key in keys:
                self.db.execute('UPDATE faces SET folder=?,state=?,updated=? WHERE id=?',
                                (folder, 'Em busca', datetime.now().isoformat(timespec='seconds'), key))

    def remove_authority(self, key):
        with self.db:
            for table, column in (('matches', 'face'), ('authority_references', 'authority'),
                                  ('authority_checked', 'face'), ('authority_settings', 'face'),
                                  ('authority_notifications','face'), ('authority_inventory','face'), ('authority_inventory_state','face'), ('faces', 'id'), ('authorities', 'id')):
                self.db.execute(f'DELETE FROM {table} WHERE {column}=?', (key,))
