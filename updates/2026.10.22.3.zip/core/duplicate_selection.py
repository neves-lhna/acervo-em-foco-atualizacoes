"""Metadata hints; only byte-identical copies are selected automatically."""
import os
from functools import lru_cache
from PIL import Image

@lru_cache(maxsize=2048)
def image_info(path,mtime,size):
    try:
        with Image.open(path) as im:
            exif=im.getexif()
            details=exif.get_ifd(34665) if 34665 in exif else exif
            date=details.get(36867) or exif.get(306) or ''
            return f'{im.width} × {im.height} · EXIF: {date or "data ausente"} · {size/1048576:.1f} MB'
    except Exception:
        return f'{os.path.splitext(path)[1].upper().lstrip(".")} · EXIF indisponível · {size/1048576:.1f} MB'


def exact_suggestions(db,run):
    groups={}
    for path,digest in db.execute("SELECT DISTINCT s.path,s.digest FROM signatures s JOIN files f ON f.path=s.path WHERE f.run=? AND f.state='Analisada'",(run,)):
        if digest:groups.setdefault(digest,[]).append(path)
    selected=set();keepers={}
    for paths in groups.values():
        if len(paths)<2:continue
        paths.sort(key=lambda p:(len(p),p.casefold()))
        keep=paths[0]
        for path in paths[1:]:selected.add(path);keepers[path]=keep
    return selected,keepers

@lru_cache(maxsize=2048)
def preservation_rank(path,mtime,size):
    raw=os.path.splitext(path)[1].lower() in {'.nef','.cr2','.cr3','.arw','.dng','.raf','.orf','.rw2','.pef'}
    pixels=tags=0
    try:
        with Image.open(path) as im:
            pixels=im.width*im.height;tags=len(im.getexif())
    except Exception:pass
    return (raw,pixels,tags)


def preferred_copy(a,b):
    try:
        sa=os.stat(a);sb=os.stat(b)
        ra=preservation_rank(a,sa.st_mtime_ns,sa.st_size)
        rb=preservation_rank(b,sb.st_mtime_ns,sb.st_size)
        if ra==rb:return None
        return a if ra>rb else b
    except OSError:return None


def automatic_selection(db,run):
    """Choose globally, keeping a direct retained counterpart for every selection."""
    neighbors={}
    for a,b in db.execute('SELECT a,b FROM pairs WHERE run=?',(run,)):
        if a==b:continue
        neighbors.setdefault(a,set()).add(b);neighbors.setdefault(b,set()).add(a)
    ranks={}
    for path in neighbors:
        try:
            st=os.stat(path)
            ranks[path]=preservation_rank(path,st.st_mtime_ns,st.st_size)
        except OSError:continue
    ordered=sorted(ranks,key=lambda p:(tuple(-int(v) for v in ranks[p]),len(p),p.casefold()))
    selected=set();keepers={}
    for keep in ordered:
        if keep in selected:continue
        for other in neighbors[keep]:
            if other in ranks and other not in keepers:
                selected.add(other);keepers[other]=keep
    return selected,keepers
