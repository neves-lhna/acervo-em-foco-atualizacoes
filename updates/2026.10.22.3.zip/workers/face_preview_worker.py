import os
import cv2
from PySide6.QtCore import QThread, Signal
from core.face_history import FaceHistory
from core.image_loader import load_bgr_image


class FacePreviewWorker(QThread):
    ready=Signal(str,bytes)
    def __init__(self, db_path, face, rows, parent=None):
        super().__init__(parent);self.db_path=db_path;self.face=face;self.rows=rows

    def run(self):
        history=FaceHistory(self.db_path)
        try:
            for path,score,pose,mtime,size,preview in self.rows:
                if self.isInterruptionRequested():break
                if preview:continue
                try:
                    st=os.stat(path)
                    if (st.st_mtime_ns,st.st_size)!=(mtime,size):continue
                    bgr=load_bgr_image(path)
                    if bgr is None:continue
                    h,w=bgr.shape[:2];scale=min(200/w,130/h,1)
                    ok,data=cv2.imencode('.jpg',cv2.resize(bgr,(max(1,round(w*scale)),max(1,round(h*scale)))))
                    if not ok:continue
                    blob=data.tobytes()
                    with history.db:
                        history.db.execute('UPDATE matches SET preview=? WHERE face=? AND path=? AND mtime=? AND size=?',
                                           (blob,self.face,path,mtime,size))
                    self.ready.emit(path,blob)
                except Exception as exc:
                    from core.diagnostics import image_error
                    image_error(path,str(exc),'Prévia de pessoa')
                    continue
        finally:history.db.close()
