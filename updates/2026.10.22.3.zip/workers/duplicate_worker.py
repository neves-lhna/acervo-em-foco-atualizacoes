"""Persistent image-only duplicate scans, within the selected folder tree."""
import os, hashlib, time
from core import database as sqlite3
from core.diagnostics import image_error,program_error,folder_checked
from datetime import datetime
import cv2
from PySide6.QtCore import QThread, Signal
from core.image_loader import load_bgr_image
from core.folder_history import IMAGE_EXTENSIONS,is_image_file


def connect(path):
    db = sqlite3.connect(path, timeout=10)
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript('''
    CREATE TABLE IF NOT EXISTS signatures(path TEXT PRIMARY KEY,mtime INTEGER,size INTEGER,digest TEXT,phash TEXT,thumb BLOB);
    CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY,folder TEXT,started TEXT,level INTEGER,total INTEGER DEFAULT 0,done INTEGER DEFAULT 0,errors INTEGER DEFAULT 0,state TEXT);
    CREATE TABLE IF NOT EXISTS files(run INTEGER,path TEXT,state TEXT,error TEXT,PRIMARY KEY(run,path));
    CREATE TABLE IF NOT EXISTS pairs(run INTEGER,a TEXT,b TEXT,score REAL);
    CREATE INDEX IF NOT EXISTS pairs_run ON pairs(run);
    ''')
    return db


def visual_hash(bgr):
    gray=cv2.cvtColor(cv2.resize(bgr,(32,32)),cv2.COLOR_BGR2GRAY).astype('float32')
    values=cv2.dct(gray)[:8,:8].flatten()[1:]
    median=float(sorted(values)[len(values)//2])
    return sum(int(v>median)<<i for i,v in enumerate(values))


def similarity(a,b):
    return min(9.9,10*(1-(a^b).bit_count()/63))


class DuplicateWorker(QThread):
    progress=Signal(int)
    updated=Signal()
    status=Signal(str)
    subfolders_found=Signal(int)

    def __init__(self,folder,level,db_path,parent=None):
        super().__init__(parent);self.folder=os.path.abspath(folder);self.level=level;self.db_path=db_path
        self.stopped=False;self.run_id=None;self.failure=None;self.subfolders=0

    def stop(self):self.stopped=True

    def run(self):
        self.progress.emit(0)
        db=connect(self.db_path);total=done=errors=0
        try:
            with db:
                self.run_id=db.execute('INSERT INTO runs(folder,started,level,state) VALUES(?,?,?,?)',
                    (self.folder,datetime.now().isoformat(timespec='seconds'),self.level,'Analisando')).lastrowid
            if not os.path.isdir(self.folder):raise OSError(f'Pasta indisponível: {self.folder}')
            paths=[]
            def walk_error(exc):
                raise exc
            for folder, dirs, files in os.walk(self.folder,followlinks=False,onerror=walk_error):
                if self.stopped:break
                dirs[:]=[d for d in dirs if not os.path.islink(os.path.join(folder,d)) and not os.path.isjunction(os.path.join(folder,d))]
                self.subfolders+=len(dirs)
                for name in files:
                    path=os.path.join(folder,name)
                    if not os.path.islink(path) and is_image_file(path):paths.append(path)
            self.subfolders_found.emit(self.subfolders)
            paths.sort()
            total=len(paths)
            with db:
                db.execute('UPDATE runs SET total=? WHERE id=?',(total,self.run_id))
                db.executemany('INSERT INTO files VALUES(?,?,?,?)',[(self.run_id,p,'Pendente','') for p in paths])
            self.updated.emit();items=[];last=0
            for path in paths:
                if self.stopped:break
                try:
                    st=os.stat(path)
                    cached=db.execute('SELECT digest,phash FROM signatures WHERE path=? AND mtime=? AND size=?',(path,st.st_mtime_ns,st.st_size)).fetchone()
                    if cached is None:
                        sha=hashlib.sha256()
                        with open(path,'rb') as f:
                            while block:=f.read(1024*1024):
                                if self.stopped:break
                                sha.update(block)
                        if self.stopped:break
                        bgr=load_bgr_image(path)
                        if bgr is None:raise ValueError('Não foi possível decodificar a imagem')
                        after=os.stat(path)
                        if (st.st_mtime_ns,st.st_size)!=(after.st_mtime_ns,after.st_size):raise ValueError('Arquivo alterado durante a leitura; execute novamente')
                        ph=visual_hash(bgr);h,w=bgr.shape[:2];thumb=cv2.resize(bgr,(max(1,round(w*min(240/w,160/h))),max(1,round(h*min(240/w,160/h)))))
                        ok,encoded=cv2.imencode('.jpg',thumb)
                        if not ok:raise ValueError('Falha na prévia')
                        cached=(sha.hexdigest(),str(ph))
                        db.execute('INSERT OR REPLACE INTO signatures VALUES(?,?,?,?,?,?)',(path,st.st_mtime_ns,st.st_size,*cached,encoded.tobytes()))
                    items.append((path,cached[0],int(cached[1])))
                    done+=1;db.execute("UPDATE files SET state='Analisada' WHERE run=? AND path=?",(self.run_id,path))
                except Exception as exc:
                    image_error(path,str(exc),'Duplicidade')
                    errors+=1;db.execute("UPDATE files SET state='Falha',error=? WHERE run=? AND path=?",(str(exc),self.run_id,path))
                db.execute('UPDATE runs SET done=?,errors=? WHERE id=?',(done,errors,self.run_id));db.commit()
                if time.monotonic()-last>.2:
                    self.progress.emit(int(90*(done+errors)/total) if total else 0)
                    self.status.emit(f'Analisando imagens: {done+errors}/{total}');self.updated.emit();last=time.monotonic()
            if not self.stopped:
                self.progress.emit(90)
                db.execute("UPDATE runs SET state='Comparando' WHERE id=?",(self.run_id,));db.commit();self.updated.emit()
                exact_groups={}
                if self.level == 10:
                    for pos,(_,digest,_) in enumerate(items):exact_groups.setdefault(digest,[]).append(pos)
                for i,(a,sha,ph) in enumerate(items):
                    if self.stopped:break
                    matches=[]
                    candidates=(j for j in exact_groups[sha] if j>i) if self.level==10 else range(i+1,len(items))
                    for j in candidates:
                        if j%256==0 and self.stopped:break
                        b,other_sha,other_ph=items[j]
                        score=10.0 if sha==other_sha else similarity(ph,other_ph)
                        if score>=self.level:matches.append((self.run_id,a,b,score))
                    db.executemany('INSERT INTO pairs VALUES(?,?,?,?)',matches);db.commit()
                    if time.monotonic()-last>.2:
                        self.progress.emit(90+int(10*(i+1)/len(items)))
                        self.status.emit(f'Comparando imagens: {i+1}/{len(items)}');last=time.monotonic()
        except Exception as exc:self.failure=str(exc);program_error(str(exc),'Duplicidade')
        finally:
            if self.run_id is not None:
                state='Interrompida' if self.stopped else ('Com Falha' if errors or self.failure else 'Concluída')
                db.execute('UPDATE runs SET state=? WHERE id=?',(state,self.run_id));db.commit()
            folder_checked(self.folder,'Duplicidade: '+('interrompida' if self.stopped else 'concluída'))
            db.close();self.updated.emit()
            if not self.stopped and not self.failure:self.progress.emit(100)
            self.status.emit(self.failure or ('Verificação interrompida; resultados parciais preservados.' if self.stopped else 'Verificação finalizada. Confira visualmente os pares; nenhuma foto foi removida.'))
