from core.diagnostics import program_error
"""Independent, resumable cache preparation; no reference or matching."""
import threading
from PySide6.QtCore import Signal
from workers.scan_worker import ScanWorker
from core.face_engine import FaceEngine
from core.folder_history import inspect_folder, path_key
import time


class CacheWorker(ScanWorker):
    paused = Signal(bool)

    def __init__(self, folder, cache, history, parent=None):
        super().__init__(folder, None, 0, cache, parent, history)
        self._condition = threading.Condition()
        self._pause_requested = False
        self.processed = 0
        self.total = 0
        self.reused=set();self.computed=set()

    def pause(self):
        with self._condition:
            self._pause_requested = True

    def resume(self):
        with self._condition:
            self._pause_requested = False
            self._condition.notify_all()

    def stop(self):
        with self._condition:
            self._stop_requested = True
            self._condition.notify_all()

    def _checkpoint(self):
        with self._condition:
            if self._pause_requested and not self._stop_requested:
                self.paused.emit(True)
                while self._pause_requested and not self._stop_requested:
                    self._condition.wait()
                if not self._stop_requested:
                    self.paused.emit(False)
            return self._stop_requested

    def run(self):
        snapshot = None
        try:
            self.history.set_state(self.folder, 'inventory')
            self.history_changed.emit()
            from core.recent_inventory import reuse
            self.status.emit('Validando se a conferência recente ainda pode ser usada…')
            prepared=reuse(self.cache,self.folder,self._checkpoint,
                lambda n:self.status.emit(f'Validando conferência recente: {n:,} arquivos…'))
            if prepared:
                snapshot,paths=prepared
                self.status.emit('Conferência recente reaproveitada. Preparando apenas as fotos pendentes…')
            else:
                self.status.emit('Conferindo arquivos e cache existente…')
                snapshot, paths = inspect_folder(self.folder,
                    self.cache.metadata_index(cancelled=self._checkpoint), self._checkpoint,
                    lambda n: self.status.emit(f'Conferindo {n:,} imagens…'))
            if snapshot is None:
                return
            self.total = len(paths)
            self.history.save(snapshot, 'scanning', replace=True)
            self.history.reconcile_inventory(snapshot)
            self.history_changed.emit()
            self.progress.emit(0, self.total)
            engine = None
            last_save = last_progress = time.monotonic()
            for path in paths:
                if self._checkpoint():
                    break
                try:
                    # Skip valid images without deserializing their face vectors.
                    if path_key(path) not in snapshot.ready_paths:
                        if engine is None:
                            engine = FaceEngine.instance()
                        self._get_or_compute_embeddings(engine, path)
                        snapshot.mark_ready(path)
                        self.computed.add(path_key(path))
                    else:self.reused.add(path_key(path))
                except Exception as exc:
                    from concurrent.futures import CancelledError
                    if isinstance(exc, CancelledError):
                        break
                    self.failed_count += 1
                    self.failure_message = str(exc)
                    snapshot.mark_error(path,str(exc))
                self.processed += 1
                now = time.monotonic()
                if now - last_save >= 2 or self._pause_requested:
                    self.history.save(snapshot, 'scanning')
                    self.history_changed.emit()
                    last_save = now
                if now - last_progress >= .1:
                    self.progress.emit(self.processed, self.total)
                    last_progress = now
            self.progress.emit(self.processed, self.total)
        except InterruptedError:
            pass
        except Exception as exc:
            self.failure_message = str(exc)
            program_error(str(exc),'cache_worker');self.error.emit(str(exc))
        finally:
            state = 'interrupted' if self._stop_requested else ('error' if self.failure_message else 'ready')
            if snapshot is not None:
                self.history.save(snapshot, state)
                self.status.emit('Salvando resumo da coleta e contagem de rostos…')
                try:self.history.record_cache_details(snapshot,self.cache.face_counts(),self.reused,self.computed,state)
                except Exception as exc:
                    self.failure_message='Cache preservado, mas não foi possível salvar o resumo: '+str(exc)
                    self.error.emit(self.failure_message)
            else:
                self.history.set_state(self.folder, state, self.failure_message or '')
            self.history_changed.emit()
