import os
import shutil
from pathlib import Path
from PySide6.QtCore import QThread, Signal


def copy_unique(source, destination, mtime, size):
    """Never overwrite an existing file, including a same-name original."""
    st = os.stat(source)
    if (st.st_mtime_ns,st.st_size) != (mtime,size):
        raise ValueError('Arquivo alterado desde a busca; faça uma nova verificação.')
    source = Path(source)
    number = 0
    while True:
        name = source.name if not number else f'{source.stem} ({number}){source.suffix}'
        target = Path(destination)/name
        try:
            output = target.open('xb')
            break
        except FileExistsError:
            number += 1
    try:
        with output, source.open('rb') as original:
            shutil.copyfileobj(original,output,1024*1024)
        after = source.stat()
        if (after.st_mtime_ns,after.st_size) != (mtime,size):
            raise ValueError('Arquivo alterado durante a cópia.')
        shutil.copystat(source,target)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    return str(target)


class FaceExportWorker(QThread):
    progress = Signal(int,int)
    def __init__(self, rows, destination, parent=None,convert_raw=False):
        super().__init__(parent)
        self.rows=rows;self.destination=destination;self.copied=0;self.errors=[]
        self.stopped=False
        self.convert_raw=convert_raw

    def run(self):
        for i,row in enumerate(self.rows):
            if self.stopped:break
            path,score,pose,mtime,size,*_=row
            try:
                if self.convert_raw:
                    from core.photo_export import export_photo
                    export_photo(path,self.destination,mtime,size)
                else:copy_unique(path,self.destination,mtime,size)
                self.copied+=1
            except Exception as exc:
                from core.diagnostics import image_error
                image_error(path,str(exc),'Cópia de fotos')
                self.errors.append(f'{path}: {exc}')
            self.progress.emit(i+1,len(self.rows))
