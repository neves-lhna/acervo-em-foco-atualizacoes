from core.diagnostics import program_error
from PySide6.QtCore import QThread, Signal
from core.folder_history import inspect_folder
import os


class InventoryWorker(QThread):
    status = Signal(str)
    updated = Signal()
    error = Signal(str)
    activity = Signal(str,str,int,int,int)

    def __init__(self, roots, cache, history, parent=None, directories_only=True):
        super().__init__(parent)
        self.roots, self.cache, self.history = roots, cache, history
        self.summary='';self.checked=0;self.failures=0;self.observed=0
        self.directories_only=directories_only
        self.saved_roots=0

    def discover_directories(self):
        added=0;visited=set()
        try:
            for index,root in enumerate(self.roots,1):
                pending=[root];found=[]
                while pending:
                    if self.isInterruptionRequested():break
                    folder=pending.pop()
                    if folder in visited:continue
                    visited.add(folder)
                    self.observed+=1
                    self.activity.emit('Procurando pastas novas',folder,self.observed,index,len(self.roots))
                    try:
                        with os.scandir(folder) as entries:
                            children=[e.path for e in entries if e.is_dir(follow_symlinks=False)]
                        found.append(folder);pending.extend(children)
                    except OSError as exc:
                        self.failures+=1;program_error(str(exc),'inventory_worker');self.error.emit(str(exc))
                if self.isInterruptionRequested():break
                added+=self.history.add_discovered(root,found)
                self.updated.emit()
        except Exception as exc:
            self.failures+=1;program_error(str(exc),'inventory_worker');self.error.emit(str(exc))
        finally:
            state='Interrompido' if self.isInterruptionRequested() else 'Concluído'
            pending=len(self.history.discovered_keys())
            self.summary=f'Pastas: {state}. {self.observed:,} verificadas; {added} novas; {pending} aguardando coleta ou validação no acervo; {self.failures} ocorrência(s). Nenhum rosto processado nesta verificação.'

    def report(self,count,folder,index):
        self.observed=self.checked+count
        self.activity.emit('Conferindo arquivos',folder,self.observed,index,len(self.roots))

    def run(self):
        if self.directories_only:
            self.discover_directories();return
        try:
            self.activity.emit('Lendo informações do cache',self.roots[0] if self.roots else '',0,0,len(self.roots))
            revision=self.cache.inventory_revision(self.isInterruptionRequested) if hasattr(self.cache,'inventory_revision') else None
            metadata = self.cache.metadata_index(cancelled=self.isInterruptionRequested,
                progress=lambda count:self.activity.emit(f'Lendo cache: {count:,} registros consultados',
                    self.roots[0] if self.roots else '',0,0,len(self.roots)))
            for index,root in enumerate(self.roots,1):
                if self.isInterruptionRequested():
                    break
                self.history.set_state(root, 'inventory')
                self.status.emit(f'Conferindo arquivos: {root}')
                self.updated.emit()
                try:
                    snapshot, paths = inspect_folder(root, metadata, self.isInterruptionRequested,
                        lambda count: self.status.emit(f'Conferindo {count:,} arquivos: {root}'),
                        lambda count,folder:self.report(count,folder,index))
                    if snapshot is None:
                        self.history.set_state(root, 'interrupted')
                        break
                    self.checked+=len(paths)
                    self.failures+=len(snapshot.failures)
                    self.activity.emit('Salvando inventário',root,self.checked,index,len(self.roots))
                    self.history.save(snapshot, 'ready', replace=True)
                    self.history.reconcile_inventory(snapshot)
                    self.saved_roots+=1
                    from core.recent_inventory import remember
                    remember(self.cache,snapshot,paths,revision)
                    with self.history.lock,self.history.conn:
                        self.history.conn.execute("UPDATE roots SET message=? WHERE key=?",('Inventário validado: contagem de arquivos e conferência do cache; nenhum novo reconhecimento facial.',os.path.normcase(os.path.abspath(root))))
                except OSError as exc:
                    self.failures+=1
                    if os.path.isdir(root) or not self.history.forget_missing_root(root):
                        self.history.set_state(root, 'unavailable', str(exc))
                    program_error(str(exc),'inventory_worker');self.error.emit(str(exc))
                self.updated.emit()
        except InterruptedError:
            pass
        except Exception as exc:
            for root in self.roots:
                self.history.set_state(root, 'interrupted', str(exc))
            program_error(str(exc),'inventory_worker');self.error.emit(str(exc))
            self.failures+=1
        finally:
            state='Interrompido' if self.isInterruptionRequested() else ('Concluído com ocorrências' if self.failures else 'Concluído')
            if self.isInterruptionRequested() and self.observed==0 and self.saved_roots==0:
                self.summary='Verificação interrompida antes da conferência das fotos. Os números anteriores foram preservados. Nenhum rosto foi processado.'
            else:
                result=(f'{self.saved_roots} pasta(s) selecionada(s) com inventário atualizado; as demais mantêm os números anteriores.'
                        if self.saved_roots else 'Nenhum inventário atualizado. Os números anteriores foram preservados.')
                self.summary=f'Inventário: {state}. {self.observed:,} imagens conferidas; {self.failures} ocorrência(s). {result} Nenhum rosto novo processado.'
