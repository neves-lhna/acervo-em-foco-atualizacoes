"""Metadata-only gate for automatic authority searches; never decodes photos."""
import os
from core import database as sqlite3
from contextlib import closing
from PySide6.QtCore import QThread, Signal
from core.folder_history import is_image_file


def inventory(folder, stopped=lambda:False):
    if not os.path.isdir(folder):raise OSError('Pasta do acervo indisponível.')
    result={}
    def fail(error):raise error
    for root,dirs,files in os.walk(folder,onerror=fail):
        if stopped():raise InterruptedError('Conferência interrompida.')
        for name in files:
            if stopped():raise InterruptedError('Conferência interrompida.')
            path=os.path.abspath(os.path.join(root,name))
            if is_image_file(path):
                stat=os.stat(path)
                result[os.path.normcase(path)]=(stat.st_mtime_ns,stat.st_size)
    if not os.path.isdir(folder):raise OSError('O acervo foi desconectado.')
    return result


class AuthorityInventoryWorker(QThread):
    result=Signal(object)
    def __init__(self,db,key,folder,signature,parent=None,snapshot=None):
        super().__init__(parent)
        self.snapshot=snapshot
        self.db,self.key,self.folder,self.signature=db,key,folder,signature
    def run(self):
        try:
            current=self.snapshot if self.snapshot is not None else inventory(self.folder,self.isInterruptionRequested)
            if not os.path.isdir(self.folder):raise OSError("Acervo indisponível.")
            with closing(sqlite3.connect(self.db,timeout=10)) as db:
                marker=db.execute('SELECT folder,signature FROM authority_inventory_state WHERE face=?',(self.key,)).fetchone()
                valid=marker==(os.path.normcase(os.path.abspath(self.folder)),self.signature)
                if valid:
                    previous=dict((p,(m,s)) for p,m,s in db.execute('SELECT path,mtime,size FROM authority_inventory WHERE face=?',(self.key,)))
                else:
                    previous=None
                checked={os.path.normcase(os.path.abspath(p)):(m,s) for p,m,s in db.execute('SELECT path,mtime,size FROM authority_checked WHERE face=? AND signature=?',(self.key,self.signature))}
            # Existing installations can use completed checkpoints without rebuilding recognition.
            unchanged=current==(previous if previous is not None else checked)
            pending=[p for p,metadata in current.items() if checked.get(p)!=metadata]
            self.result.emit({'current':current,'pending':pending,'unchanged':unchanged,'baseline':valid})
        except Exception as error:
            from core.diagnostics import program_error
            program_error(str(error),'Inventário de pessoas')
            self.result.emit({'error':str(error)})
