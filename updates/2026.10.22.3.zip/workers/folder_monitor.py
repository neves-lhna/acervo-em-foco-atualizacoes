"""Directory-only monitoring, including external archive volumes; no image decoding."""
import os
import time
from datetime import datetime
from PySide6.QtCore import QThread,Signal
from core.folder_history import path_key,is_within

class FolderMonitor(QThread):
    checked=Signal(object,object)
    activity=Signal(str)
    summary=Signal(str)
    def __init__(self,history,previous,parent=None,tracked_only=False):
        super().__init__(parent);self.history=history;self.previous=previous;self.tracked_only=tracked_only
    def run(self):
        roots,rows=self.history.records();current={};changed=set();dirty=[];observations=[]
        paths={r[2] for r in rows}|{r[1] for r in roots};known={path_key(p) for p in paths}
        previous=self.history.observed_signatures();previous.update(self.previous)
        # A saved monitor signature is only an observation, not proof that the
        # cache was validated after this directory was modified.
        checked_at={r[0]:r[3] for r in roots}
        validated={}
        for owner,key,path,*rest in rows:
            stamp=checked_at.get(owner)
            if stamp:
                try:validated[key]=max(validated.get(key,0),datetime.fromisoformat(stamp).timestamp())
                except ValueError:pass
        already_pending=self.history.discovered_keys()
        bases=set()
        for root in roots:
            drive=os.path.splitdrive(root[1])[0]
            bases.add(drive+os.sep if not self.tracked_only and drive and drive.casefold()!=os.environ.get('SystemDrive','C:').casefold() else root[1])
        visited=set();new=returned=altered=outside=errors=0;last=0
        for base in sorted(bases):
            pending=[base]
            while pending:
                if self.isInterruptionRequested():return
                path=pending.pop();key=path_key(path)
                if key in visited:continue
                visited.add(key)
                now=time.monotonic()
                if now-last>.25:
                    self.activity.emit(f'Verificando pastas do HD: {len(visited):,} pastas percorridas — {path}');last=now
                try:
                    stat=os.stat(path);signature=(stat.st_mtime_ns,stat.st_ino)
                    with os.scandir(path) as entries:
                        children=[e.path for e in entries if e.is_dir(follow_symlinks=False) and e.name.casefold() not in ('$recycle.bin','system volume information')]
                except OSError as exc:
                    from core.diagnostics import record
                    record('error',folder=path,error=str(exc),stage='Verificação de pastas')
                    errors+=1;continue
                pending.extend(children);current[key]=signature;observations.append((path,signature))
                owners=[r[1] for r in roots if is_within(path,r[1])]
                if not owners:
                    if key not in previous:outside+=1
                    continue
                if key not in known:
                    from core.diagnostics import notify,folder_checked
                    notify('Foi encontrada uma pasta nova no acervo: '+path)
                    folder_checked(path,'Nova pasta detectada')
                    new+=1;dirty.append(path);changed.add(min(owners,key=len))
                elif (key in previous and previous[key]!=signature) or (key in validated and int(stat.st_mtime)>int(validated[key])):
                    if key in previous and previous[key] is None:returned+=1
                    else:altered+=1
                    dirty.append(path)
                    if key not in already_pending:changed.add(min(owners,key=len))
        # Confirm disappearance only with a readable parent; offline disks are preserved.
        for path in paths:
            key=path_key(path)
            if key in current:continue
            try:
                with os.scandir(os.path.dirname(path)) as entries:
                    if any(e.name.casefold()==os.path.basename(path).casefold() for e in entries):continue
            except OSError:continue
            current[key]=None;observations.append((path,None));dirty.append(path)
            owners=[r[1] for r in roots if is_within(path,r[1])]
            if owners:changed.add(min(owners,key=len))
        self.history.mark_changed(dirty);self.history.save_observations(observations)
        message=f'Verificação de pastas: {len(visited):,} percorridas; {new} novas no acervo; {returned} reencontradas; {altered} alteradas; {errors} inacessíveis. Nenhuma coleta de rostos executada.'
        if outside:message+=f' {outside} pastas detectadas fora do acervo acompanhado; use Acompanhar pasta para incluí-las.'
        self.summary.emit(message);self.checked.emit(current,sorted(changed))
