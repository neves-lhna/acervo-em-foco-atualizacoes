import numpy as np
import threading
import time
import os
from PySide6.QtCore import Signal
from workers.scan_worker import ScanWorker


def authority_matches(embeddings, references, threshold):
    """One best match per authority and image, even with multiple references."""
    if not embeddings:
        return []
    faces = np.stack(embeddings)
    matches = []
    for key, vectors in references.items():
        scores = faces @ np.stack(vectors).T
        face, reference = np.unravel_index(scores.argmax(), scores.shape)
        score = float(scores[face, reference])
        if score >= threshold:
            matches.append((key, int(face), score))
    return matches


class AuthorityWorker(ScanWorker):
    authority_evaluated = Signal(str,str)
    authority_found = Signal(str, str, float, str)
    file_checked = Signal(object)

    def __init__(self, folder, references, threshold, cache, parent=None, checked=None, signatures=None, paths=None):
        super().__init__(folder, None, threshold, cache, parent=parent)
        self.paths = paths
        self.references = references
        self._activity_lock = threading.Lock()
        self._activities = {}
        self.checked = checked or {}
        self.signatures = signatures or {}

    def _iter_image_paths(self):
        if self.paths is None:
            yield from super()._iter_image_paths()
        else:
            for path in self.paths:
                if self._stop_requested:return
                yield path

    def activity_snapshot(self):
        with self._activity_lock:
            return dict(self._activities)

    def _report_activity(self, path, stage):
        with self._activity_lock:
            self._activities[path] = (stage, time.monotonic())

    def _process_image(self, engine, path):
        try:
            if self._stop_requested:
                return None
            stat = os.stat(path)
            normalized = os.path.normcase(os.path.abspath(path))
            pending = {key: refs for key,refs in self.references.items()
                       if self.checked.get(key,{}).get(normalized) != (stat.st_mtime_ns,stat.st_size)}
            if not pending:
                return None
            embeddings, poses = self._get_or_compute_embeddings(engine, path)
            if self._stop_requested:return None
            for key in pending:self.authority_evaluated.emit(key,path)
            self._report_activity(path, 'Comparando com as referências das autoridades')
            for key, index, score in authority_matches(embeddings, pending, self.threshold):
                if self._stop_requested:
                    break
                self.authority_found.emit(key, path, score, poses[index])
            after = os.stat(path)
            if not self._stop_requested and (after.st_mtime_ns,after.st_size)==(stat.st_mtime_ns,stat.st_size):
                for key in pending:
                    if key in self.signatures:
                        self.file_checked.emit((key,os.path.abspath(path),stat.st_mtime_ns,stat.st_size,self.signatures[key]))
            return None
        finally:
            with self._activity_lock:
                self._activities.pop(path, None)
