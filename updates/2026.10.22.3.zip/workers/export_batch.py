from core.diagnostics import image_error
"""Background batch export, comparison samples and guarded copy disposal."""
from PySide6.QtCore import QThread,Signal
from core.export_pipeline import export_one,discard_export

class ExportBatch(QThread):
    progress=Signal(int,int,str)
    def __init__(self,rows,destination,options,parent=None):
        super().__init__(parent);self.rows=rows;self.destination=destination;self.options=options
        self.results=[];self.errors=[];self.stopped=False
    def run(self):
        for i,row in enumerate(self.rows):
            if self.isInterruptionRequested():self.stopped=True;break
            self.progress.emit(i,len(self.rows),row[0])
            try:self.results.append(export_one(row,self.destination,self.options))
            except Exception as exc:image_error(row[0],str(exc),'Exportação');self.errors.append(f'{row[0]}: {exc}')
            self.progress.emit(i+1,len(self.rows),row[0])

class ExportSamples(QThread):
    def __init__(self,row,destination,limit,parent=None):
        super().__init__(parent);self.row=row;self.destination=destination;self.limit=limit;self.paths=[];self.notes=[];self.errors=[]
    def run(self):
        from core.export_pipeline import rendered,jpeg_bytes
        from pathlib import Path
        for method,label in [('camera','1 - Aparência da câmera'),('develop','2 - Revelação RAW')]:
            if self.isInterruptionRequested():break
            try:
                image,actual,notes=rendered(self.row[0],method)
                data,reduced=jpeg_bytes(image,self.limit)
                path=Path(self.destination)/(label+'.jpg');path.write_bytes(data)
                self.paths.append(str(path));self.notes.append(label+': '+actual+'. '+ ' '.join(notes)+(' Dimensões reduzidas.' if reduced else ''))
            except Exception as exc:image_error(self.row[0],str(exc),'Amostra de conversão');self.errors.append(label+': '+str(exc))

class DiscardCopies(QThread):
    def __init__(self,records,destination,parent=None):
        super().__init__(parent);self.records=records;self.destination=destination;self.removed=[];self.errors=[]
    def run(self):
        for record in self.records:
            try:discard_export(record,self.destination);self.removed.append(record['path'])
            except Exception as exc:image_error(record['path'],str(exc),'Descarte de cópia');self.errors.append(record['path']+': '+str(exc))
