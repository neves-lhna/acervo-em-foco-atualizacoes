"""
workers/scan_worker.py
------------------------
Núcleo da responsividade da aplicação: TODA a varredura de pastas e
inferência de rede neural roda aqui, em uma QThread separada da thread
de UI (thread principal do Qt).

Por que QThread + Signals/Slots (e não apenas `threading.Thread`)?
  - PySide6/Qt já garante que sinais emitidos em uma QThread são
    entregues de forma thread-safe aos slots conectados na thread
    principal (via fila de eventos do Qt, "queued connection"
    automática quando threads diferem). Isso evita tocar em widgets
    diretamente de outra thread, o que quebraria a UI.
  - `threading.Thread` funcionaria para o cálculo, mas exigiria
    sincronização manual (ex.: QMetaObject.invokeMethod) para
    atualizar a UI com segurança — QThread já resolve isso.

Fluxo:
  1. `run()` varre recursivamente a pasta escolhida.
  2. Para cada imagem: consulta o cache; se não houver cache válido,
     detecta rostos + calcula embeddings e atualiza o cache.
  3. Compara cada rosto encontrado com o embedding de referência
     (similaridade de cosseno).
  4. Se a melhor similaridade da foto >= limiar, emite o sinal
     `match_found` IMEDIATAMENTE (streaming de resultados) — a UI
     não espera o fim da varredura.
  5. Emite `progress` periodicamente para a barra de progresso e
     `finished` ao concluir (ou `error` em caso de falha).

O worker é interrompível (`stop()`), permitindo cancelar uma busca em
andamento sem travar a interface.
"""

from __future__ import annotations
from core.diagnostics import program_error

import os
import time
from dataclasses import dataclass

from PySide6.QtCore import QThread, Signal

from core.face_engine import FaceEngine, load_bgr_image
from core.embedding_cache import EmbeddingCache

from core.image_loader import RAW_EXTENSIONS
from core.folder_history import inspect_folder,IMAGE_EXTENSIONS,is_image_file



@dataclass
class MatchResult:
    path: str
    score: float          # similaridade de cosseno (0-1, aprox.)
    pose: str              # "frontal" | "perfil" do rosto que casou


class ScanWorker(QThread):
    # (path_arquivo, score, pose)
    match_found = Signal(str, float, str)
    # (arquivos_processados, total_estimado)
    progress = Signal(int, int)
    # mensagem de status (ex.: "Indexando 1234 fotos...")
    status = Signal(str)
    error = Signal(str)
    history_changed = Signal()

    def __init__(
        self,
        folder: str,
        query_embedding,
        threshold: float,
        cache: EmbeddingCache,
        parent=None,
        history=None,
    ):
        super().__init__(parent)
        self.folder = folder
        self.query_embedding = query_embedding
        self.threshold = threshold
        self.cache = cache
        self.history = history
        self._stop_requested = False
        self.failure_message = None
        self.failed_count = 0

    def stop(self):
        self._stop_requested = True

    # ------------------------------------------------------------------
    def _iter_image_paths(self):
        for root, _dirs, files in os.walk(self.folder):
            if self._stop_requested:
                return
            for name in files:
                ext = os.path.splitext(name)[1].lower()
                if is_image_file(os.path.join(root,name)):
                    yield os.path.join(root, name)

    def _process_image(self, engine, path):
        embeddings, poses = self._get_or_compute_embeddings(engine, path)
        if embeddings:
            best_idx, best_score = self._best_match(embeddings)
            if best_score >= self.threshold:
                return path, best_score, poses[best_idx]
        return None

    def run(self):
        snapshot = None
        try:
            import concurrent.futures
            self.status.emit("Enumerando arquivos de imagem...")
            if self.history is not None:
                self.history.set_state(self.folder, 'inventory')
                self.history_changed.emit()
                snapshot, all_paths = inspect_folder(self.folder, self.cache.metadata_index(), lambda: self._stop_requested,
                    lambda count: self.status.emit(f'Enumerando e conferindo cache: {count:,} imagens…'))
                if snapshot is None:
                    return
                self.history.save(snapshot, 'scanning', replace=True)
                self.history_changed.emit()
            else:
                all_paths = list(self._iter_image_paths())
            total = len(all_paths)
            engine = FaceEngine.instance() if total and not self._stop_requested else None
            self.status.emit(f"{total} imagens encontradas. Iniciando análise...")

            processed = 0
            last_emit_time = 0.0
            last_history_time = time.monotonic()

            def collect(future, path):
                nonlocal processed
                if future.cancelled():
                    return
                try:
                    result = future.result()
                    if snapshot is not None:
                        snapshot.mark_ready(path)
                    if result and not self._stop_requested:
                        self.match_found.emit(*result)
                except concurrent.futures.CancelledError:
                    return
                except Exception as exc:
                    self.failed_count += 1
                    self.failure_message = str(exc)
                    if snapshot is not None:
                        snapshot.mark_error(path,str(exc))
                processed += 1

            # Bound decoding and pending work: inference is serialized by the engine.
            paths = iter(all_paths)
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
                pending = {}
                def submit_next():
                    if self._stop_requested:
                        return
                    path = next(paths, None)
                    if path is not None:
                        pending[executor.submit(self._process_image, engine, path)] = path
                for _ in range(2):
                    submit_next()
                while pending and not self._stop_requested:
                    done, _ = concurrent.futures.wait(pending, timeout=0.1,
                        return_when=concurrent.futures.FIRST_COMPLETED)
                    for future in done:
                        collect(future, pending.pop(future))
                        submit_next()
                    now = time.monotonic()
                    if snapshot is not None and now - last_history_time >= 2:
                        self.history.save(snapshot, 'scanning')
                        self.history_changed.emit()
                        last_history_time = now
                    if now - last_emit_time > 0.1 or processed == total:
                        self.progress.emit(processed, total)
                        last_emit_time = now
                for future in pending:
                    future.cancel()
            for future, path in pending.items():
                collect(future, path)
            self.progress.emit(processed, total)

        except Exception as exc:  # pragma: no cover - defensivo
            self.failure_message = str(exc)
            program_error(str(exc),'scan_worker');self.error.emit(str(exc))
        finally:
            if self.history is not None:
                state = 'interrupted' if self._stop_requested else ('error' if self.failure_message else 'ready')
                if snapshot is not None:
                    self.history.save(snapshot, state)
                else:
                    self.history.set_state(self.folder, state, self.failure_message or '')
                self.history_changed.emit()

    # ------------------------------------------------------------------
    def _report_activity(self, path, stage):
        """Optional activity reporting; existing search and cache workers are unchanged."""
        pass

    def _get_or_compute_embeddings(self, engine: FaceEngine, path: str):
        self._report_activity(path, 'Conferindo acesso ao arquivo')
        try:
            stat = os.stat(path)
        except OSError as exc:
            raise OSError(f'Não foi possível acessar: {path}') from exc

        self._report_activity(path, 'Consultando o cache')
        cached = self.cache.get_cached(path, stat.st_mtime, stat.st_size)
        if cached is not None:
            return cached, self.cache.get_poses(path)

        if self._stop_requested:
            from concurrent.futures import CancelledError
            raise CancelledError()

        self._report_activity(path, 'Lendo e decodificando a imagem')
        bgr = load_bgr_image(path)
        if bgr is None:
            raise ValueError(f"Não foi possível decodificar: {path}")
        if self._stop_requested:
            from concurrent.futures import CancelledError
            raise CancelledError()

        self._report_activity(path, 'Reconhecimento facial (inclui espera pelo modelo)')
        faces = engine.detect_faces(bgr)
        embeddings = [f.embedding for f in faces]
        poses = [f.pose for f in faces]

        self._report_activity(path, 'Salvando o reconhecimento no cache')
        self.cache.store(path, stat.st_mtime, stat.st_size, embeddings, poses)
        return embeddings, poses

    def _best_match(self, embeddings):
        import numpy as np

        stacked = np.stack(embeddings)
        sims = stacked @ self.query_embedding
        best_idx = int(sims.argmax())
        return best_idx, float(sims[best_idx])
